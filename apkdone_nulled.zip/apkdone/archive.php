<?php if ( ! defined( 'ABSPATH' ) ) exit; get_header(); ?>
    <main class="container">
    <div class="wrap archive">
        <div class="columns">
            <div class="column is-9">
                <nav class="breadcrumb" aria-label="breadcrumb_items" style="text-transform: capitalize;">
                    <span>
                        <span>
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a> » <?php printf( __( '%s', 'apkdone' ), '<span class="breadcrumb_last" aria-current="page">' . single_cat_title( '', false ) . '</span>' ); ?>
                        </span>
                    </span>
                </nav>
				<?php ex_themes_adv_homes_(); ?>
                <div class="clearfix"></div>
				 <div class="block-title">
                    <div class="atitle">
                        <?php printf( __( '%s', 'apkdone' ), '<p>' . single_cat_title( '', false ) . '</p>' ); ?>
                    </div>
                </div>
                <div class="columns is-multiline">
                    <?php $postcounter = 1; if (have_posts()) : ?>
                    <?php while (have_posts()) : $postcounter = $postcounter + 1; the_post(); $do_not_duplicate = $post->ID; $the_post_ids = get_the_ID(); ?>
                        <a href="<?php the_permalink() ?>" class="column app is-4 post post-<?php echo $postcounter ;?>" title="<?php the_title(); ?>">
                            <div>
                                <?php
                                global $wpdb, $post;
                                $thumbnails = get_post_meta( $post->ID, 'wp_poster_GP', true );
                                ?>
                                <?php global $opt_themes; if($opt_themes['ex_themes_thumbnails_gpstore_active_']) { ?>
                                    <img alt="<?php echo get_the_title(); ?>" data-spai="1" class="lzl" src="<?php echo $thumbnails; ?>=w64-rw"  data-spai-upd="64"/>
                                <?php } else { ?>
                                    <?php if (has_post_thumbnail()) { ?>
                                        <img alt="<?php echo get_the_title(); ?>" data-spai="1" class="lzl" src="<?php $image_id = get_post_thumbnail_id(); $image_url = wp_get_attachment_image_src($image_id,'64', true); echo $image_url[0]; ?>"  data-spai-upd="64"/>
                                    <?php } else { ?>
                                        <img alt="<?php echo get_the_title(); ?>" data-spai="1" class="lzl" src="<?php echo get_template_directory_uri(); ?>/assetss/img/lazy.png"  data-spai-upd="64"/>
                                    <?php } ?>
                                <?php } ?>
                            </div>
                            <div> <b><?php the_title(); ?></b>
                                <p><span class="tag"><?php echo esc_html( get_post_meta( $post->ID, 'wp_rated_GP', true ) ); ?> ★</span> •
                                    <?php global $opt_themes; $ex_themes_fakees_ = mt_rand(500,9999); if($opt_themes['ex_themes_fake_view_active_']) { ?>
                                        <span class="tag"> <i class="icon-dl"></i> <!--<?php echo numToKs($ex_themes_fakees_); ?>--> <?php echo $ex_themes_fakees_; ?> </span>
                                    <?php } else { ?>
                                        <span class="tag"> <i class="icon-dl"></i> <?= ex_themes_get_post_view_(); ?> </span>
                                    <?php } ?>
                                </p>
                                <span>
                                    <?php
                                    $i = 0;
                                    foreach((get_the_category()) as $cat) {
                                        echo '' . $cat->cat_name . '';
                                        if (++$i == 1) break;
                                    }
                                    ?>
                                </span>
                            </div>
                        </a>
                    <?php endwhile; ?>
                </div>
                <div class="clearfix"></div>               
                <ul class="pagination paginador"><?php ex_themes_page_navy_(); ?></ul>
                <?php else : ?>
                <?php endif; ?>
            </div>
            <div class="column is-3 sidebar">
                <?php get_sidebar(); ?>
            </div>
        </div>
        <div id="breadcrumbiblog">
            <?php if (function_exists('breadcrumbsX')) breadcrumbsX(); ?>
        </div>
    </div> 
<?php get_footer(); ?>