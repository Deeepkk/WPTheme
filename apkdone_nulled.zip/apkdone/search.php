<?php get_header(); ?>
<div class="wrap post-<?php the_title(); ?>">
<div class="single page page-<?php the_ID(); ?>">
    <div class="container">
        <div class="columns">
            <div class="column is-9">
                <nav class="breadcrumb" aria-label="breadcrumb_items">
                    <span>
                        <span>
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a> »
                            <span class="breadcrumb_last" aria-current="page"><?php the_title(); ?>                            
							</span>
                        </span>
                    </span>
                </nav>
                <div class="block-title">
                    <div class="atitle">
                        <p>For the term "<?php the_title(); ?>"</p>
                    </div>
                </div>
                <?php get_template_part('template/loop/search'); ?>
                <div class="clearfix"></div>
                <ul class="pagination paginador">
                    <?php ex_themes_page_navy_(); ?>
                </ul>
            </div>
            <div class="column is-3 sidebar">
                <?php get_sidebar(); ?>
            </div>
        </div>
        <div id="breadcrumbiblog">
            <?php if (function_exists('breadcrumbsX')) breadcrumbsX(); ?>
        </div>
    </div>
    </section>
<?php get_footer(); ?>