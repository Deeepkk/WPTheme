<!DOCTYPE html>
<!--[if IE 7]><html class="ie7 no-js"  <?php language_attributes(); ?><![endif]-->
<!--[if lte IE 8]><html class="ie8 no-js"  <?php language_attributes(); ?><![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="not-ie no-js" <?php language_attributes(); ?>>  <!--<![endif]-->
<head>
<meta charset="utf-8">
<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php wp_head(); ?>
<?php ex_themes_head_on_sections_(); ?>

</head>
<header>
    <nav class="navbar has-shadow is-small">
        <div class="container">
            <div class="navbar-brand">
                <div class="navbar-burger burger" data-target="header-menu" style="margin-left: 0;" onclick="this.classList.toggle('is-active');document.getElementById('header-menu').classList.toggle('is-active');">
				<span></span><span></span><span></span>
                </div>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-item"><?php ex_themes_logo_headers_(); ?></a>
                <div aria-label="Search" onclick="document.querySelectorAll('.navbar-burger')[0].classList.toggle('is-active');document.getElementById('header-menu').classList.toggle('is-active');document.querySelector('input[name=s]').focus()" class="navbar-item is-hidden-desktop search-icon">
				<span class="icon"><svg width="16" height="16" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1216 832q0-185-131.5-316.5t-316.5-131.5-316.5 131.5-131.5 316.5 131.5 316.5 316.5 131.5 316.5-131.5 131.5-316.5zm512 832q0 52-38 90t-90 38q-54 0-90-38l-343-342q-179 124-399 124-143 0-273.5-55.5t-225-150-150-225-55.5-273.5 55.5-273.5 150-225 225-150 273.5-55.5 273.5 55.5 225 150 150 225 55.5 273.5q0 220-124 399l343 343q37 37 37 90z" fill="#fff"></path></svg> 
				</span>
                </div>
            </div>
            <div id="header-menu" class="navbar-menu">
                <?php if (is_home() || is_front_page()) { ?>
                <?php } elseif (is_single() || is_page() || is_search() || is_archive() || is_404() || is_tag()) { ?>
                    <div class="navbar-start">
                        <div class="navbar-item">
                            <form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="GET">
                                <div>
                                    <div> <input name="s" value="" required="" class="ainput" type="search" placeholder="To search type and hit enter">
                                    </div> <button aria-label="Search" class="abutton is-light"> <span>Search</span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php } ?>
                <div class="navbar-end">
                    <div class="menu-header-container">
                        <ul id="menu-header" class="menu">
                            <?php ex_themes_headers_menu_(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header>

<main class="container"  itemscope itemtype="https://schema.org/SoftwareApplication">