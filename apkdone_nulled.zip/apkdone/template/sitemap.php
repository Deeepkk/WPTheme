<?php
/* 
Template Name: Template - Sitemap
*/
?>
<?php
###### https://www.geeksforgeeks.org/php-str_replace-function/
###### PHP | str_replace() Function 
###### Input string 
$url = get_bloginfo('url');
###### using str_replace() function 
$urls = str_replace('http://', '', $url);
$linkX = get_bloginfo('url');;
$parse = parse_url($linkX);
$urls = $parse['host'];
//$urls = str_replace('https://', '', $url);
$datePublished = mysql2date( DATE_W3C, $post->post_date, false );
$dateModified = mysql2date( DATE_W3C, $post->post_modified_gmt, false );
?>
<?php
$post_date = get_the_date( 'l, F j, Y' );
$post_time = get_the_date( 'g:i A' );
?>
    <style>
        .btnt-sitemap { border-bottom: 4px solid <?php global $opt_themes; if(($opt_themes['color'] == '')) { } else {} echo $opt_themes['color'];  ?>; }
        .btnt-toc-wrap { display: inline-block; font-family: "Century Gothic",sans-serif; width: 100%; }
        .btnt-toc-wrap .btnt-cat { background: <?php global $opt_themes; if(($opt_themes['color'] == '')) { } else {} echo $opt_themes['color'];  ?>; border-radius: 2px; color: #fff; font-size: 15px; font-weight: bold; padding: 10px 20px; text-transform: capitalize; }
        .btnt-toc::before { background: <?php global $opt_themes; if(($opt_themes['color'] == '')) { } else {} echo $opt_themes['color'];  ?>; bottom: 0; content: ""; left: 20%; margin-left: -10px; position: absolute; top: 0; width: 4px; }
        .btnt-toc { margin: 0!important; padding: 30px 20px; position: relative; }
        .btnt-toc li { list-style: none; margin: 0; padding: 0; position: relative; }
        .btnt-toc > li .toc-date { color: #999; display: block; font-size: 14px; font-weight: bold; position: absolute; text-transform: uppercase; top: 25px; width: 15%; }
        .btnt-toc > li .btnt-icon { background: #fff; border-radius: 50%; box-shadow: 0 0 0 4px <?php global $opt_themes; if(($opt_themes['color'] == '')) { } else {} echo $opt_themes['color'];  ?>; color: #fff; font-size: 1.4em; font-style: normal; font-variant: normal; font-weight: normal; height: 10px; left: 20%; line-height: 10px; margin: 0 0 0 -25px; position: absolute; text-align: center; text-transform: none; top: 30px; width: 10px; }
        .btnt-toc > li .btnt-post::after { border-color: transparent #f5f5f5 transparent transparent; border-style: solid; border-width: 10px; content: " "; height: 0; pointer-events: none; position: absolute; right: 100%; top: auto; width: 0; }
        .btnt-toc > li .btnt-post { background: #f5f5f5; border-radius: 5px; display: block; font-size: 15px; line-height: 15px; margin: 0 0 15px 23%; padding: 25px 30px; position: relative; }
        .btnt-toc > li .btnt-post a { color: <?php global $opt_themes; if(($opt_themes['color'] == '')) { } else {} echo $opt_themes['color'];  ?>; font-weight: bold; }
        .btnt-toc > li .btnt-post a:hover { color: #999; }
    </style>
<?php get_header(); // add header ?>
    <!-- Begin Content -->
    <div id="main-container" class="container">
        <div class="margin-bottom-20">
        </div>
        <div id="breadcrumb-ads-links">
            <div id="breadcrumb">
                <div class="btn-group btn-breadcrumb">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="Home" class="btn btn-default">Home</a>
                    <span class="btn btn-default"><?php the_title(); ?></span>
                </div>
            </div>
        </div>
        <div id="main-content" class="row">
            <div id="main-content-before-wrapper" class="col-md-12 col-lg-12">
                <div id="main-content-wrapper" class="row">
                    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                    <div id="content">
                        <div id="last-updates">
                            <h1 itemprop="name" class="page-title"><?php the_title(); ?></h1>
                            <!--start kontent -->
                            <div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
                                <div class="entry">
                                    <!--start kontent -->
                                    <div class="btnt-sitemap">
                                        <?php
                                        // Add categories you'd like to exclude in the exclude here
                                        $learnedia_cats = get_categories('exclude=');
                                        foreach ($learnedia_cats as $learnedia_cat) {
                                        $learnedia_posts_by_slug = array(
                                            'category_name'    => $learnedia_cat->slug,
                                            'exclude'          => '', // enter the ID or comma-separated list of page IDs to exclude
                                            'numberposts'      => '10' // number of posts to show, default value is 5
                                        );
                                        $learnedia_posts_array = get_posts( $learnedia_posts_by_slug );
                                        echo "<div class=\"btnt-toc-wrap\">";
                                        echo '<div class="btnt-cat">'.$learnedia_cat->cat_name.'</div>';
                                        echo '<ul class="btnt-toc">';
                                        foreach ($learnedia_posts_array as $learnedia_post){ ?>
                                            <li>
                                                <div class="toc-date"> </div>
                                                <div class="btnt-icon">
                                                </div>
                                                <span class="btnt-post">
                                                    <a href="<?php echo get_permalink($learnedia_post); ?>"><?php echo get_the_title($learnedia_post); ?></a>
                                                </span>
                                            </li>
                                        <?php } ?>
                                        </ul>
                                    </div>
                                    <?php } ?>
                                    <div class="btnt-toc-wrap">
                                        <div class="btnt-cat">Pages</div>
                                        <ul class="btnt-toc">
                                            <li>
                                                <div class="toc-date"> </div>
                                                <div class="btnt-icon">
                                                </div>
                                                <span class="btnt-post">
                                                    <a href="/privacy/">Privacy Policy</a>
                                                </span>
                                            </li>
                                            <li>
                                                <div class="toc-date"> </div>
                                                <div class="btnt-icon">
                                                </div>
                                                <span class="btnt-post">
                                                    <a href="/sitemap/">Sitemap</a>
                                                </span>
                                            </li>
                                            <li>
                                                <div class="toc-date"> </div>
                                                <div class="btnt-icon">
                                                </div>
                                                <span class="btnt-post">
                                                    <a href="/contact/">Contact</a>
                                                </span>
                                            </li>
                                            <li>
                                                <div class="toc-date"> </div>
                                                <div class="btnt-icon">
                                                </div>
                                                <span class="btnt-post">
                                                    <a href="/about/">About Us</a>
                                                </span>
                                            </li>
                                            <li>
                                                <div class="toc-date"> </div>
                                                <div class="btnt-icon">
                                                </div>
                                                <span class="btnt-post">
                                                    <a href="/dmca/">DMCA</a>
                                                </span>
                                            </li>
                                            <li>
                                                <div class="toc-date"> </div>
                                                <div class="btnt-icon">
                                                </div>
                                                <span class="btnt-post">
                                                    <a href="/report/">Report</a>
                                                </span>
                                            </li>
                                            <noscript>
                                                <?php
                                                $lookfor = array('<li','</li>');
                                                $replacewith = array('<span', '</span>');
                                                $lookfor1 = array('page_item','');
                                                $replacewith1 = array('btnt-post', '');
                                                $args = array(
                                                    'echo'          => 0,
                                                    'sort_column'   => 'menu_order',
                                                    'title_li'      => __('')
                                                );
                                                $output = wp_list_pages( $args );
                                                echo str_replace($lookfor,$replacewith,$output); ?>
                                            </noscript>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div><!-- end #entry -->
            <style>
                #breadcrumbiblog1 {
                    padding:5px 5px 5px 0px; margin: 0px 0px 15px 0px; font-size:90%; line-height: 1.4em; border-bottom:3px double #eee;
                }
                /* Breadcrumb */
                #breadcrumbiblog{background:#fff;line-height:1.2em;width:auto;overflow:hidden;margin:0;padding:10px 0;border-top:1px solid #dedede;border-bottom:1px solid #dedede;font-size:80%;color:#888;font-weight:400;text-overflow:ellipsis;-webkit-text-overflow:ellipsis;white-space:nowrap}
                #breadcrumbiblog a{display:inline-block;text-decoration:none;transition:all .3s ease-in-out;color:#666;font-weight:400}
                #breadcrumbiblog a:hover{color:#11589D}
                #breadcrumbiblog svg{width:16px;height:16px;vertical-align:-4px}
                #breadcrumbiblog svg path{fill:#666}
                }
            </style>
            <div id="breadcrumbiblog">
                <?php if (function_exists('breadcrumbsX')) breadcrumbsX(); ?>
            </div>
        </div><!-- end .post -->
        </article>
    </div><!-- end .wrap-fullwidth -->
<?php get_footer(); // add footer  ?>