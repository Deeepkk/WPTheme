<div class="desc">
    <div class="post-tab">
        <input checked="checked" id="tab1" type="radio" name="apkdonetab" />
        <input id="tab2" type="radio" name="apkdonetab" />
        <?php if (get_post_meta( $post->ID, 'wp_whatnews_GP', true )) { ?><input id="tab3" type="radio" name="apkdonetab" /><?php } else { ?><?php } ?>
        <nav>
            <ul>
                <li class="tab1"> <label for="tab1">Version</label></li>
                <li class="tab2"> <label for="tab2">Description</label></li>
                <?php if (get_post_meta( $post->ID, 'wp_whatnews_GP', true )) { ?><li class="tab3"> <label for="tab3">Whats New</label></li><?php } else { ?><?php } ?>
            </ul>
        </nav>
        <section>
            <div class="tab1">
                <h3 class="h3info">Additional Information</h3>
                <section class="app-info-body">
                    <div>
                        <div> <b style="font-weight: bold">Genres</b></div>
                        <div> <?php
                            $i = 0;
                            foreach((get_the_category()) as $cat) {
                                echo '<a class="label" href="'.get_category_link($cat->cat_ID).'">' . $cat->cat_name . '</a>';
                                if (++$i == 1) break;
                            }
                            ?>
                        </div>
                    </div>
                    <div>
                        <div> <b style="font-weight: bold">Version</b></div>
                        <?php
                        $version = get_post_meta( $post->ID, 'wp_version_GP', true );
                        $versionX1 = get_post_meta( $post->ID, 'wp_version_GP', true );
                        $versionX = '-';
                        if ( $version === FALSE or $version == '' ) $version = $versionX;
                        ?>
                        <div> <?php echo $version; ?></div>
                    </div>
                    <div>
                        <div> <b style="font-weight: bold">Developer</b></div>
						<?php if (get_option('wp_developers_GP', 'developer')) { ?>
						<?php
						global $post;
						$developer = get_option('wp_developers_GP', 'developer'); 
						$terms = wp_get_post_terms($post->ID, $developer);
						if ($terms) {
							$output = array();
							foreach ($terms as $term) {
								$output[] = '<a href="' .get_term_link( $term->slug, $developer) .'" title="Developer by ' .$term->name .'">' .$term->name .'</a>';
							}
							echo join( ', ', $output );	}
						?>                        
                        <div> <?php echo $developers; ?></div>
						   <?php } else { ?>
							<?php
                            $developersx1 = get_post_meta( $post->ID, 'wp_developers_GP', true );                            
                            ?>
						<div> <?php echo $developersx1 ?></div>
						<?php } ?>
   
                    </div>
                    <div>
                        <div> <b style="font-weight: bold">Requires</b></div>
                        <?php
                        $requires = get_post_meta( $post->ID, 'wp_requires_GP', true );
                        $requiresX1 = get_post_meta( $post->ID, 'wp_requires_GP', true );
                        $requiresX = '-';
                        if ( $requires === FALSE or $requires == '' ) $requires = $requiresX;
                        ?>
                        <div>Android <?php echo $requires; ?></div>
                        <span itemprop="operatingSystem" style='display:none'>Android </span>
                        <span itemprop="softwareRequirements" style='display:none'>Android <?php echo $requires; ?></span>
                        <span itemprop="applicationCategory" content="<?php
                        $i = 0;
                        foreach((get_the_category()) as $cat) {
                            echo '' . $cat->cat_name . '';
                            if (++$i == 1) break;
                        }
                        ?> " style='display:none'><?php
                            $i = 0;
                            foreach((get_the_category()) as $cat) {
                                echo '' . $cat->cat_name . '';
                                if (++$i == 1) break;
                            }
                            ?> 
							</span>
                    </div>
                    <?php
                    $sizes = get_post_meta( $post->ID, 'wp_sizes', true );
                    $sizesX1 = get_post_meta( $post->ID, 'wp_sizes', true );
                    $sizesX = '-';
                    if ( $sizes === FALSE or $sizes == '' ) $sizes = $sizesX;
                    ?>
                    <?php if (get_post_meta( $post->ID, 'wp_sizes', true )) { ?>
                        <div>
                            <div> <b style="font-weight: bold">Size</b>
                            </div>
                            <div> <?php echo $sizes; ?></div>
                        </div>
                    <?php } else { ?><?php } ?>
                    <?php if (get_post_meta( $post->ID, 'wp_mods', true )) { ?>
                        <div>
                            <div> <b style="font-weight: bold">MOD Features</b>
                            </div>
                            <?php
                            $wp_mods = get_post_meta( $post->ID, 'wp_mods1', true );
                            $wp_mods1 = get_post_meta( $post->ID, 'wp_mods', true );
                            if ( $wp_mods === FALSE or $wp_mods == '' ) $wp_mods = $wp_mods1;
                            ?>
                            <div>
                                <?php echo $wp_mods ?>
                            </div>
                        </div>
                    <?php } else { ?><?php } ?>
                    <div>
                        <div> <b style="font-weight: bold">Updated</b>
                        </div>
                        <?php
                        $updates = get_post_meta( $post->ID, 'wp_updates_GP', true );
                        $updatesX1 = get_post_meta( $post->ID, 'wp_updates_GP', true );
                        $updatesX = '-';
                        if ( $updates === FALSE or $updates == '' ) $updates = $updatesX;
                        ?>
                        <div> <?php echo $updates; ?></div>
                        <span itemprop="datePublished" style='display:none'><?php echo $updates; ?></span>
                    </div>
                    <div>
                        <div><b style="font-weight: bold">Get it on</b></div>
                        <div><a title="Get <?php echo esc_html( get_post_meta( $post->ID, 'wp_title_GP', true ) ); ?> on google play" rel="nofollow noreferrer" href="https://play.google.com/store/apps/details?id=<?php echo esc_html( get_post_meta( $post->ID, 'wp_GP_ID', true ) ); ?>&hl=en" target="_blank"><img class='googleplayicon' alt="Get <?php echo esc_html( get_post_meta( $post->ID, 'wp_title_GP', true ) ); ?> for Free on Google Play" src="<?php echo get_template_directory_uri(); ?>/assetss/img/gp.png" height="14" width="66"></a></div>
                    </div>
					<div><div> <b style="font-weight: bold">Read</b>
                            </div>
                            <?php global $opt_themes; $fakees = mt_rand(500,9999); if($opt_themes['aktif_fake_views']) { ?>
            
               <!--<?php echo numToKs($fakees); ?>--> <?php echo $fakees; ?> views
            
            <?php } else { ?>
            <div><?php ex_themes_set_post_view_(); ?><?= ex_themes_get_post_view_(); ?> views</div>
            <?php } ?>
                        </div>
                    <div itemprop="aggregateRating" itemscope itemtype="https://schema.org/AggregateRating" style='display:none!important'>
                        <span itemprop="ratingValue" style='display:none'><?php echo esc_html( get_post_meta( $post->ID, 'wp_rated_GP', true ) ); ?></span> ( <span itemprop="ratingCount" style='display:none'><?php echo mt_rand(60,985); ?></span> ratings )
                    </div>
                    <div itemprop="offers" itemscope itemtype="https://schema.org/Offer" style='display:none!important'>
                        Price: $<span itemprop="price">0</span>
                        <meta itemprop="priceCurrency" content="USD" />
                    </div>
                    <span itemprop="author" itemscope itemtype="https://schema.org/Person" style='display:none!important'>
									<span itemprop="name" ><?php the_author(); ?></span>
									<span itemprop="datePublished" content="<?php the_time('l, F jS, Y') ?>" class="p2TkOb"><?php the_time('l, F jS, Y') ?></span>
									<span itemprop="reviewBody">
									<?php echo esc_html( get_post_meta( $post->ID, 'wp_title_GP', true ) ); ?> is the most famous version in the <?php echo esc_html( get_post_meta( $post->ID, 'wp_title_GP', true ) ); ?> series of publisher <?php echo esc_html( get_post_meta( $post->ID, 'wp_developers_GP', true ) ); ?>.
									</span>
									</span>
                </section>
                <?php ex_themes_adv_single_page_2(); ?>
                <br>
                <div class="abuttons"> <a href="<?php the_permalink() ?>download/" class="abutton is-success" rel="nofollow" title="">Download APK</a>
                </div>
                <?= ex_themes_blogs_shares_($content1); ?>
            </div>
            <div class="tab2">
                <div id="ftwp-postcontent kontents" class="kontents" >
                    <p style='display:none'>
                        <img class="size-full wp-image-28463 aligncenter" src="<?php global $opt_themes; if($opt_themes['ex_themes_thumbnails_gpstore_active_']) { ?><?php echo $thumbnails; ?>=w300-rw<?php } else { ?><?php if (has_post_thumbnail()) { ?><?php $image_id = get_post_thumbnail_id(); $image_url = wp_get_attachment_image_src($image_id,'full', true); echo $image_url[0]; ?><?php } else { ?><?php echo get_template_directory_uri(); ?>/assetss/img/lazy.png<?php } ?><?php } ?>" data-spai="1" alt="<?php echo esc_html( get_post_meta( $post->ID, 'wp_title_GP', true ) ); ?> poster" sizes="(max-width: 1280px) 100vw, 1280px" data-spai-upd="300" width="300" height="300">
                    </p>
                    <style type="text/css">#gallery-3{margin:auto}#gallery-3 .gallery-item{float:left;margin-top:10px;text-align:center;width:33%}#gallery-3 img{border:2px solid #cfcfcf}#gallery-3 .gallery-caption{margin-left:0}</style>
                    <noscript>
					<div id="gallery-3" class="gallery galleryid-28459 gallery-columns-3 gallery-size-medium" style="dispaly:none">
                        <?php if (get_post_meta( $post->ID, 'wp_images_GP', true )) { ?>
                            <?php
                            $datos_imagenes = get_post_meta(get_the_ID(), 'wp_images_GP', true);
                            $i = 0;
                            if(count($datos_imagenes)>3){
                                foreach($datos_imagenes as $elemento) { ?>
                                    <dl class="gallery-item">
                                        <dt class="gallery-icon portrait"> <img src="<?php echo (!empty($datos_imagenes[$i])) ? $datos_imagenes[$i] : ''; ?>" data-spai="1" class="attachment-medium size-medium" title="<?php echo esc_html( get_post_meta( $post->ID, 'wp_title_GP', true ) ); ?> screen <?php echo $i; ?>"  alt="<?php echo esc_html( get_post_meta( $post->ID, 'wp_title_GP', true ) ); ?> screen <?php echo $i; ?>" data-spai-upd="212" width="226" height="402">
                                        </dt>
                                    </dl>
                                    <?php if (++$i == 3) break; } ?>
                            <?php } else { for($i=0;$i<3;$i++): ?>
                            <?php endfor; ?>
                            <?php } ?>
                        <?php } else { ?>
                        <?php } ?>
                        <br style="clear: both">
                    </div>
					</noscript>
                    <?php
                    if ( have_posts() ) : while ( have_posts() ) : the_post();
                        the_content();
                    endwhile;
                    endif;
                    ?>
                </div>
                <div style="padding: 1px 20px; text-align: center;">
                    <a class="btn-download" style="color: #fff!important;" href="<?php the_permalink() ?>download/" rel="nofollow">Download Now</a>
                </div>
                <?= ex_themes_blogs_shares_($content1); ?>
            </div>
            <style>.kontents p{margin-bottom:20px!important}.kontents b{border-bottom:2px solid lavender!important}.kontents i{border-bottom:2px solid lavender!important;font-weight:bolder}</style>
            <?php
            $wp_whatnews_GP = get_post_meta( $post->ID, 'wp_whatnews_GP1', true );
            $wp_whatnews_GP1 = get_post_meta( $post->ID, 'wp_whatnews_GP', true );
            if ( $wp_whatnews_GP === FALSE or $wp_whatnews_GP == '' ) $wp_whatnews_GP = $wp_whatnews_GP1;
            ?>
            <?php if (get_post_meta( $post->ID, 'wp_whatnews_GP', true )) { ?>
                <div class="tab3">
                    <div style="padding: 5px 0px 30px; ">
                        <?php echo $wp_whatnews_GP ?>
                    </div>
                    <div class="clearfix"></div>
                </div>
            <?php } else { ?><?php } ?>
        </section>
    </div>
    <div class="clearfix"></div>
</div>
