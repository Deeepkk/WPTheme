<?php 
global $wpdb, $post, $wp_query;
?>
<h3 class="h3info">Additional Information</h3>
<section class="app-info-body">
    <div>
        <div>
            <b style="font-weight: bold">Genres</b>
        </div>
        <div>
            <?php
            $i = 0;
            foreach((get_the_category()) as $cat) {
                echo '<a class="label" href="'.get_category_link($cat->cat_ID).'">' . $cat->cat_name . '</a>';
                if (++$i == 1) break;
            }
            ?>
        </div>
    </div>
    <div>
        <div>
            <b style="font-weight: bold">Version</b>
        </div>
        <?php
        $version = get_post_meta( $post->ID, 'wp_version_GP', true );
        $versionX1 = get_post_meta( $post->ID, 'wp_version_GP', true );
        $versionX = '-';
        if ( $version === FALSE or $version == '' ) $version = $versionX;
        ?>
        <div> <?php echo $version; ?></div>
    </div>
    <div>
        <div>
            <b style="font-weight: bold">Developer</b>
        </div>
      
						<?php if (get_option('wp_developers_GP', 'developer')) { ?>
						<?php
						global $post;
						$developer = get_option('wp_developers_GP', 'developer'); 
						$terms = wp_get_post_terms($post->ID, $developer);
						if ($terms) {
							$output = array();
							foreach ($terms as $term) {
								$output[] = '<a href="' .get_term_link( $term->slug, $developer) .'" title="Developer by ' .$term->name .'">' .$term->name .'</a>';
							}
							echo join( ', ', $output );	}
						?>                        
                        <div> <?php echo $developers; ?></div>
						   <?php } else { ?>
							<?php
                            $developersx1 = get_post_meta( $post->ID, 'wp_developers_GP', true );                            
                            ?>
						<div> <?php echo $developersx1 ?></div>
						<?php } ?>
         
    </div>
    <div>
        <div>
            <b style="font-weight: bold">Requires</b>
        </div>
        <?php
        $requires = get_post_meta( $post->ID, 'wp_requires_GP', true );
        $requiresX1 = get_post_meta( $post->ID, 'wp_requires_GP', true );
        $requiresX = '-';
        if ( $requires === FALSE or $requires == '' ) $requires = $requiresX;
        ?>
        <div> Android <?php echo $requires; ?></div>
    </div>
    <?php
    $sizes = get_post_meta( $post->ID, 'wp_sizes', true );
    $sizesX1 = get_post_meta( $post->ID, 'wp_sizes_GP', true );
    $sizesX = '-';
    if ( $sizes === FALSE or $sizes == '' ) $sizes = $sizesX;
    ?>
    <?php if (get_post_meta( $post->ID, 'wp_sizes', true )) { ?>
        <div>
            <div> <b style="font-weight: bold">Size</b>
            </div>
            <div> <?php echo $sizes; ?> </div>
        </div>
    <?php } else { ?><?php } ?>
    <?php if (get_post_meta( $post->ID, 'wp_mods', true )) { ?>
        <div>
            <div> <b style="font-weight: bold">MOD Features</b>
            </div>
            <?php
            $wp_mods = get_post_meta( $post->ID, 'wp_mods1', true );
            $wp_mods1 = get_post_meta( $post->ID, 'wp_mods', true );
            if ( $wp_mods === FALSE or $wp_mods == '' ) $wp_mods = $wp_mods1;
            ?>
            <div>
                <?php echo $wp_mods ?>
            </div>
        </div>
    <?php } else { ?><?php } ?>
    <div>
        <div>
            <b style="font-weight: bold">Updated</b>
        </div>
        <?php
        $updates = get_post_meta( $post->ID, 'wp_updates_GP', true );
        $updatesX1 = get_post_meta( $post->ID, 'wp_updates_GP', true );
        $updatesX = '-';
        if ( $updates === FALSE or $updates == '' ) $updates = $updatesX;
        ?>
        <div> <?php echo $updates; ?></div>
    </div>
</section>