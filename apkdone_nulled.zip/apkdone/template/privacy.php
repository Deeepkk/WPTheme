<?php
/* 
Template Name: Template - Privacy Policy
*/
?>
<?php
###### https://www.geeksforgeeks.org/php-str_replace-function/
###### PHP | str_replace() Function 
###### Input string 
$url = get_bloginfo('url');
###### using str_replace() function 
$urls = str_replace('http://', '', $url);
$linkX = get_bloginfo('url');;
$parse = parse_url($linkX);
$urls = $parse['host'];
//$urls = str_replace('https://', '', $url);
$datePublished = mysql2date( DATE_W3C, $post->post_date, false );
$dateModified = mysql2date( DATE_W3C, $post->post_modified_gmt, false );
$emailX = get_bloginfo('admin_email');
$namesX = get_bloginfo('name');
?>
<?php
$post_date = get_the_date( 'l, F j, Y' );
$post_time = get_the_date( 'g:i A' );
?>
<?php get_header(); // add header ?>
<div class="wrap post-<?php the_title(); ?>">
<div class="single page page-<?php the_ID(); ?>">
    <div class="container">
        <div class="columns">
            <div class="column is-9">
                <nav class="breadcrumb" aria-label="breadcrumb_items">
                    <span>
                        <span><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a> »
                            <span class="breadcrumb_last" aria-current="page"><?php the_title(); ?></span>
                        </span>
                    </span>
                </nav>
                <article class="is-large">
                    <h1 itemprop="name" ><?php the_title(); ?></h1>
                </article>
                <br>
          
                    <div class="desc">
                        <!--start kontent -->
                        <p>If you require any more information or have any questions about our privacy policy, please feel free to contact us by email at <i class="mark"><a href="//<?php echo $urls; ?>/contact" title="contact to <?php echo get_bloginfo('admin_email'); ?>" ><?php echo get_bloginfo('admin_email'); ?></a></i>.</p>
                        <br>
                        <p>At <strong><?php echo $urls; ?></strong> we consider the privacy of our visitors to be extremely important. This privacy policy document describes in detail the types of personal information is collected and recorded by <strong><?php echo $urls; ?></strong> and how we use it.</p>
                        <br>
                        <p><b>Log Files</b><br>
                            <i class="hurufbesar">L</i>ike many other Web sites, <strong><?php echo $urls; ?></strong> makes use of log files. These files merely logs visitors to the site &#8211; usually a standard procedure for hosting companies and a part of hosting services&#8217;s analytics. The information inside the log files includes internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date/time stamp, referring/exit pages, and possibly the number of clicks. This information is used to analyze trends, administer the site, track user&#8217;s movement around the site, and gather demographic information. IP addresses, and other such information are not linked to any information that is personally identifiable.</p>
                        <br>
                        <p><b>Cookies and Web Beacons</b>
                            <br>
                            <strong><?php echo $urls; ?></strong> uses cookies to store information about visitors&#8217; preferences, to record user-specific information on which pages the site visitor accesses or visits, and to personalize or customize our web page content based upon visitors&#8217; browser type or other information that the visitor sends via their browser.</p>
                        <br>
                        <p><b>DoubleClick DART Cookie</b></p>
                        <p>→ Google, as a third party vendor, uses cookies to serve ads on <?php echo $urls; ?>.
                            <br>
                            → Google&#8217;s use of the DART cookie enables it to serve ads to our site&#8217;s visitors based upon their visit to <strong><?php echo $urls; ?></strong> and other sites on the Internet.
                            <br>
                            → Users may opt out of the use of the DART cookie by visiting the Google ad and content network privacy policy at the following URL &#8211; <a title="Opt out of the Dart Cookie" href="http://www.google.com/privacy_ads.html">http://www.google.com/privacy_ads.html</a></p>
                        <br>
                        <p><b>Our Advertising Partners</b>
                            <br>
                            Some of our advertising partners may use cookies and web beacons on our site. Our advertising partners include &#8230;&#8230;.</p>
                        <ul>
                            <li>Other</li>
                        </ul>
                        <p><em>While each of these advertising partners has their own Privacy Policy for their site, an updated and hyperlinked resource is maintained here: <a href="//<?php echo $urls; ?>/privacy-policy">Privacy Policies</a>.
                                <br>
                                You may consult this listing to find the privacy policy for each of the advertising partners of <strong><?php echo $urls; ?></strong>.</em></p>
                        <br>
                        <p>These third-party ad servers or ad networks use technology in their respective advertisements and links that appear on <strong><?php echo $urls; ?></strong> and which are sent directly to your browser. They automatically receive your IP address when this occurs. Other technologies (such as cookies, JavaScript, or Web Beacons) may also be used by our site&#8217;s third-party ad networks to measure the effectiveness of their advertising campaigns and/or to personalize the advertising content that you see on the site.</p>
                        <br>
                        <p><strong><?php echo $urls; ?></strong> has no access to or control over these cookies that are used by third-party advertisers.</p>
                        <br>
                        <p><b>Third Party Privacy Policies</b>
                            <br>
                            You should consult the respective privacy policies of these third-party ad servers for more detailed information on their practices as well as for instructions about how to opt-out of certain practices. <strong><?php echo $urls; ?></strong>&#8217;s privacy policy does not apply to, and we cannot control the activities of, such other advertisers or web sites. You may find a comprehensive listing of these privacy policies and their links here: <a title="Privacy Policy Links" href="//<?php echo $urls; ?>/privacy-policy">Privacy Policy Links</a>.</p>
                        <br>
                        <p>If you wish to disable cookies, you may do so through your individual browser options. More detailed information about cookie management with specific web browsers can be found at the browsers&#8217; respective websites.  </p>
                        <br>
                        <p><strong>Children&#8217;s Information</strong><br />
                            We believe it is important to provide added protection for children online. We encourage parents and guardians to spend time online with their children to observe, participate in and/or monitor and guide their online activity.
                            <br>
                            <strong><?php echo $urls; ?></strong> does not knowingly collect any personally identifiable information from children under the age of 13. If a parent or guardian believes that <strong><?php echo $urls; ?></strong> has in its database the personally-identifiable information of a child under the age of 13, please contact us immediately (using the contact in the first paragraph) and we will use our best efforts to promptly remove such information from our records.</p>
                        <br>
                        <p><b>Online Privacy Policy Only</b>
                            <br>
                            This privacy policy applies only to our online activities and is valid for visitors to our website and regarding information shared and/or collected there.
                            <br>
                            This policy does not apply to any information collected offline or via channels other than this website.</p>
                        <br>
                        <p><b>Consent</b>
                            <br>
                            By using our website, you hereby consent to our privacy policy and agree to its terms.</p>
                        <br>
                        <p><b>Update</b><br />
                            <?php
                            $post_date = get_the_date( 'l, F j, Y' );
                            $post_time = get_the_date( 'g:i A' );
                            ?>
                            This Privacy Policy was last updated on: <?php echo $post_date; ?> at <?php echo $post_time; ?></p>
                        <br>
                        <p><em>Should we update, amend or make any changes to our privacy policy, those changes will be posted here.</em></p>
                        <!--end kontent -->
                    </div>
 
                <div class="clearfix">
                </div>
            </div>
            <div class="column is-3 sidebar">
                <?php get_sidebar(); ?>
            </div>
        </div>
        <style>
            #breadcrumbiblog1 {
                padding:5px 5px 5px 0px; margin: 0px 0px 15px 0px; font-size:90%; line-height: 1.4em; border-bottom:3px double #eee;
            }
            /* Breadcrumb */
            #breadcrumbiblog{background:#fff;line-height:1.2em;width:auto;overflow:hidden;margin:0;padding:10px 0;border-top:1px solid #dedede;border-bottom:1px solid #dedede;font-size:80%;color:#888;font-weight:400;text-overflow:ellipsis;-webkit-text-overflow:ellipsis;white-space:nowrap}
            #breadcrumbiblog a{display:inline-block;text-decoration:none;transition:all .3s ease-in-out;color:#666;font-weight:400}
            #breadcrumbiblog a:hover{color:#11589D}
            #breadcrumbiblog svg{width:16px;height:16px;vertical-align:-4px}
            #breadcrumbiblog svg path{fill:#666}
            }
        </style>
        <div id="breadcrumbiblog">
            <?php if (function_exists('breadcrumbsX')) breadcrumbsX(); ?>
        </div>
    </div>
 
<?php get_footer(); ?>