<?php
/* 
Template Name: Template - About
*/
include "../../../wp-load.php";
?>
<?php
###### https://www.geeksforgeeks.org/php-str_replace-function/
###### PHP | str_replace() Function 
###### Input string 
$url = get_bloginfo('url');
###### using str_replace() function 
$urls1 = str_replace('http://', '', $url);

$linkX = get_bloginfo('url');
$emailX = get_bloginfo('admin_email');
$namesX = get_bloginfo('name');
$parse = parse_url($linkX);
$urls = $parse['host'];

//$urls = str_replace('https://', '', $url); 
$datePublished = mysql2date( DATE_W3C, $post->post_date, false );
$dateModified = mysql2date( DATE_W3C, $post->post_modified_gmt, false );
?>
<?php
$post_date = get_the_date( 'l, F j, Y' );
$post_years = get_the_date( 'Y' );
$post_time = get_the_date( 'g:i A' );
?>

<?php get_header(); // add header ?>


<div class="wrap post-<?php the_title(); ?>">
<div class="single page page-<?php the_ID(); ?>">
    <div class="container">
        <div class="columns">
            <div class="column is-9">
                <nav class="breadcrumb" aria-label="breadcrumb_items"> <span>
<span>
<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a> » <span class="breadcrumb_last" aria-current="page"><?php the_title(); ?></span>
</span>
</span>
                </nav>

                <article class="is-large">
                    <h1 itemprop="name" ><?php the_title(); ?></h1>
                </article>
                <br>


                <div class="desc">


                    <!--start kontent -->
                    <p style="text-align: justify;"><strong><?php echo $urls; ?></strong> is a non-profit website founded by us who are passionate about technology. By the end of <?php echo$post_years; ?>, we had the idea of setting up a website to share our knowledge about games, applications for Android and everything related to technology. And then, <?php echo $urls; ?> was born.</p>
                    <br>
                    <p style="text-align: justify;"><strong>“Sharing for free and forever!”</strong> That’s our goal right from the develop this website.  Here, we share to you the popular applications and games on Android. Besides, we also bring their mods. You can download and install them completely free of charge. We do not require you to provide any information or permissions.</p>
                    <br>
                    <p style="text-align: justify;">If you have good ideas, or you want to join us for website development, do not hesitate to <a href="/contact/">contact us</a>. You are always welcome here.</p>
                    <pre>Send your email to: <a href="mailto:<?php echo get_bloginfo('admin_email'); ?>"><?php echo get_bloginfo('admin_email'); ?></a></pre>
                    <h4>Get more <span style="color: #ff6600;"><?php echo get_bloginfo('name'); ?></span>
                    </h4>

                    <ul>
                        <?php global $opt_themes; if($opt_themes['facebook_url']) { ?><li>
                            <strong>Facebook</strong>: <a href="<?php echo $opt_themes['facebook_url']; ?>"><?php echo $opt_themes['facebook_url']; ?></a>
                            </li><?php } ?>
                        <?php global $opt_themes; if($opt_themes['youtube_url']) { ?><li>
                            <strong>Youtube</strong>:&nbsp;<a href="<?php echo $opt_themes['youtube_url']; ?>"><?php echo $opt_themes['youtube_url']; ?></a>
                            </li><?php } ?>
                        <?php global $opt_themes; if($opt_themes['twitter_url']) { ?><li>
                            <strong>Twitter</strong>: <a href="<?php echo $opt_themes['twitter_url']; ?>"><?php echo $opt_themes['twitter_url']; ?></a>
                            </li><?php } ?>
                        <?php global $opt_themes; if($opt_themes['instagram_url']) { ?><li>
                            <strong>Instagram</strong>: <a href="<?php echo $opt_themes['instagram_url']; ?>"><?php echo $opt_themes['instagram_url']; ?></a>
                            </li><?php } ?>
                    </ul>
                    <!--end kontent -->
                </div>


                <div class="clearfix">
                </div>
            </div>


            <div class="column is-3 sidebar">
                <?php get_sidebar(); ?>
            </div>


        </div>
        <style>
            #breadcrumbiblog1 {
                padding:5px 5px 5px 0px; margin: 0px 0px 15px 0px; font-size:90%; line-height: 1.4em; border-bottom:3px double #eee;
            }
            /* Breadcrumb */
            #breadcrumbiblog{background:#fff;line-height:1.2em;width:auto;overflow:hidden;margin:0;padding:10px 0;border-top:1px solid #dedede;border-bottom:1px solid #dedede;font-size:80%;color:#888;font-weight:400;text-overflow:ellipsis;-webkit-text-overflow:ellipsis;white-space:nowrap}
            #breadcrumbiblog a{display:inline-block;text-decoration:none;transition:all .3s ease-in-out;color:#666;font-weight:400}
            #breadcrumbiblog a:hover{color:#11589D}
            #breadcrumbiblog svg{width:16px;height:16px;vertical-align:-4px}
            #breadcrumbiblog svg path{fill:#666}
            }
        </style>
        <div id="breadcrumbiblog">
            <?php if (function_exists('breadcrumbsX')) breadcrumbsX(); ?>
        </div>
    </div>
 

<?php get_footer(); ?>