<?php
// My custom comments output html
function better_comments( $comment, $args, $depth ) {
    // Get correct tag used for the comments
    if ( 'div' === $args['style'] ) {
        $tag       = 'ol';
        $add_below = 'comment';
    } else {
        $tag       = 'ol';
        $add_below = 'div-comment';
    } ?>
    <div class="navigation">
        <div class="alignleft"></div>
        <div class="alignright"></div>
    </div>
    <<?php echo $tag; ?> class="commentlist">
    <?php
    // Switch between different comment types
    switch ( $comment->comment_type ) :
        case 'pingback' :
        case 'trackback' : ?>
            <div class="pingback-entry"><span class="pingback-heading"><?php esc_html_e( 'Pingback:', 'textdomain' ); ?></span> <?php comment_author_link(); ?></div>
            <?php break; default : if ( 'div' != $args['style'] ) { ?>
        <li class="comment even thread-even depth-1" id="comment-<?php comment_ID() ?>">
        <div id="div-comment-<?php comment_ID() ?>" class="comment-body">
            <div class="comment-author vcard"> <img alt="" src="<?php echo get_avatar_url($comment,$size='32',$default='".get_template_directory_uri();."/assetss/img/lazy.png' ); ?>" srcset="<?php echo get_avatar_url($comment,$size='32',$default='".get_template_directory_uri();."/assetss/img/lazy.png' ); ?>" class="avatar avatar-32 photo" width="32" height="32"> <?php printf(__('<cite class="fn">%s</cite> <span class="says">says:</span>'), get_comment_author_link()) ?>
            </div>
            <div class="comment-meta commentmetadata">
                <a > <?php
                    /* translators: 1: date, 2: time */
                    printf(
                        __( '%1$s', 'textdomain' ),
                        get_comment_date(),
                        get_comment_time()
                    ); ?> </a>
            </div>
            <p><?php comment_text(); ?>   </p>
            <div class="reply">
                <?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth'] ))); ?>
            </div>
        </div>
    <?php } ?>
        <?php if ( 'div' != $args['style'] ) { ?>
            </li>
            </ol>
        <?php }
        // IMPORTANT: Note that we do NOT close the opening tag, WordPress does this for us
        break;
    endswitch; // End comment_type check.
}
?>