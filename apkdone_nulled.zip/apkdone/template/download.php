<?php
function my_simple_crypt( $string, $action = 'e' ) {
    $secret_key = 'drivekey';
    $secret_iv = 'google';
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $key = hash( 'sha256', $secret_key );
    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
    if( $action == 'e' ) {
        $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
    }else if( $action == 'd' ){
        $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
    }
    return $output;
}
global $wpdb, $post, $wp_query;
$linkX = get_bloginfo('url'); $parse = parse_url($linkX); $watermark1 = $parse['host'];
$sizes = get_post_meta( $post->ID, 'wp_sizes', true );
$sizesX1 = get_post_meta( $post->ID, 'wp_sizes_GP', true );
$sizesX = 'Loading...';
if ( $sizes === FALSE or $sizes == '' ) $sizes = $sizesX;
$url1 = get_post_meta( $post->ID, 'wp_downloadlink', true ) ;
$postid = $wp_query->post->ID;
$dt_player	= get_post_meta($postid, 'repeatable_fields', true);
$updates = get_post_meta( $post->ID, 'wp_updates_GP', true );
$updatesX1 = get_post_meta( $post->ID, 'wp_updates_GP', true );
$updatesX = '-';
if ( $updates === FALSE or $updates == '' ) $updates = $updatesX;
$titleGPs = get_post_meta( $post->ID, 'wp_title_GP', true );
$titleGPsX1 = get_post_meta( $post->ID, 'wp_title_GP', true );
$titleGPsX = '-';
if ( $titleGPs === FALSE or $titleGPs == '' ) $titleGPs = $titleGPsX;
$idtitleGPs = get_post_meta( $post->ID, 'wp_GP_ID', true );
$idtitleGPsX1 = get_post_meta( $post->ID, 'wp_GP_ID', true );
$idtitleGPsX = '-';
if ( $idtitleGPs === FALSE or $idtitleGPs == '' ) $idtitleGPs = $idtitleGPsX;
get_header(); ?>

   <div class="wrap post-download">
	<div class="single single-download single-<?php the_ID(); ?>">
    <div class="container">
        <div class="columns">
            <div class="column is-9">
                <nav class="breadcrumb" aria-label="breadcrumb_items">
                    <a href="<?php echo home_url(); ?>" title="Home">Home</a> »
                    <span><?php echo get_the_category_list( '  »  ', '', $post->ID ); ?></span>  »
                    <span><a href="<?php the_permalink() ?>download/"><?php echo get_the_title(); ?></a></span> »
                    <span><a href="<?php the_permalink() ?>">Latest Version</span>
                </nav>
                <div id="breadcrumb" style='display:none'>
                    <div class="btn-group btn-breadcrumb" itemscope="" itemtype="http://schema.org/BreadcrumbList">
                        <span itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                            <a href="<?php echo home_url(); ?>" title="Home" class="btn btn-default" itemprop="item"><span itemprop="name">Home</span></a><meta itemprop="position" content="1"></span>
                        <span itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                            <a href="<?php the_permalink() ?>download/" title="Download" class="btn btn-default" itemprop="item"><span itemprop="name">Download</span></a>
                            <meta itemprop="position" content="2"></span>
                        <span class="btn btn-default"><?php echo get_the_title(); ?></span>
                    </div>
                    <!-- .breadcrumbs -->
                </div>
                <article>
                    <h1 class="post-title entry-title">Download <?php echo get_the_title(); ?></h1>
                </article>
                <div class="desc">
                    <?php get_template_part('template/loop/apk_info_download'); ?>
                    <br>
					<center><?php ex_themes_adv_download_page_(); ?></center>
					<div class="clearfix"></div>                    
                    <div class="tab-pane">                        
                        <div class="div">
                            <span style="padding: 10px 30px;font-size: 40px; display:block;text-align:center;"><?php global $opt_themes; if($opt_themes['timer_active_']) { ?> <?php echo $opt_themes['timer_fake_download']; ?><?php } else { ?>3<?php } ?></span>
                        </div>
                        <div class="div2" style="display:none;">
                            <nav class="download-body" id="download">
                                <?php
                                $downloadlink = get_post_meta(get_the_ID(), 'repeatable_fields', true);
                                if ($downloadlink) {
                                    foreach ($downloadlink as $k => $dw) { 
									$mask_link = my_simple_crypt($dw['url']); 
									$unmask_link = my_simple_crypt($dw['url'], 'd');
										?>
                                        <a href="<?php global $opt_themes; if($opt_themes['ex_themes_mask_link_']) { ?><?php the_permalink() ?>get/?urls=<?php echo (!empty($mask_link)) ? $mask_link : ''; ?>&names=<?php echo (!empty($dw['name'])) ? sanitize_title_with_dashes($dw['name']) : ''; ?>.apk<?php } else { ?><?php echo (!empty($dw['url'])) ? $dw['url'] : ''; ?><?php } ?>" rel="nofollow"  class="column app is-12" >
                                            <div><div class="file-icon" data-type="<?php echo $dw['tipes']; ?>"></div></div>
                                            <div><b><?php echo $dw['name']; ?></b>
                                                <p><?php if ($dw['sizes1']) { ?><span class="tag"><?php echo $dw['sizes1']; ?> &#9733;</span> &#8226; <?php } else { ?><?php echo $sizes; ?><?php } ?>
                                                    <?php if ($dw['dates']) { ?><span class="tag"> <i class="icon-dl"></i> <?php echo $dw['dates']; ?> </span> &#8226; <?php } else { ?><span class="tag"> <i class="icon-dl"></i> <?php the_time(); ?></span><?php } ?></p>
                                            </div></a>
                                    <?php } } else { ?>
                                    <?php
                                    $download3 = get_post_meta(get_the_ID(), 'wp_downloadlink2', true);
                                    $download2 = get_post_meta(get_the_ID(), 'wp_downloadlink', true);
                                    $namedownload2 = get_post_meta(get_the_ID(), 'wp_namedownloadlink', true);
                                    $namedownload3 = get_post_meta(get_the_ID(), 'wp_namedownloadlink2', true);
									$sizesr = get_post_meta( $post->ID, 'wp_sizes', true );
									$sizesX1 = get_post_meta( $post->ID, 'wp_sizes_GP', true );
									$sizesX = '-';
									if ( $sizesr === FALSE or $sizesr == '' ) $sizesr = $sizesX;
                                    $i = 0;
                                    if(count($download3)>0){
                                        foreach($download3 as $elemento) {
                                            $download3x1 = $download3[$i];
                                            $download31 = $download3[$i]; 
											$download32 = $download3[$i];
											$mask_link = my_simple_crypt($download3[$i]); 
											$unmask_link = my_simple_crypt($download3[$i], 'd');
                                            ?>
											
                                            <a href="<?php global $opt_themes; if($opt_themes['ex_themes_mask_link_']) { ?><?php the_permalink() ?>get/?urls=<?php echo (!empty($mask_link)) ? $mask_link : ''; ?>&names=<?php echo (!empty($namedownload3[$i])) ? sanitize_title_with_dashes($namedownload3[$i]) : ''; ?>.apk<?php } else { ?><?php echo (!empty($download31)) ? $download31 : ''; ?><?php } ?>" rel="nofollow"  class="column app is-12" ><div><div class="file-icon" data-type="apk"></div></div>
                                                <div><b><?php echo (!empty($namedownload3[$i])) ? $namedownload3[$i] : ''; ?></b><p><span class="tag"><?php echo $sizes; ?> &#9733;</span> &#8226; <span class="tag"> <i class="icon-dl"></i> <?php echo $updates; ?></span></p></div></a>
                                            <?php $i++; } ?>
                                    <?php } else {  ?>
                                        <a href="<?php echo (!empty($download2)) ? $download2 : ''; ?>" rel="nofollow" class="column app is-12" ><div><div class="file-icon" data-type="apk"></div></div>
                                            <div><b><?php echo (!empty($namedownload2)) ? $namedownload2 : 'Download Now'; ?></b><p><span class="tag"><?php echo $sizes; ?> &#9733;</span> &#8226; <span class="tag"> <i class="icon-dl"></i> <?php echo $updates; ?></span></p></div></a>
                                    <?php } ?>
                                <?php }  ?>
                                <?php global $opt_themes; if($opt_themes['aktif_ads_fake_download']) { ?>
                                    <a href="<?php global $opt_themes; if($opt_themes['aktif_ads_fake_download']) { ?> <?php echo $opt_themes['ads_fake_download']; ?><?php } else { ?><?php } ?>" rel="nofollow" class="column app is-12" >
                                        <div><div class="file-icon" data-type="apk"></div></div>
                                        <div><b><?php global $opt_themes; if($opt_themes['aktif_ads_fake_download']) { ?> <?php echo $opt_themes['title_fake_download']; ?><?php } else { ?><?php } ?></b>
                                            <p><span class="tag"><?php echo $sizes; ?> &#9733;</span> &#8226; <span class="tag"> <i class="icon-dl"></i> <?php echo $updates; ?></span></p>
                                        </div></a>
                                <?php } else { ?>
                                    <!-- put your code ads here-->
									<span style="text-align:center;display:block;">Original file on Google Play</span>
									<a href="https://play.google.com/store/apps/details?id=<?php echo $idtitleGPs; ?>" rel="nofollow" class="column app is-12" target="_blank"><div><div class="file-icon" data-type="apk"></div></div>
                                    <div><b>Download <?php echo get_the_title(); ?> ON Google play</b><p><span class="tag"><?php echo $sizes; ?>  </span> <span class="tag"> <i class="icon-dl"></i> <?php echo $updates; ?></span></p></div></a>
									<center><?php ex_themes_adv_download_page_2(); ?></center>
									<div class="clearfix"></div>
                                <?php } ?>
                            </nav>
                        </div>
						<center><?php ex_themes_adv_download_page_2(); ?></center>
                    </div>
                    <script language="javascript">
                        var timeout,interval
                        var threshold = <?php global $opt_themes; if($opt_themes['timer_active_']) { ?><?php echo $opt_themes['timer_fake_download']; ?>000<?php } else { ?>3000<?php } ?>;
                        var secondsleft=threshold;
                        window.onload = function()
                        {
                            startschedule();
                        }
                        function startChecking()
                        {
                            secondsleft-=1000;
                            document.querySelector(".div").innerHTML = "<span style=\"padding: 10px 30px;font-size: 40px; display:block;text-align:center;\">" + Math.abs((secondsleft/1000))+" </span>";
                            if(secondsleft == 0)
                            {
                                //document.getElementById("clickme").style.display="";
                                clearInterval(interval);
                                document.querySelector(".div").style.display="none";
                                document.querySelector(".div2").style.display="";
                            }
                        }
                        function startschedule()
                        {
                            clearInterval(interval);
                            secondsleft=threshold;
                            document.querySelector(".div").innerHTML = "<span style=\"padding: 10px 30px;font-size: 40px; display:block;text-align:center;\"> " + Math.abs((secondsleft/1000))+" </span>";
                            interval = setInterval(function()
                            {
                                startChecking();
                            },1500)
                        }
                        function resetTimer()
                        {
                            startschedule();
                        }
                    </script>
                    <h2>Download and Install FAQs</h2>
                    <div class="faq accordion">
                        <input id="handle0" name="collapse" type="checkbox" />
                        <div class="handle">
                            <h3><label for="handle0">How to install APK games or apps with OBB file <span class="angle">&#10095;</span></label></h3>
                        </div>
                           <div class="faq-content content">
                            <ol>
                                <li>You can open a ZIP file directly from the <a >ES File Explorer</a>.</li>
                                <li>Install APK file and do not run yet.</li>
                                <li>Place the OBB Data in the <strong>/SDCARD/Android/obb/</strong> file location and you are good to go</li>
                                <li>Start the games or apps again. Enjoy</li>
                            </ol>
                            <strong>Example</strong> : If you have <a ><?php echo $titleGPs; ?></a> games or apps and is installed in your external memory, then extract the OBB file to <strong><span style="color: #008000;">/SDCARD/Android/obb/<?php echo $idtitleGPs; ?></span></strong>. Ensure that the OBB file (<strong><span style="color: #ff0000;">main.156.<?php echo $idtitleGPs; ?>.obb</span></strong>) sits within the <strong><?php echo $idtitleGPs; ?></strong> folder.
                        </div>
                    </div>
                    <div style="clear:both;margin-bottom:5px;"></div>
                    <div class="faq accordion">
                        <input id="handle1" name="collapse" type="checkbox" />
                        <div class="handle">
                            <h3><label for="handle1">How to install APKs Bundle (Split APKs)? <span class="angle">&#10095;</span></label></h3>
                        </div>
                        <div class="faq-content content">
                            <ul>
                                <li>Install "<a rel="noopener noreferrer"><?php echo $watermark1; ?> Installer</a>" and open it.</li>
                                <li>Click "Install APKs" button and select all of the APK files in the APKs Bundle.</li>
                                <li>Click "Select" button to start the installation process.</li>
                            </ul>
                        </div>
                    </div>
                    <?= ex_themes_blogs_shares_($content1); ?>
                </div>
                <br style="clear:both;">                
                <style type="text/css">h2{margin-bottom:10px}.desc{padding-bottom:10px}.post-title{text-align:center;margin-bottom:10px}.download-body{border:2px solid #ededed;border-radius:5px;padding:10px;margin-bottom:10px}.download-body a.app{border-bottom:1px solid #ededed}.download-body a.app:last-child{border-bottom:0}.file-icon{width:27px;height:36px;background:#8ec155;position:relative;border-radius:2px;text-align:left;-webkit-font-smoothing:antialiased}.file-icon::before{display:block;content:"";position:absolute;top:0;right:0;width:0;height:0;border-bottom-left-radius:2px;border-width:5px;border-style:solid;border-color:#fff #fff #ffffff59 #ffffff59}.file-icon::after{display:block;content:attr(data-type);position:absolute;bottom:0;left:0;font-size:12px;color:#fff;text-transform:lowercase;width:100%;padding:2px;white-space:nowrap;overflow:hidden}.file-icon[data-type=zip]{background-color:#ffb229}span.angle{display:block;float:right;transform:rotate(90deg);-webkit-transform:rotate(90deg);-moz-transform:rotate(90deg);-ms-transform:rotate(90deg);-o-transform:rotate(90deg)}.accordion>input[type="checkbox"]{position:absolute;left:-100vw}.accordion .handle{margin:0;font-size:1.125em;line-height:1.2em}.accordion label{color:#333;cursor:pointer;font-weight:normal;padding:10px;padding-bottom:5px;padding-top:5px;background:#f5f5f5;display:block;border-radius:6px;border-left:5px solid #444}.accordion>input[type="checkbox"]:checked ~ .content{padding:15px;border:1px solid #e8e8e8;border-top-color:#e8e8e8;border-top-style:solid;border-top-width:1px;border-top:0;height:auto;overflow:visible;margin-bottom:5px;word-break:break-word;width:auto}.accordion>input[type="checkbox"]:checked ~ .handle span.angle{transform:rotate(-90deg);-webkit-transform:rotate(-90deg);-moz-transform:rotate(-90deg);-ms-transform:rotate(-90deg);-o-transform:rotate(-90deg)}.accordion .content{overflow-y:hidden;height:0;transition:height .3s ease;float:none!important}.app-info i{min-width:20px;color:green}.app-info-body{border-top:1px solid #e0e2e3;padding:15px 0}.app-info-body>div{padding:5px 0;border-bottom:1px solid #eaeaea}i.icon-dl{padding-right:20px}i.icon-dl:before{content:" ";background-image:url(<?php echo get_template_directory_uri();?>/assetss/img/ic_download_count.svg);width:24px;height:24px;position:absolute;background-size:13px;background-repeat:no-repeat;margin-top:3px}.abuttons.acategory .abutton:not(:last-child):not(.is-fullwidth){margin-right:0}.abuttons.acategory .abutton{width:50%;float:left;margin-bottom:0;border:0;border-bottom:1px solid #ededed;text-align:left;padding:5px 0}.acategory a i{display:inline-block;vertical-align:middle;width:30px;height:30px;border-radius:50%;margin-right:5px}.cat-icon.social{margin:0;margin-right:5px}.aapp a i{background:url(<?php echo get_template_directory_uri();?>/assetss/img/app-icon.png) no-repeat}.agame a i{background:url(<?php echo get_template_directory_uri();?>/assetss/img/game-icon2.png) no-repeat}.agame .action{background-position:0 0}.agame .adventure{background-position:0 -30px}.agame .arcade{background-position:0 -60px}.agame .board{background-position:0 -90px}.agame .card{background-position:0 -120px}.agame .casino{background-position:0 -150px}.agame .casual{background-position:0 -180px}.agame .educational{background-position:0 -210px}.agame .horror{background-position:0 -240px}.agame .music{background-position:0 -268px}.agame .offline-games{background-position:0 -297px}.agame .puzzle{background-position:0 -328px}.agame .racing{background-position:0 -358px}.agame .rpg{background-position:0 -400px}.agame .shooting{background-position:0 -418px}.agame .simulation{background-position:0 -448px}.agame .sports{background-position:0 -476px}.agame .strategy{background-position:0 -503px}.agame .fighting{background-position:0 -535px}.agame .golf-games{background-position:0 -565px}.agame .online{background-position:0 -595px}.agame .role-playing{background-position:0 -625px}.agame .survival{background-position:0 -655px}.aapp .family{background-position:0 -510px}.aapp .art-design{background-position:0 -540px}.aapp .auto-vehicles{background-position:0 -570px}.aapp .beauty{background-position:0 -600px}.aapp .books-reference{background-position:0 -630px}.aapp .business{background-position:0 -660px}.aapp .comic{background-position:0 -690px}.aapp .communication{background-position:0 -720px}.aapp .dating{background-position:0 -750px}.aapp .education{background-position:0 -780px}.aapp .entertainment{background-position:0 -810px}.aapp .events{background-position:0 -840px}.aapp .finance{background-position:0 -870px}.aapp .clear{background-position:0 -900px}.aapp .health-fitness{background-position:0 -930px}.aapp .house_and_home{background-position:0 -960px}.aapp .libraries-demo{background-position:0 -990px}.aapp .lifestyle{background-position:0 -1020px}.aapp .maps-navigation{background-position:0 -1050px}.aapp .medical{background-position:0 -1080px}.aapp .music-audio{background-position:0 -1110px}.aapp .news-magazines{background-position:0 -1140px}.aapp .parenting{background-position:0 -1170px}.aapp .personalization{background-position:0 -1200px}.aapp .photography{background-position:0 -1230px}.aapp .productivity{background-position:0 -1260px}.aapp .shopping{background-position:0 -1290px}.aapp .social{background-position:0 -1320px}.aapp .sports-apps{background-position:0 -1350px}.aapp .tools{background-position:0 -1380px}.aapp .travel-local{background-position:0 -1410px}.aapp .video-players-editors{background-position:0 -1440px}.aapp .weather{background-position:0 -1470px}#breadcrumbiblog1{padding:5px 5px 5px 0;margin:0 0 15px 0;font-size:90%;line-height:1.4em;border-bottom:3px double #eee}#breadcrumbiblog{background:#fff;line-height:1.2em;width:auto;overflow:hidden;margin:0;padding:10px 0;border-top:1px solid #dedede;border-bottom:1px solid #dedede;font-size:80%;color:#888;font-weight:400;text-overflow:ellipsis;-webkit-text-overflow:ellipsis;white-space:nowrap}#breadcrumbiblog a{display:inline-block;text-decoration:none;transition:all .3s ease-in-out;color:#666;font-weight:400}#breadcrumbiblog a:hover{color:#11589d}#breadcrumbiblog svg{width:16px;height:16px;vertical-align:-4px}#breadcrumbiblog svg path{fill:#666}}</style>
                <div class="clearfix"></div>
                <?php ex_themes_related_posts_(); ?>
				 <?php get_template_part('template/loop/comments'); ?>
            </div>
            <div class="column is-3 sidebar">
                <?php get_sidebar(); ?>
            </div>
        </div>
        <div id="breadcrumbiblog">
            <?php if (function_exists('breadcrumbsX')) breadcrumbsX(); ?>
        </div>
    </div>
    </section>
<?php get_footer(); ?>