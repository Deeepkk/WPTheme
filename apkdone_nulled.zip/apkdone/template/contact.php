<?php
/* 
Template Name: Template - Contact
*/
?>
<?php
###### https://www.geeksforgeeks.org/php-str_replace-function/
###### PHP | str_replace() Function 
###### Input string 
$url = get_bloginfo('url');
###### using str_replace() function 
$urls1 = str_replace('http://', '', $url);
$linkX = get_bloginfo('url');;
$parse = parse_url($linkX);
$urls = $parse['host'];
//$urls = str_replace('https://', '', $url);
$datePublished = mysql2date( DATE_W3C, $post->post_date, false );
$dateModified = mysql2date( DATE_W3C, $post->post_modified_gmt, false );
$emailX = get_bloginfo('admin_email');
$namesX = get_bloginfo('name');
?>
<?php
$post_date = get_the_date( 'l, F j, Y' );
$post_years = get_the_date( 'Y' );
$post_time = get_the_date( 'g:i A' );
?>
<?php get_header(); // add header ?>
<div class="wrap post-<?php the_title(); ?>">
<div class="single page page-<?php the_ID(); ?>">
    <div class="container">
        <div class="columns">
            <div class="column is-9">
                <nav class="breadcrumb" aria-label="breadcrumb_items">
				<span>
				<span><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a> »
				<span class="breadcrumb_last" aria-current="page"><?php the_title(); ?></span>
				</span>
				</span>
                </nav>
                <article class="is-large">
                    <h1 itemprop="name" ><?php the_title(); ?></h1>
                </article>
              
                    <div class="desc">
                        <?php
                        if(isset($_POST['submit'])){
                            $to = get_bloginfo('admin_email'); // this is your Email address
                            $from = $_POST['email']; // this is the sender's Email address
                            $first_name = $_POST['first_name'];
                            $subject = "Form submission";
                            $subject2 = "Copy of your form submission";
                            $message = $first_name . " wrote the following:" . "\n\n" . $_POST['message'];
                            $message2 = "Here is a copy of your message " . $first_name . "\n\n" . $_POST['message'];
                            $headers = "From:" . $from;
                            $headers2 = "From:" . $to;
                            mail($to,$subject,$message,$headers);
                            mail($from,$subject2,$message2,$headers2); // sends a copy of the message to the sender
                            echo "Mail Sent. Thank you " . $first_name . ", we will contact you shortly.";
                            // You can also use header('Location: thank_you.php'); to redirect to another page.
                        }
                        ?>
                        <h1>Contact Form Email</h1>
                        <p>If you want to contact us, please use form email at <?php echo get_bloginfo('admin_email'); ?></p>
                        <p>Topics that we accept include:</p>
                        <ul>
                            <li>Complain about copyright of your game on our website.</li>
                            <li>Report error of game or application.</li>
                            <li>Collaborate to share guest post on the website or distribute other digital content.</li>
                        </ul>
                        <p>We will respond to you as soon as possible. Wish you have a happy experience on our website!</p>
                        <form action="" method="post">
                            <p><input type="text" name="first_name" placeholder="Your Name" ></p>
                            <p><input type="text" name="email" placeholder="Email"></p>
                            <p><textarea rows="5" name="message" cols="30" placeholder="Message"></textarea></p>
                            <p><input type="submit" name="submit" value="Submit" class="btn btn-warning"> </p>
                        </form>
                    </div>
    
                <div class="clearfix">
                </div>
            </div>
            <div class="column is-3 sidebar">
                <?php get_sidebar(); ?>
            </div>
        </div>
        <style>
            #breadcrumbiblog1 {
                padding:5px 5px 5px 0px; margin: 0px 0px 15px 0px; font-size:90%; line-height: 1.4em; border-bottom:3px double #eee;
            }
            /* Breadcrumb */
            #breadcrumbiblog{background:#fff;line-height:1.2em;width:auto;overflow:hidden;margin:0;padding:10px 0;border-top:1px solid #dedede;border-bottom:1px solid #dedede;font-size:80%;color:#888;font-weight:400;text-overflow:ellipsis;-webkit-text-overflow:ellipsis;white-space:nowrap}
            #breadcrumbiblog a{display:inline-block;text-decoration:none;transition:all .3s ease-in-out;color:#666;font-weight:400}
            #breadcrumbiblog a:hover{color:#11589D}
            #breadcrumbiblog svg{width:16px;height:16px;vertical-align:-4px}
            #breadcrumbiblog svg path{fill:#666}
            }
            input[type="color"], input[type="date"], input[type="datetime-local"], input[type="datetime"], input[type="email"], input[type="month"], input[type="number"], input[type="password"], input[type="range"], input[type="search"], input[type="tel"], input[type="text"], input[type="time"], input[type="url"], input[type="week"], textarea {
                color: #666;
                border: 1px solid #ccc;
                width: 100%;
                max-width: 100%;
                height: 34px;
                padding: 3px 9px;
            }
        </style>
        <div id="breadcrumbiblog">
            <?php if (function_exists('breadcrumbsX')) breadcrumbsX(); ?>
        </div>
    </div>
 <?php get_footer(); ?>