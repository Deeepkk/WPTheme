<?php
/* 
Template Name: Template - Disclaimer
*/
?>
<?php
###### https://www.geeksforgeeks.org/php-str_replace-function/
###### PHP | str_replace() Function 
###### Input string 
$url = get_bloginfo('url');
###### using str_replace() function 
$urls1 = str_replace('http://', '', $url);
$linkX = get_bloginfo('url');;
$parse = parse_url($linkX);
$urls = $parse['host'];
//$urls = str_replace('https://', '', $url);
$datePublished = mysql2date( DATE_W3C, $post->post_date, false );
$dateModified = mysql2date( DATE_W3C, $post->post_modified_gmt, false );
$emailX = get_bloginfo('admin_email');
$namesX = get_bloginfo('name');
?>
<?php
$post_date = get_the_date( 'l, F j, Y' );
$post_time = get_the_date( 'g:i A' );
?>
<?php get_header(); // add header ?>
  <div class="wrap post-<?php the_title(); ?>">
<div class="single page page-<?php the_ID(); ?>">
    <div class="container">
        <div class="columns">
            <div class="column is-9">
                <nav class="breadcrumb" aria-label="breadcrumb_items">
                    <span>
                        <span><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a> »
                            <span class="breadcrumb_last" aria-current="page"><?php the_title(); ?></span>
                        </span>
                    </span>
                </nav>
                <article class="is-large">
                    <h1 itemprop="name" ><?php the_title(); ?></h1>
                </article>
                <br>
          
                           <div class="desc">
                           
                                <!--start kontent -->
                                <p>All the content on <strong>
                                <span style="color: #ff6600;"><?php echo $urls; ?></span>
                                </strong> is either submitted to <a href="//<?php echo $urls; ?>"><?php echo $urls; ?></a> by email or is readily available in various places on the Internet and believed to be in public domain. Content (including images and videos) posted are believed to be posted within our rights according to the U.S. Copyright Fair Use Act (Title 17, U.S. Code.)</p>
                                <h3>Notification of Copyright Infringement</h3>
                                <p><?php echo $urls; ?> is in compliance with 17 U.S.C. § 512 and the Digital Millennium Copyright Act (“DMCA”). It is our policy to respond to any infringement notices and take appropriate actions under the Digital Millennium Copyright Act (“DMCA”) and other applicable intellectual property laws.</p>
                                <p>If your copyrighted material has been posted on <?php echo $urls; ?> or if links to your copyrighted material are returned through any search engine and you want this material removed, you must provide a written communication that details the information listed in the following section. Please be aware that you will be liable for damages (including costs and attorneys’ fees) if you misrepresent information listed on our site that is infringing on your copyrights. We suggest that you first contact an attorney for legal assistance on this matter.</p>
                                <p>The following elements must be included in your copyright infringement claim:</p>
                                <ul>
                                    <li>Provide evidence of the authorized person to act on behalf of the owner of an exclusive right that is allegedly infringed.</li>
                                    <li>Provide sufficient contact information so that we may contact you. You must also include a valid email address.</li>
                                    <li>You must identify in sufficient detail the copyrighted work claimed to have been infringed and including at least one search term under which the material appears in <?php echo $urls; ?> search results.</li>
                                    <li>A statement that the complaining party has a good faith belief that use of the material in the manner complained of is not authorized by the copyright owner, its agent, or the law.</li>
                                    <li>A statement that the information in the notification is accurate, and under penalty of perjury, that the complaining party is authorized to act on behalf of the owner of an exclusive right that is allegedly infringed.</li>
                                </ul>
                                <p>Must be signed by the authorized person to act on behalf of the owner of an exclusive right that is allegedly being infringed.</p>
                                <p>Please send the infringement notice via email to <a href="mailto:<?php echo $emailX; ?>"><?php echo $emailX; ?></a>
                                </p>
                                <p>Please allow us a day or two for an email response. Note that emailing your complaint to other parties such as our Internet Service Provider will not expedite your request and may result in a delayed response due the complaint not properly being filed. Thanks.</p>
                                <h3 style="text-align: justify;">Update</h3>
                                <p style="text-align: justify;">This site disclaimer was last updated on: <?php echo $post_date; ?> at <?php echo $post_time; ?></p>
                                <p style="text-align: justify;"><i> · Should we update, amend or make any changes to this document, those changes will be prominently posted here.</i></p>
                                <!--end kontent -->
                            </div>
 
                <div class="clearfix">
                </div>
            </div>
            <div class="column is-3 sidebar">
                <?php get_sidebar(); ?>
            </div>
        </div>
        <style>
            #breadcrumbiblog1 {
                padding:5px 5px 5px 0px; margin: 0px 0px 15px 0px; font-size:90%; line-height: 1.4em; border-bottom:3px double #eee;
            }
            /* Breadcrumb */
            #breadcrumbiblog{background:#fff;line-height:1.2em;width:auto;overflow:hidden;margin:0;padding:10px 0;border-top:1px solid #dedede;border-bottom:1px solid #dedede;font-size:80%;color:#888;font-weight:400;text-overflow:ellipsis;-webkit-text-overflow:ellipsis;white-space:nowrap}
            #breadcrumbiblog a{display:inline-block;text-decoration:none;transition:all .3s ease-in-out;color:#666;font-weight:400}
            #breadcrumbiblog a:hover{color:#11589D}
            #breadcrumbiblog svg{width:16px;height:16px;vertical-align:-4px}
            #breadcrumbiblog svg path{fill:#666}
            }
        </style>
        <div id="breadcrumbiblog">
            <?php if (function_exists('breadcrumbsX')) breadcrumbsX(); ?>
        </div>
    </div>
 
<?php get_footer(); ?>