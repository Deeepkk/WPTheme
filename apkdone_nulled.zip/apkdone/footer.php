</div>
</main>

<p id="backtop" style="display: block;"></p>

<?php ex_themes_footer_on_sections_(); ?>
<?php wp_footer(); ?>
</body>
</html>