<?php
###############################
###    Stop Don't Try Edit  ###
###  if you don't know php  ###
###############################
###      EX-THEMES.COM      ###
### Premium Wordress Themes ###
###############################
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
define('EX_THEMES_NAMES','Apkdone');
define('EX_THEMES_VERSION','2.2');
define('EX_THEMES_SLUGS_','exthemes');
define('EX_THEMES_SPACES','v');
define('EX_THEMES_URI',get_template_directory_uri());
define('EX_THEMES_DIR',get_template_directory());
require EX_THEMES_DIR.'/libs/core/addscripts.php';
require EX_THEMES_DIR.'/libs/core/inits.php';
require EX_THEMES_DIR.'/libs/core/breadcrums.php';
require EX_THEMES_DIR.'/libs/core/widgets.php';
require EX_THEMES_DIR.'/libs/core/walker_menu.php';
require EX_THEMES_DIR.'/libs/main.php';
require EX_THEMES_DIR. '/template/better-comments.php';
require_once EX_THEMES_DIR.'/template/better-comments.php';
require EX_THEMES_DIR.'/libs/core/cores.php';
require EX_THEMES_DIR.'/libs/core/ads.php';
require EX_THEMES_DIR.'/libs/core/extra.php';
require EX_THEMES_DIR.'/libs/core/cpt.php';
require EX_THEMES_DIR.'/libs/core/install_page.php';
require EX_THEMES_DIR.'/libs/tgm.php';
require EX_THEMES_DIR.'/libs/register_plugin.php';	
###### Include Panel ######