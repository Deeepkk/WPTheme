<?php
if ( ! defined( 'ABSPATH' ) ) exit; 
require_once "liatma.php";
class Apkdone {
	public $plugin_file=__FILE__;
	public $responseObj;
	public $licenseMessage;
	public $showMessage=false;
	public $slug=EX_THEMES_SLUGS_;
	function __construct() {
		add_action( 'admin_print_styles', [ $this, 'SetAdminStyle' ] );
		$licenseKey=get_option("Apkdone_lic_Key","");
		$liceEmail=get_option( "Apkdone_lic_email","");
		$templateDir=get_template_directory(); //or dirname(__FILE__);
		if(ApkdoneBase::CheckWPPlugin($licenseKey,$liceEmail,$this->licenseMessage,$this->responseObj,get_template_directory()."/style.css")){
			add_action( 'admin_menu', [$this,'ActiveAdminMenu'],99999);
			add_action( 'admin_post_Apkdone_el_deactivate_license', [ $this, 'action_deactivate_license' ] );
			//$this->licenselMessage=$this->mess;
			require_once( get_template_directory().'/libs/inc/ReduxCore/inc/themecheck/class.cores.php' );
			}else{
			if(!empty($licenseKey) && !empty($this->licenseMessage)){
				$this->showMessage=true;
			}
			update_option("Apkdone_lic_Key","") || add_option("Apkdone_lic_Key","");
			add_action( 'admin_post_Apkdone_el_activate_license', [ $this, 'action_activate_license' ] );
			add_action( 'admin_menu', [$this,'InactiveMenu']);
			add_action( 'admin_notices', 'ex_themes_notices' );
			add_action( 'wp_footer', 'ex_themes_not_activate_notice' );
		}
        }
	function SetAdminStyle() {
		//wp_register_style( "ApkdoneLic", get_template_directory().("/libs/inc/options/_lic_style.css"),10);
		//wp_enqueue_style( "ApkdoneLic" );
	}
	function ActiveAdminMenu(){
		add_menu_page (  EX_THEMES_NAMES." Active", EX_THEMES_NAMES." Active", "activate_plugins", $this->slug, [$this,"Activated"], " dashicons-unlock ");
		//add_submenu_page(  $this->slug, "Apkdone License", "License Info", "activate_plugins",  $this->slug."_license", [$this,"Activated"] );
	}
	function InactiveMenu() {
		add_menu_page( EX_THEMES_NAMES." Inactive", EX_THEMES_NAMES." Inactive", 'activate_plugins', $this->slug,  [$this,"LicenseForm"], " dashicons-lock " );
	}
	function action_activate_license(){
		check_admin_referer( 'el-license' );
		$licenseKey=!empty($_POST['el_license_key'])?$_POST['el_license_key']:"";
		$licenseEmail=!empty($_POST['el_license_email'])?$_POST['el_license_email']:"";
		update_option("Apkdone_lic_Key",$licenseKey) || add_option("Apkdone_lic_Key",$licenseKey);
		update_option("Apkdone_lic_email",$licenseEmail) || add_option("Apkdone_lic_email",$licenseEmail);
		update_option('_site_transient_update_themes','');
		wp_safe_redirect(admin_url( 'admin.php?page='.$this->slug));
	}
	function action_deactivate_license() {
		check_admin_referer( 'el-license' );
		$message="";
		if(ApkdoneBase::RemoveLicenseKey(__FILE__,$message)){
			update_option("Apkdone_lic_Key","") || add_option("Apkdone_lic_Key","");
			update_option('_site_transient_update_themes','');
		}
    	wp_safe_redirect(admin_url( 'admin.php?page='.$this->slug));
    }
	function Activated(){
		?>
		<style>.larismanis-license-form{padding:10px 20px;background:#fff;border-left:4px solid #00a0d2;margin-top:15px}.larismanis-license-form input{height:40px;line-height:40px;padding:0 10px;vertical-align:top;background:#f5f5f5}.wp-core-ui .larismanis-license-form .button,.wp-core-ui .larismanis-license-form .button-primary,.wp-core-ui .larismanis-license-form .button-secondary{height:40px;line-height:40px;padding:0 20px;vertical-align:top}.larismanis-license-form a{text-decoration:none}.larismanis-license-good{color:#3c763d}.larismanis-license-bad{color:#a94442}.el-license-container .el-license-info-title::after{content:":";position:absolute;right:2px}.larismanis-license-form .el-license-container .el-license-valid,.el-license-container .el-license-invalid{padding:0 5px 2px;color:#fff;background-color:#8fcc77;border-radius:3px}.el-license-container{margin:20px;padding:35px;background:#fff;border-radius:4px}.el-license-container .el-license-field{display:block;margin-bottom:15px}.el-license-container .el-license-field input{font-size:200%;padding:8px 10px 10px}.el-license-container .notice-error,.el-license-container div.error{background:rgba(220,50,50,0.11);margin:0}.el-license-container .el-license-title{margin-top:0;font-size:30px}.el-license-container .el-license-info li{list-style:none;padding:0}.el-license-container .el-license-info-title{width:150px;display:inline-block;position:relative;padding-right:5px}.el-license-container .el-license-info-title:after{content:":";position:absolute;right:2px}.el-license-container .el-license-valid,.el-license-container .el-license-invalid{padding:0 5px 2px;color:#fff;background-color:#8fcc77;border-radius:3px}.el-license-container .el-license-invalid{background-color:#f44336}.el-license-container .el-license-key{font-weight:700;opacity:.8}.el-license-container .el-green-btn{padding:0 5px 2px;color:#fff;background-color:#8fcc77;border-radius:3px;text-decoration:none;-webkit-box-shadow:0 0 3px -1px rgba(0,0,0,0.38);-moz-box-shadow:0 0 3px -1px rgba(0,0,0,0.38);box-shadow:0 0 3px -1px rgba(0,0,0,0.38)}.el-license-container .el-green-btn:hover{color:#fff;background-color:#84bc6c}.el-license-container .el-blue-btn{padding:0 5px 2px;color:#fff;background-color:#20b1d2;border-radius:3px;text-decoration:none;-webkit-box-shadow:0 0 3px -1px rgba(0,0,0,0.38);-moz-box-shadow:0 0 3px -1px rgba(0,0,0,0.38);box-shadow:0 0 3px -1px rgba(0,0,0,0.38)}.el-license-container .el-blue-btn:hover{color:#fff;background-color:#219dbf}.el-license-container .el-license-field label{display:block;margin-bottom:5px}.el-license-container .el-license-active-btn{margin-top:25px}</style>
		<div class="wrap">
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"  class="larismanis-license-form">
            <input type="hidden" name="action" value="Apkdone_el_deactivate_license"  class="larismanis-license-form" />           
              <div class="el-license-container">
			  <h3 class="el-license-title"><span class="dashicons dashicons-unlock" style="font-size:26px!important;color:green!important;"></span> <?php echo EX_THEMES_NAMES; ?> License Info</h3>
                <hr>
				<p>
				<ul class="el-license-info">
                <li>
                    <div>
                        <span class="el-license-info-title"><?php _e("Status",$this->slug);?></span>
                        <?php if ( $this->responseObj->is_valid ) : ?>
                            <span class="el-license-valid"><?php _e("Valid",$this->slug);?></span>
                        <?php else : ?>
                            <span class="el-license-valid"><?php _e("Invalid",$this->slug);?></span>
                        <?php endif; ?>
                    </div>
                </li>
                <li>
                    <div>
                        <span class="el-license-info-title"><?php _e("License Type",$this->slug);?></span>
                        <?php echo $this->responseObj->license_title; ?>
                    </div>
                </li>
               <li>
                   <div>
                       <span class="el-license-info-title"><?php _e("License Expired on",$this->slug);?></span>
                       <?php echo $this->responseObj->expire_date;
                       if(!empty($this->responseObj->expire_renew_link)){
                           ?>
                           <a target="_blank" class="el-blue-btn" href="<?php echo $this->responseObj->expire_renew_link; ?>">Renew</a>
                           <?php
                       }
                       ?>
                   </div>
               </li>
               <li>
                   <div>
                       <span class="el-license-info-title"><?php _e("Support Expired on",$this->slug);?></span>
                       <?php
                           echo $this->responseObj->support_end;
                        if(!empty($this->responseObj->support_renew_link)){
                            ?>
                               <a target="_blank" class="el-blue-btn" href="<?php echo $this->responseObj->support_renew_link; ?>">Renew</a>
                            <?php
                        }
                       ?>
                   </div>
               </li>
                <li>
                    <div>
                        <span class="el-license-info-title"><?php _e("Your License Key",$this->slug);?></span>
                        <span class="el-license-key"><?php echo esc_attr( substr($this->responseObj->license_key,0,9)."XXXXXXXX-XXXXXXXX".substr($this->responseObj->license_key,-9) ); ?></span>
                    </div>
                </li>
                </ul>
                <div class="el-license-active-btn">
                    <?php wp_nonce_field( 'el-license' ); ?>
                    <?php submit_button('Deactivate'); ?>
                </div>
          </div></div>
        </form>
		<?php }	
	function LicenseForm() {
		?>
		<style>
		.larismanis-license-form {
			padding: 10px 20px;
			background: #fff;
			border-left: 4px solid #00a0d2;
			margin-top: 15px;
		}
		.larismanis-license-form input {
			height: 40px;
			line-height: 40px;
			padding: 0 10px;
			vertical-align: top;
			background: #f5f5f5;
		}
		.wp-core-ui .larismanis-license-form .button, .wp-core-ui .larismanis-license-form .button-primary, .wp-core-ui .larismanis-license-form .button-secondary {
			height: 40px;
			line-height: 40px;
			padding: 0 20px;
			vertical-align: top;
		}
		.larismanis-license-form a {
			text-decoration: none;
		}
		.larismanis-license-good {
			color: #3c763d;
		}
		.larismanis-license-bad {
			color: #a94442;
		}
		</style>
		<div class="wrap">
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="larismanis-license-form">
            <input type="hidden" name="action" value="Apkdone_el_activate_license"/>
             		<div class="el-license-container">
                <h3 class="el-license-title"><span class="dashicons dashicons-lock" style="font-size:26px!important;color:red!important;"></span> <?php echo EX_THEMES_NAMES; ?> Theme License</h3>
    		    <p style="font-size:15px;text-transform:capitalize">    			   
    			    <input type="text" class="regular-text" name="el_license_key" size="50" placeholder="xxxxxxxx-xxxxxxxx-xxxxxxxx-xxxxxxxx" value="00000000-00000000-00000000-00000000" required="required">
					<?php wp_nonce_field( 'el-license' ); ?>
					<input type="submit" class="button button-primary" name="<?php echo $this->theme_slug; ?>_license_deactivate" value="Activate"/>
    		    </p>
                <?php
					if(!empty($this->showMessage) && !empty($this->licenseMessage)){
						?>
					   <p><span class="description">
							<span class="larismanis-license-bad"><b>STATUS:</b> <?php echo $this->licenseMessage; ?></span>
						</span></p>
						<?php
					}
				?>
            <h3>How to get License Key <?php echo EX_THEMES_NAMES; ?> Themes?</h3>
				<p>
					<ol>						 
						<li>
							First you have to buy <?php echo EX_THEMES_NAMES; ?> themes on <b><a href="https://ex-themes.com/" target="_blank">ex-themes.com</a></b>.
						</li>
					</ol>
				</p>
        </form>
        </div>
		<?php
	}
}
new Apkdone();