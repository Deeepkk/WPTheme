<?php
/**
 * ReduxFramework Barebones Sample Config File
 * For full documentation, please visit: http://docs.reduxframework.com/
 */
if ( ! class_exists( 'Redux' ) ) {
    return;
}
// This is your option name where all the Redux data is stored.
$opt_name = "opt_themes";
/**
 * ---> SET ARGUMENTS
 * All the possible arguments for Redux.
 * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
 * */
$theme = wp_get_theme(); // For use with some settings. Not necessary.
$args = array(
    // TYPICAL -> Change these values as you need/desire
    'opt_name'             => $opt_name,
    // This is where your data is stored in the database and also becomes your global variable name.
    'display_name'         => '<span class="dashicons dashicons-share-alt"></span> '.$theme->get( 'Name' ).'',
    // Name that appears at the top of your panel
    'display_version'      => $theme->get( 'Version' ),
    // Version that appears at the top of your panel
    'menu_type'            => 'menu',
    //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
    'allow_sub_menu'       => true,
    // Show the sections below the admin menu item or not
    'menu_title'           => __( ''.$theme->get( 'Name' ).' '.$theme->get( 'Version' ).'', 'ex_themes' ),
    'page_title'           => __( ''.$theme->get( 'Name' ).' '.$theme->get( 'Version' ).'', 'ex_themes' ),
    // You will need to generate a Google API key to use this feature.
    // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
    'google_api_key'       => '',
    // Set it you want google fonts to update weekly. A google_api_key value is required.
    'google_update_weekly' => false,
    // Must be defined to add google fonts to the typography module
    'async_typography'     => true,
    // Use a asynchronous font on the front end or font string
    //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
    'admin_bar'            => true,
    // Show the panel pages on the admin bar dashicons-share-alt dashicons-dashboard
    'admin_bar_icon'       => 'dashicons-admin-multisite',
    // Choose an icon for the admin bar menu
    'admin_bar_priority'   => 50,
    // Choose an priority for the admin bar menu
    'global_variable'      => '',
    // Set a different name for your global variable other than the opt_name
    'dev_mode'             => false,
    // Show the time the page took to load, etc
    'update_notice'        => false,
    // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
    'customizer'           => false,
    // Enable basic customizer support
    //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
    //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field
    // OPTIONAL -> Give you extra features
    'page_priority'        => null,
    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
    'page_parent'          => 'themes.php',
    // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
    'page_permissions'     => 'manage_options',
    // Permissions needed to access the options panel.
    'menu_icon'            => 'dashicons-admin-multisite',
    // Specify a custom URL to an icon
    'last_tab'             => '',
    // Force your panel to always open to a specific tab (by id)
    'page_icon'            => 'icon-themes',
    // Icon displayed in the admin panel next to your menu_title
    'page_slug'            => '_options',
    // Page slug used to denote the panel
    'save_defaults'        => true,
    // On load save the defaults to DB before user clicks save or not
    'default_show'         => false,
    // If true, shows the default value next to each field that is not the default value.
    'default_mark'         => '',
    // What to print by the field's title if the value shown is default. Suggested: *
    'show_import_export'   => true,
    // Shows the Import/Export panel when not used as a field.
    // CAREFUL -> These options are for advanced use only
    'transient_time'       => 60 * MINUTE_IN_SECONDS,
    'output'               => true,
    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
    'output_tag'           => true,
    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
    // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.
    // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
    'database'             => '',
    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
    'use_cdn'              => true,
    // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.
    //'compiler'             => true,
    // HINTS
    'hints'                => array(
        'icon'          => 'el el-question-sign',
        'icon_position' => 'right',
        'icon_color'    => 'lightgray',
        'icon_size'     => 'normal',
        'tip_style'     => array(
            'color'   => 'light',
            'shadow'  => true,
            'rounded' => false,
            'style'   => '',
        ),
        'tip_position'  => array(
            'my' => 'top left',
            'at' => 'bottom right',
        ),
        'tip_effect'    => array(
            'show' => array(
                'effect'   => 'slide',
                'duration' => '500',
                'event'    => 'mouseover',
            ),
            'hide' => array(
                'effect'   => 'slide',
                'duration' => '500',
                'event'    => 'click mouseleave',
            ),
        ),
    )
);
// ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
$args['admin_bar_links'][] = array(
    'id'    => 'redux-docs',
    'href'  => 'https://ex-themes.com',
    'title' => __( 'Doc', 'ex_themes' ),
);
/*
   $args['admin_bar_links'][] = array(
       //'id'    => 'redux-support',
       'href'  => 'https://github.com/ReduxFramework/redux-framework/issues',
       'title' => __( 'Support', 'ex_themes' ),
   );
   $args['admin_bar_links'][] = array(
       'id'    => 'redux-extensions',
       'href'  => 'reduxframework.com/extensions',
       'title' => __( 'Extensions', 'ex_themes' ),
   );
*/
// SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
$args['share_icons'][] = array(
    'url'   => 'https://facebook.com/Ex-themescom-147994030387758',
    'title' => 'Follow us on Facebook',
    'icon'  => 'el el-facebook'
);
$args['share_icons'][] = array(
    'url'   => 'https://twitter.com/ExThemes',
    'title' => 'Follow us on Twitter',
    'icon'  => 'el el-twitter'
);
$args['share_icons'][] = array(
    'url'   => 'https://www.linkedin.com/in/bangreyblogs',
    'title' => 'Find us on LinkedIn',
    'icon'  => 'el el-linkedin'
);
$args['share_icons'][] = array(
    'url'   => 'https://www.youtube.com/c/seomakassar',
    'title' => 'Find us on Youtube',
    'icon'  => 'el el-youtube'
);
$args['share_icons'][] = array(
    'url'   => 'https://www.instagram.com/exthemescom/',
    'title' => 'Find us on Instagram',
    'icon'  => 'el el-instagram'
);
$args['share_icons'][] = array(
    'url'   => 'https://ex-themes.com',
    'title' => 'Find us on Wordpress',
    'icon'  => 'el el-wordpress'
);
// Panel Intro text -> before the form
if ( ! isset( $args['global_variable'] ) || $args['global_variable'] !== false ) {
    if ( ! empty( $args['global_variable'] ) ) {
        $v = $args['global_variable'];
    } else {
        $v = str_replace( '-', '_', $args['opt_name'] );
    }
    //$args['intro_text'] = sprintf( __( '<noscript><p style="display:none">Did you know that Redux sets a global variable for you? To access any of your saved options from within your code you can use your global variable: <strong>$%1$s</strong></p></noscript>', 'ex_themes' ), $v );
} else {
    //$args['intro_text'] = __( '<p style="display:none">This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>', 'ex_themes' );
}
// Add content after the form.
$args['footer_text'] = __( '<p></p>', 'ex_themes' );
Redux::setArgs( $opt_name, $args );

Redux::setSection( $opt_name, array(
    'title'            => __( 'Generals', 'ex_themes' ),
    'id'               => 'dashboard_ex_themes',
    'customizer_width' => '700px',
    'icon'             => 'el el-dashboard',
    'subsection'       => false,

) );

Redux::setSection( $opt_name, array(
    'title'            => __( 'Headers', 'ex_themes' ),
    //'desc'             => __( 'For full documentation on this field, visit: ', 'ex_themes' ) . '<a href="//docs.reduxframework.com/core/fields/text/" target="_blank">docs.reduxframework.com/core/fields/text/</a>',
    'id'               => 'header',
    'subsection'       => true,
    'customizer_width' => '700px',
    'icon'             => 'el el-wrench',

    'fields'           => array(
        array(
            'id'       => 'ex_themes_logo_headers_active_',
            'type'     => 'switch',
            'title'    => __( 'Logo Header', 'ex_themes' ),
            ////'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'header_logo',
            'type'     => 'media',
            'title'    => __( 'Upload Your Header Logo', 'ex_themes' ),
            'default'  => array(
                'url'=> ''.get_bloginfo('template_directory') . '/assetss/img/apkdone.png'),
            'required' => array( 'ex_themes_logo_headers_active_', '=', true )
        ),
        array(
            'id'       => 'aktif_favicon',
            'type'     => 'switch',
            'title'    => __( 'Favicons', 'ex_themes' ),
            ////'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'favicon',
            'type'     => 'media',
            'title'    => __( 'Upload Favicon', 'ex_themes' ),
            'default'  => array(
                'url'=> ''.get_bloginfo('template_directory') . '/assetss/img/lazy.png'),
            'required' => array( 'aktif_favicon', '=', true )
        ),
    )
) );

Redux::setSection( $opt_name, array(
    'title'            => __( 'Footer', 'ex_themes' ),
    'id'               => 'footers',
    'customizer_width' => '500px',
    'subsection'       => true,
    'icon'             => 'el el-wrench',
    'fields'     => array(
        array(
            'id'       => 'ex_themes_footers_code_active_',
            'type'     => 'switch',
            'title'    => __( 'Statistic Codes', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'ex_themes_footers_code_',
            'type'     => 'textarea',
            'title'    => __( 'Histats or Analytics', 'ex_themes' ),
            'subtitle' => __( 'HTML Allowed', 'ex_themes' ),
            //'desc'     => __( 'This is the description field, again good for additional info.', 'ex_themes' ),
            'default'  => '',
            'required' => array( 'ex_themes_footers_code_active_', '=', true )
        ),
        array(
            'id'       => 'ex_themes_footers_copyrights_active_',
            'type'     => 'switch',
            'title'    => __( 'Footer Copyright', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'ex_themes_footers_copyrights_code_',
            'type'     => 'editor',
            'title'    => __( 'Footer Copyright', 'ex_themes' ),
            'subtitle' => __( 'HTML Allowed', 'ex_themes' ),
            'default'  => "<a href='".get_option('home')."'>".get_option('blogname')."</a> - © <script type=\"text/javascript\">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> All rights reserved - Developer by <a href=\"https://ex-themes.com\" title=\"premium wordpress themes - ex-themes.com\"><strong style=\"text-transform: capitalize;\">ex-themes.com</strong></a>",
            'required' => array( 'ex_themes_footers_copyrights_active_', '=', true )
        ),
    )
) );

Redux::setSection( $opt_name, array(
    'title'            => __( 'Colour Styles', 'ex_themes' ),
    'id'               => 'color_styles',
    'customizer_width' => '700px',
    'icon'             => 'el el-css',
    'subsection'       => true,
    'fields'     => array(
        array(
            'id'       => 'color_header',
            'type'     => 'color',
            'title'    => __('Menu Color', 'ex_themes'),
            'subtitle' => __('Pick Menu Color for the theme (default: #4a4a4a).', 'ex_themes'),
            'default'  => '#4a4a4a',
            'validate' => 'color',
        ),
        array(
            'id'       => 'color',
            'type'     => 'color',
            'title'    => __('Button Color', 'ex_themes'),
            'subtitle' => __('Pick Button Color for the theme (default: #008080).', 'ex_themes'),
            'default'  => '#008080',
            'validate' => 'color',
        ),
        array(
            'id'       => 'color_link',
            'type'     => 'color',
            'title'    => __('Link Color', 'ex_themes'),
            'subtitle' => __('Pick Link Color for the theme (default: #3273dc).', 'ex_themes'),
            'default'  => '#3273dc',
            'validate' => 'color',
        ),
		/*
		array(
        'id'          => 'opt-typography',
        'type'        => 'typography', 
        'title'       => __('Typography', 'redux-framework-demo'),
        'google'      => true, 
        'font-backup' => true,
        'output'      => array('h2.site-description'),
        'units'       =>'px',
        'subtitle'    => __('Typography option with each property can be called individually.', 'redux-framework-demo'),
        'default'     => array(
            'color'       => '#333', 
            'font-style'  => '700', 
            'font-family' => 'Abel', 
            'google'      => true,
            'font-size'   => '33px', 
            'line-height' => '40'
        ),
		),
		*/

    )
) );

Redux::setSection( $opt_name, array(
    'title'            => __( 'Advertise', 'ex_themes' ),
    'id'               => 'ads',
    'customizer_width' => '500px',
    'icon'             => 'el el-usd',
    'fields'     => array(
        array(
            'id'       => 'ex_themes_adv_homes_active_',
            'type'     => 'switch',
            'title'    => __( 'Ads Banner for All Pages', 'ex_themes' ),
            'subtitle' => __( '<br>ads banner for home, archive, categorie, search, 404 pages', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'ex_themes_adv_homes_code_',
            'type'     => 'textarea',
            'title'    => __( 'HTML Allowed', 'ex_themes' ),
            'subtitle' => __( 'Insert your code <br> Scripts or Banner', 'ex_themes' ),
            'default'  => "<img src=\"".get_bloginfo('template_directory') . "/assetss/img/ads1.png\" height=\"auto\" width=\"100%\">",
            'required' => array( 'ex_themes_adv_homes_active_', '=', true )
        ),
        array(
            'id'       => 'ex_themes_adv_homes_active_2',
            'type'     => 'switch',
            'title'    => __( 'Ads Banner for only Homes', 'ex_themes' ),
            'subtitle' => __( '<br>ads banner for homes', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'ex_themes_adv_homes_code_2',
            'type'     => 'textarea',
            'title'    => __( 'HTML Allowed', 'ex_themes' ),
            'subtitle' => __( 'Insert your code <br> Scripts or Banner', 'ex_themes' ),
            'default'  => "<img src=\"".get_bloginfo('template_directory') . "/assetss/img/ads2.png\" height=\"auto\" width=\"100%\">",
            'required' => array( 'ex_themes_adv_homes_active_2', '=', true )
        ),
        array(
            'id'       => 'ex_themes_adv_single_page_active_',
            'type'     => 'switch',
            'title'    => __( 'Ads Banner for Single Post', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'ex_themes_adv_single_page_code_',
            'type'     => 'textarea',
            'title'    => __( 'HTML Allowed', 'ex_themes' ),
            'subtitle' => __( 'Insert your code <br> Scripts or Banner', 'ex_themes' ),
            'default'  => "<img src=\"".get_bloginfo('template_directory') . "/assetss/img/ads1.png\" height=\"auto\" width=\"100%\">",
            'required' => array( 'ex_themes_adv_single_page_active_', '=', true )
        ),
        array(
            'id'       => 'ex_themes_adv_single_page_active_2',
            'type'     => 'switch',
            'title'    => __( 'Ads Banner for Single Post Alternative', 'ex_themes' ),
            //'subtitle' => __( '<br>ads banner for', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'ex_themes_adv_single_page_code_2',
            'type'     => 'textarea',
            'title'    => __( 'HTML Allowed', 'ex_themes' ),
            'subtitle' => __( 'Insert your code <br> Scripts or Banner', 'ex_themes' ),
            'default'  => "<img src=\"".get_bloginfo('template_directory') . "/assetss/img/ads3.png\" height=\"auto\" width=\"100%\">",
            'required' => array( 'ex_themes_adv_single_page_active_2', '=', true )
        ),
        array(
            'id'       => 'ex_themes_adv_download_page_active_',
            'type'     => 'switch',
            'title'    => __( 'Ads Banner for Download Pages', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'ex_themes_adv_download_page_code_',
            'type'     => 'textarea',
            'title'    => __( 'HTML Allowed', 'ex_themes' ),
            'subtitle' => __( 'Insert your code <br> Scripts or Banner', 'ex_themes' ),
            'default'  => "<img src=\"".get_bloginfo('template_directory') . "/assetss/img/ads2.png\" height=\"auto\" width=\"100%\">",
            'required' => array( 'ex_themes_adv_download_page_active_', '=', true )
        ),
        array(
            'id'       => 'ex_themes_adv_download_page_active_2',
            'type'     => 'switch',
            'title'    => __( 'Ads Banner for Download Pages Alternative', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'ex_themes_adv_download_page_code_2',
            'type'     => 'textarea',
            'title'    => __( 'HTML Allowed', 'ex_themes' ),
            'subtitle' => __( 'Insert your code <br> Scripts or Banner', 'ex_themes' ),
            'default'  => "<img src=\"".get_bloginfo('template_directory') . "/assetss/img/ads1.png\" height=\"auto\" width=\"100%\">",
            'required' => array( 'ex_themes_adv_download_page_active_2', '=', true )
        ),

        array(
            'id'       => 'aktif_ads_fake_download',
            'type'     => 'switch',
            'title'    => __( 'Ads Banner for Fake Link', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'title_fake_download',
            'type'     => 'text',
            'title'    => __( 'Title Fake Download', 'ex_themes' ),
            'subtitle' => __( '', 'ex_themes' ),
            'default'  => 'Fast Download APK MOD & OBB File',
            'required' => array( 'aktif_ads_fake_download', '=', true )
        ),
        array(
            'id'       => 'ads_fake_download',
            'type'     => 'text',
            'title'    => __( 'Link URL Fake Download', 'ex_themes' ),
            'subtitle' => __( 'This must be a URL.', 'ex_themes' ),
            'validate' => 'url',
            'default'  => 'https://ex-themes.com/download',
            'required' => array( 'aktif_ads_fake_download', '=', true )
        ),
        array(
            'id'       => 'timer_active_',
            'type'     => 'switch',
            'title'    => __( 'Timer Counts Options', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'timer_fake_download',
            'type'     => 'text',
            'title'    => __( 'Timer Counts', 'ex_themes' ),
            'subtitle' => __( 'Defaults is 3', 'ex_themes' ),
            'validate' => 'numeric',
            'default'  => '3',
            'required' => array( 'timer_active_', '=', true )
        ),
    )
) );


Redux::setSection( $opt_name, array(
    'title'            => __( 'Home Page', 'ex_themes' ),
    'id'               => 'option_homepage',
    'customizer_width' => '500px',
    'icon'             => 'el el-home',
    'fields'     => array(
        array(
            'id'       => 'ex_themes_homes_titles_',
            'type'     => 'text',
            'title'    => __( 'Title Opt', 'ex_themes' ),
            'subtitle' => __( '', 'ex_themes' ),
            'default'  => __( '#1 The Best Downloader for MOD APK files - Modded games & apps for Android', 'ex_themes' )
        ),
        array(
            'id'       => 'ex_themes_notice_installers_active_',
            'type'     => 'switch',
            'title'    => __( 'Notice Info Installer', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
		
        array(
            'id'       => 'ex_themes_notice_installers_codes_',
            'type'     => 'textarea',
            'title'    => __( 'Notices Infos', 'ex_themes' ),
            'subtitle' => __( 'HTML Allowed', 'ex_themes' ),
            'default'  => "<div class=\"column app is-12 installer\" title=\"Apkdone Installer\">
<div> <img src=\"".get_bloginfo('template_directory') . "/assetss/img/apkdoneinstaller.png\" alt=\"Apkdone Installer v1.0\" class=\"lzl\"> 
</div> 
<div> <b>".get_option('blogname')." Installer</b>
<p>Using ".get_option('blogname')." Installer to install Split APKs, OBB, ZIP, XAPK, APKM.!</p> <a href=\"#\" title=\"Download ".get_option('blogname')." installer\" class=\"btnDownload\">DOWNLOAD</a>
</div>
</div>",
            'required' => array( 'ex_themes_notice_installers_active_', '=', true )
        ),
        array(
            'id'       => 'limit_categorie_home',
            'type'     => 'text',
            'title'    => __( 'How much to showing for Home', 'ex_themes' ),
            //'subtitle' => __( 'This must be numeric.', 'ex_themes' ),
            'validate' => 'numeric',
            'default'  => '12'
        ),
        array(
            'id'       => 'aktif_categorie_apps',
            'type'     => 'switch',
            'title'    => __( 'Enable Categorie Opt 1', 'ex_themes' ),
            ////'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'title_categorie_apps',
            'type'     => 'text',
            'title'    => __( 'Title Opt 1', 'ex_themes' ),
            'subtitle' => __( '', 'ex_themes' ),
            'default'  => __( 'Title Opt 1', 'ex_themes' ),
            'required' => array( 'aktif_categorie_apps', '=', true )
        ),
        array(
            'id'       => 'categorie_apps',
            'type'     => 'select',
            'data'     => 'category',
            'title'    => __('Select Category for Opt 1 ', 'ex_themes'),
            'required' => array( 'aktif_categorie_apps', '=', true )
        ),
        array(
            'id'       => 'popular_apps_url',
            'type'     => 'text',
            'title'    => __( 'URL Opt 1', 'ex_themes' ),
            'subtitle' => __( 'This must be a URL for showing more link', 'ex_themes' ),
            //'validate' => 'url',
            'default'  => '/top-apps/',
            'required' => array( 'aktif_categorie_apps', '=', true )
        ),
        array(
            'id'       => 'aktif_categorie_games',
            'type'     => 'switch',
            'title'    => __( 'Enable Categorie Opt 2', 'ex_themes' ),
            ////'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'title_categorie_games',
            'type'     => 'text',
            'title'    => __( 'Title Categorie Opt 2', 'ex_themes' ),
            'subtitle' => __( '', 'ex_themes' ),
            'default'  => __( 'Title Opt 2', 'ex_themes' ),
            'required' => array( 'aktif_categorie_games', '=', true )
        ),
        array(
            'id'       => 'categorie_games',
            'type'     => 'select',
            'data'     => 'category',
            'title'    => __( 'Select Category for Option 2 Page', 'ex_themes'),
            'required' => array( 'aktif_categorie_games', '=', true )
        ),
        array(
            'id'       => 'popular_games_url',
            'type'     => 'text',
            'title'    => __('URL Opt 2', 'ex_themes'),
            'subtitle' => __('This must be a URL for showing more link', 'ex_themes'),
            //'validate' => 'url',
            'default'  => '/top-games/',
            'required' => array( 'aktif_categorie_games', '=', true )
        ),
        array(
            'id'       => 'aktif_categorie_opt_1',
            'type'     => 'switch',
            'title'    => __( 'Enable Categorie Opt 3', 'ex_themes' ),
            ////'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'categorie_opt_1',
            'type'     => 'select',
            'data'     => 'category',
            'title'    => __( 'Select Category for Opt 3', 'ex_themes'),
            'required' => array( 'aktif_categorie_opt_1', '=', true )
        ),
        array(
            'id'       => 'title_categorie_opt_1',
            'type'     => 'text',
            'title'    => __( 'Title Categorie Opt 3', 'ex_themes' ),
            'subtitle' => __( '', 'ex_themes' ),
            'default'  => __( 'Title Opt 3', 'ex_themes' ),
            'required' => array( 'aktif_categorie_opt_1', '=', true )
        ),
        array(
            'id'       => 'popular_categorie_opt_1',
            'type'     => 'text',
            'title'    => __('URL Opt 3 ', 'ex_themes'),
            'subtitle' => __('This must be a URL for showing more link', 'ex_themes'),
            //'validate' => 'url',
            'default'  => '#',
            'required' => array( 'aktif_categorie_opt_1', '=', true )
        ),
        array(
            'id'       => 'aktif_categorie_opt_2',
            'type'     => 'switch',
            'title'    => __( 'Enable Categorie Opt 4', 'ex_themes' ),
            ////'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'categorie_opt_2',
            'type'     => 'select',
            'data'     => 'category',
            'title'    => __( 'Select Category for Opt 4 Page', 'ex_themes'),
            'required' => array( 'aktif_categorie_opt_2', '=', true )
        ),
        array(
            'id'       => 'title_categorie_opt_2',
            'type'     => 'text',
            'title'    => __( 'Title Categorie Opt 4', 'ex_themes' ),
            'subtitle' => __( '', 'ex_themes' ),
            'default'  => __( 'Title Opt 4', 'ex_themes' ),
            'required' => array( 'aktif_categorie_opt_2', '=', true )
        ),
        array(
            'id'       => 'popular_categorie_opt_2',
            'type'     => 'text',
            'title'    => __('URL Opt 4 Page', 'ex_themes'),
            'subtitle' => __('This must be a URL for showing more link', 'ex_themes'),
            //'validate' => 'url',
            'default'  => '#',
            'required' => array( 'aktif_categorie_opt_2', '=', true )
        ),
        array(
            'id'       => 'aktif_categorie_opt_3',
            'type'     => 'switch',
            'title'    => __( 'Enable Categorie Opt 5', 'ex_themes' ),
            ////'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'categorie_opt_3',
            'type'     => 'select',
            'data'     => 'category',
            'title'    => __( 'Select Category for Opt 5', 'ex_themes'),
            'required' => array( 'aktif_categorie_opt_3', '=', true )
        ),
        array(
            'id'       => 'title_categorie_opt_3',
            'type'     => 'text',
            'title'    => __( 'Title Categorie Option 5', 'ex_themes' ),
            'subtitle' => __( '', 'ex_themes' ),
            'default'  => __( 'Title Opt 5', 'ex_themes' ),
            'required' => array( 'aktif_categorie_opt_3', '=', true )
        ),
        array(
            'id'       => 'popular_categorie_opt_3',
            'type'     => 'text',
            'title'    => __('URL Opt 5 Page', 'ex_themes'),
            'subtitle' => __('This must be a URL for showing more link', 'ex_themes'),
            //'validate' => 'url',
            'default'  => '#',
            'required' => array( 'aktif_categorie_opt_3', '=', true )
        ),
    )
) );

Redux::setSection( $opt_name, array(
    'title'            => __( 'Single Post', 'ex_themes' ),
    'id'               => 'related_posts',
    'customizer_width' => '500px',
    'icon'             => 'el el-pencil-alt',
    'fields'     => array(
        array(
            'id'       => 'ex_themes_related_posts_active_',
            'type'     => 'switch',
            'title'    => __( 'Enable Related Opt 1', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
		array(
            'id'       => 'ex_themes_related_posts_title_',
            'type'     => 'text',
            'title'    => __('Title Opt ', 'ex_themes'),
            //'subtitle' => __('This must be a URL for showing more link', 'ex_themes'),
            //'validate' => 'numeric',
            'default'  => 'Recommended for you',
            'required' => array( 'ex_themes_related_posts_active_', '=', true )
        ),
        array(
            'id'       => 'ex_themes_related_posts_numbers_',
            'type'     => 'text',
            'title'    => __('Showing ', 'ex_themes'),
            //'subtitle' => __('This must be a URL for showing more link', 'ex_themes'),
            'validate' => 'numeric',
            'default'  => '6',
            'required' => array( 'ex_themes_related_posts_active_', '=', true )
        ),
        
        array(
            'id'       => 'ex_themes_you_may_also_active_',
            'type'     => 'switch',
            'title'    => __( 'Enable Related Opt 2', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
		array(
            'id'       => 'ex_themes_you_may_also_title_',
            'type'     => 'text',
            'title'    => __('Title Opt ', 'ex_themes'),
            //'subtitle' => __('This must be a URL for showing more link', 'ex_themes'),
            //'validate' => 'numeric',
            'default'  => 'You may also like',
            'required' => array( 'ex_themes_you_may_also_active_', '=', true )
        ),
        array(
            'id'       => 'ex_themes_you_may_also_numbers_',
            'type'     => 'text',
            'title'    => __('Showing ', 'ex_themes'),
            //'subtitle' => __('This must be a URL for showing more link', 'ex_themes'),
            'validate' => 'numeric',
            'default'  => '6',
            'required' => array( 'ex_themes_you_may_also_active_', '=', true )
        ),
        
        array(
            'id'       => 'aktif_ex_themes_gallery_images_gpstore_',
            'type'     => 'switch',
            'title'    => __( 'Enable Gallery Image', 'ex_themes' ),
            //'subtitle' => 'Click <code>On</code> to Show Poster Gallery Image.',
            'default'  => false
        ),		
		array(
            'id'       => 'ex_themes_gallery_content_activate_',
            'type'     => 'switch',
            'title'    => __( 'Add Random Gallery on inside content', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
		 array(
            'id'       => 'ex_themes_gallery_content_paragraph_on_',
            'type'     => 'text',
            'title'    => __('Showing on after paragraph', 'ex_themes'),
            'subtitle' => __('<i>*0 is Randoms</i>', 'ex_themes'),
            'validate' => 'numeric',
            'default'  => '2',
            'required' => array( 'ex_themes_gallery_content_activate_', '=', true )
        ),
		array(
			'id'       => 'ex_themes_youtube_content_activate_',
			'type'     => 'switch',
			'title'    => __( 'Add Random Youtube on inside content', 'ex_themes' ),
			//'subtitle' => __( '<br> ', 'ex_themes' ),
			'default'  => false
		),
		array(
			'id'       => 'ex_themes_youtube_content_paragraph_on_',
			'type'     => 'text',
			'title'    => __('Showing on after paragraph', 'ex_themes'),
			'subtitle' => __('<i>*0 is Randoms</i>', 'ex_themes'),
			'validate' => 'numeric',
			'default'  => '2',
			'required' => array( 'ex_themes_youtube_content_activate_', '=', true )
		),
					
        

    )
) );

Redux::setSection( $opt_name, array(
    'title'            => __( 'Popular Pages', 'ex_themes' ),
    'id'               => 'popular_pages',
    'customizer_width' => '500px',
    'icon'             => 'el el-pencil-alt',
    'fields'     => array(
        array(
            'id'       => 'limit_categorie',
            'type'     => 'text',
            'title'    => __( 'How much to showing for Pages', 'ex_themes' ),
            //'subtitle' => __( 'This must be numeric.', 'ex_themes' ),
            'validate' => 'numeric',
            'default'  => '21'
        ),
        array(
            'id'       => 'categorie_games_id',
            'type'     => 'select',
            'data'     => 'category',
            'title'    => __( 'Select Category for Top Games Page', 'ex_themes')
        ),
        array(
            'id'       => 'categorie_apps_id',
            'type'     => 'select',
            'data'     => 'category',
            'title'    => __( 'Select Category for Top Apps Page', 'ex_themes')
        ),
        array(
            'id'       => 'categorie_paid_id',
            'type'     => 'select',
            'data'     => 'category',
            'title'    => __( 'Select Category for Top Paids Page', 'ex_themes')
        ),
    )
) );

Redux::setSection( $opt_name, array(
    'title'            => __( 'Sidebar', 'ex_themes' ),
    'id'               => 'categorie_sidebar',
    'customizer_width' => '500px',
    'icon'             => 'el el-tags',
    'fields'     => array(
        array(
            'id'       => 'aktif_categorie_sidebar_1',
            'type'     => 'switch',
            'title'    => __( 'Enable Sidebar Opt 1', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'categorie_sidebar_1',
            'type'     => 'textarea',
            'title'    => __( 'Sidebar Opt 1', 'ex_themes' ),
            'subtitle' => __( 'HTML Allowed', 'ex_themes' ),
            'default'  => '<div>
    <div class="atitle">
        <p>Games</p>
    </div>
    <div class="abuttons acategory agame">
        <a href="/category/action/" class="abutton is-small"><i class="cat-icon "></i>Action</a>
        <a href="/category/adventure/" class="abutton is-small"><i class="cat-icon adventure"></i>Adventure</a>
        <a href="/category/arcade/" class="abutton is-small"><i class="cat-icon arcade"></i>Arcade</a>
        <a href="/category/board/" class="abutton is-small"><i class="cat-icon board"></i>Board</a>
        <a href="/category/card/" class="abutton is-small"><i class="cat-icon card"></i>Card</a>
        <a href="/category/casino/" class="abutton is-small"><i class="cat-icon casino"></i>Casino</a>
        <a href="/category/casual/" class="abutton is-small"><i class="cat-icon casual"></i>Casual</a>
        <a href="/category/educational/" class="abutton is-small"><i class="cat-icon educational"></i>educational</a>
        <a href="/category/music/" class="abutton is-small"><i class="cat-icon music"></i>Music</a>
        <a href="/category/online/" class="abutton is-small"><i class="cat-icon "></i>Online</a>
        <a href="/category/puzzle/" class="abutton is-small"><i class="cat-icon puzzle"></i>Puzzle</a>
        <a href="/category/racing/" class="abutton is-small"><i class="cat-icon racing"></i>Racing</a>
        <a href="/category/role-playing/" class="abutton is-small"><i class="cat-icon role-playing"></i>Role Playing</a>
        <a href="/category/simulation/" class="abutton is-small"><i class="cat-icon simulation"></i>Simulation</a>
        <a href="/category/sports/" class="abutton is-small"><i class="cat-icon sports"></i>Sports</a>
        <a href="/category/strategy/" class="abutton is-small"><i class="cat-icon strategy"></i>Strategy</a>
        <a href="/category/trivia/" class="abutton is-small"><i class="cat-icon "></i>trivia</a>
        <a href="/category/word/" class="abutton is-small"><i class="cat-icon "></i>word</a>
    </div>
</div>
<div class="clearfix"></div>
<hr>
				',
            'required' => array( 'aktif_categorie_sidebar_1', '=', true )
        ),
        array(
            'id'       => 'aktif_categorie_sidebar_2',
            'type'     => 'switch',
            'title'    => __( 'Enable Sidebar Opt 2', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'categorie_sidebar_2',
            'type'     => 'textarea',
            'title'    => __( 'Sidebar Opt 2', 'ex_themes' ),
            'subtitle' => __( 'HTML Allowed', 'ex_themes' ),
            'default'  => '<div>
    <div class="atitle">
        <p>Apps</p>
    </div>
    <div class="abuttons acategory aapp">
        <a href="/category/art-design/" class="abutton is-small"><i class="cat-icon online"></i>Art &amp; Design</a>
        <a href="/category/auto-vehicles/" class="abutton is-small"><i class="cat-icon auto-vehicles"></i>Auto &amp; Vehicles</a>
        <a href="/category/beauty/" class="abutton is-small"><i class="cat-icon beauty"></i>Beauty</a>
        <a href="/category/books-reference/" class="abutton is-small"><i class="cat-icon books-reference"></i>Books &amp; Reference</a>
        <a href="/category/business/" class="abutton is-small"><i class="cat-icon business"></i>Business</a>
        <a href="/category/comics/" class="abutton is-small"><i class="cat-icon online"></i>comics</a>
        <a href="/category/communication/" class="abutton is-small"><i class="cat-icon communication"></i>Communication</a>
        <a href="/category/dating/" class="abutton is-small"><i class="cat-icon dating"></i>dating</a>
        <a href="/category/education/" class="abutton is-small"><i class="cat-icon education"></i>Education</a>
        <a href="/category/entertainment/" class="abutton is-small"><i class="cat-icon entertainment"></i>Entertainment</a>
        <a href="/category/events/" class="abutton is-small"><i class="cat-icon events"></i>events</a>
        <a href="/category/finance/" class="abutton is-small"><i class="cat-icon finance"></i>finance</a>
        <a href="/category/food-drink/" class="abutton is-small"><i class="cat-icon online"></i>food drink</a>
        <a href="/category/health-fitness/" class="abutton is-small"><i class="cat-icon health-fitness"></i>Health &amp; Fitness</a>
        <a href="/category/house-home/" class="abutton is-small"><i class="cat-icon online"></i>house home</a>
        <a href="/category/libraries-demo/" class="abutton is-small"><i class="cat-icon libraries-demo"></i>libraries demo</a>
        <a href="/category/lifestyle/" class="abutton is-small"><i class="cat-icon lifestyle"></i>Lifestyle</a>
        <a href="/category/maps-navigation/" class="abutton is-small"><i class="cat-icon maps-navigation"></i>Maps &amp; Navigation</a>
        <a href="/category/medical/" class="abutton is-small"><i class="cat-icon medical"></i>medical</a>
        <a href="/category/music-audio/" class="abutton is-small"><i class="cat-icon music-audio"></i>Music &amp; Audio</a>
        <a href="/category/news-magazines/" class="abutton is-small"><i class="cat-icon news-magazines"></i>News Magazines</a>
        <a href="/category/parenting/" class="abutton is-small"><i class="cat-icon parenting"></i>parenting</a>
        <a href="/category/personalization/" class="abutton is-small"><i class="cat-icon personalization"></i>Personalization</a>
        <a href="/category/photography/" class="abutton is-small"><i class="cat-icon photography"></i>Photography</a>
        <a href="/category/productivity/" class="abutton is-small"><i class="cat-icon productivity"></i>Productivity</a>
        <a href="/category/shopping/" class="abutton is-small"><i class="cat-icon shopping"></i>Shopping</a>
        <a href="/category/social/" class="abutton is-small"><i class="cat-icon social"></i>Social</a>
        <a href="/category/sports/" class="abutton is-small"><i class="cat-icon sports-apps"></i>Sports</a>
        <a href="/category/tools/" class="abutton is-small"><i class="cat-icon tools"></i>Tools</a>
        <a href="/category/travel-local/" class="abutton is-small"><i class="cat-icon travel-local"></i>Travel &amp; Local</a>
        <a href="/category/video-players-editors/" class="abutton is-small"><i class="cat-icon video-players-editors"></i>Video Editors</a>
        <a href="/category/weather/" class="abutton is-small"><i class="cat-icon weather"></i>weather</a>
    </div>
</div>
<div class="clearfix"></div>
<hr>
				',
            'required' => array( 'aktif_categorie_sidebar_2', '=', true )
        ),
    )
) );

Redux::setSection( $opt_name, array(
    'title'            => __( 'Webmasters', 'ex_themes' ),
    'id'               => 'webmaster_tools_verification',
    'customizer_width' => '500px',
    'icon'             => 'el el-globe',
    'fields'     => array(
        array(
            'id'       => 'ex_themes_webmaster_tools_active_',
            'type'     => 'switch',
            'title'    => __( 'Webmaster Tools', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'google_verif',
            'type'     => 'text',
            'title'    => __( 'Google Search Console', 'ex_themes' ),
            'subtitle' => __( 'Insert Code Google Search Console ', 'ex_themes' ),
            'default'  => 'AvKGNc41mcT7TmHke8nHR5U99NHLk2-eJw_j6PyQq94',
            'required' => array( 'ex_themes_webmaster_tools_active_', '=', true )
        ),
        array(
            'id'       => 'bing_verif',
            'type'     => 'text',
            'title'    => __( 'Bing Webmaster Tools', 'ex_themes' ),
            'subtitle' => __( 'Insert Code Bing Webmaster Tools', 'ex_themes' ),
            'default'  => 'BC97A518A2B909C0B1A76AD695E9A665',
            'required' => array( 'ex_themes_webmaster_tools_active_', '=', true )
        ),
        array(
            'id'       => 'pinterest_verif',
            'type'     => 'text',
            'title'    => __( 'Pinterest Site Verification', 'ex_themes' ),
            'subtitle' => __( 'Insert Code Pinterest Site Verification', 'ex_themes' ),
            'default'  => 'put your code',
            'required' => array( 'ex_themes_webmaster_tools_active_', '=', true )
        ),
        array(
            'id'       => 'yandex_verif',
            'type'     => 'text',
            'title'    => __( 'Yandex Webmaster Tools', 'ex_themes' ),
            'subtitle' => __( 'Insert Code Yandex Webmaster Tools', 'ex_themes' ),
            'default'  => 'bb0b65aedc95ce07',
            'required' => array( 'ex_themes_webmaster_tools_active_', '=', true )
        ),
        array(
            'id'       => 'baidu_verif',
            'type'     => 'text',
            'title'    => __( 'Baidu Webmaster Tools', 'ex_themes' ),
            'subtitle' => __( 'Insert Code Baidu Webmaster Tools ', 'ex_themes' ),
            'default'  => 'put your code',
            'required' => array( 'ex_themes_webmaster_tools_active_', '=', true )
        ),
    )
) );

Redux::setSection( $opt_name, array(
    'title'            => __( 'Sosial Media', 'ex_themes' ),
    'id'               => 'sosial_media',
    'customizer_width' => '500px',
    'icon'             => 'el el-facebook',
    'fields'     => array(
        array(
            'id'       => 'ex_themes_social_media_sidebar_active_',
            'type'     => 'switch',
            'title'    => __( 'Socials Media', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'facebook_url',
            'type'     => 'text',
            'title'    => __( 'Facebook', 'ex_themes' ),
            //'subtitle' => __( 'This must be a URL.', 'ex_themes' ),
            //'validate' => 'url',
            'default'  => 'https://facebook.com/ex.themescom',
            'required' => array( 'ex_themes_social_media_sidebar_active_', '=', true )
        ),
        array(
            'id'       => 'twitter_url',
            'type'     => 'text',
            'title'    => __( 'Twitter', 'ex_themes' ),
            //'subtitle' => __( 'This must be a URL.', 'ex_themes' ),
            //'validate' => 'url',
            'default'  => 'https://twitter.com/ExThemes',
            'required' => array( 'ex_themes_social_media_sidebar_active_', '=', true )
        ),
        array(
            'id'       => 'youtube_url',
            'type'     => 'text',
            'title'    => __( 'Youtube', 'ex_themes' ),
            //'subtitle' => __( 'This must be a URL.', 'ex_themes' ),
            //'validate' => 'url',
            'default'  => 'https://www.youtube.com/c/seomakassar',
            'required' => array( 'ex_themes_social_media_sidebar_active_', '=', true )
        ),
        array(
            'id'       => 'instagram_url',
            'type'     => 'text',
            'title'    => __( 'Instagram', 'ex_themes' ),
            //'subtitle' => __( 'This must be a URL.', 'ex_themes' ),
            //'validate' => 'url',
            'default'  => 'https://www.instagram.com/exthemescom/',
            'required' => array( 'ex_themes_social_media_sidebar_active_', '=', true )
        ),
        array(
            'id'       => 'telegram_url',
            'type'     => 'text',
            'title'    => __( 'Telegram', 'ex_themes' ),
            //'subtitle' => __( 'This must be a URL.', 'ex_themes' ),
            //'validate' => 'url',
            'default'  => '#',
            'required' => array( 'ex_themes_social_media_sidebar_active_', '=', true )
        ),
        array(
            'id'       => 'pinterest_url',
            'type'     => 'text',
            'title'    => __( 'Pinterest', 'ex_themes' ),
            //'subtitle' => __( 'This must be a URL.', 'ex_themes' ),
            //'validate' => 'url',
            'default'  => 'https://pinterest.com/exthemes',
            'required' => array( 'ex_themes_social_media_sidebar_active_', '=', true )
        ),
        array(
            'id'       => 'linked_url',
            'type'     => 'text',
            'title'    => __( 'Linkedin', 'ex_themes' ),
            //'subtitle' => __( 'This must be a URL.', 'ex_themes' ),
            //'validate' => 'url',
            'default'  => 'https://www.linkedin.com/in/bangreyblogs',
            'required' => array( 'ex_themes_social_media_sidebar_active_', '=', true )
        ),
        array(
            'id'       => 'VKontakte_url',
            'type'     => 'text',
            'title'    => __( 'VKontakte ', 'ex_themes' ),
            //'subtitle' => __( 'This must be a URL.', 'ex_themes' ),
            //'validate' => 'url',
            'default'  => '#',
            'required' => array( 'ex_themes_social_media_sidebar_active_', '=', true )
        ),
    )
) );

Redux::setSection( $opt_name, array(
    'title'            => __( 'Script Insert', 'ex_themes' ),
    'id'               => 'script_insert',
    'customizer_width' => '500px',
    'icon'             => 'el el-pencil',
    'fields'     => array(
        array(
            'id'       => 'ex_themes_head_on_sections_active_',
            'type'     => 'switch',
            'title'    => __( 'Header Sections', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'header_section',
            'type'     => 'textarea',
            'title'    => __( 'Header Section', 'ex_themes' ),
            'subtitle' => __( 'HTML Allowed', 'ex_themes' ),
            'required' => array( 'ex_themes_head_on_sections_active_', '=', true )
        ),
        array(
            'id'       => 'ex_themes_footers_sections_active_',
            'type'     => 'switch',
            'title'    => __( 'Footer Sections ', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'ex_themes_footers_sections_',
            'type'     => 'textarea',
            'title'    => __( 'Footer Section', 'ex_themes' ),
            'subtitle' => __( 'HTML Allowed', 'ex_themes' ),
            'required' => array( 'ex_themes_footers_sections_active_', '=', true )
        ),
    )
) );
Redux::setSection( $opt_name, array(
    'title'            => __( 'Extractor APK Options', 'ex_themes' ),
    'id'               => 'option_extractor_apk',
    'customizer_width' => '500px',
    'icon'             => 'el el-adjust-alt',
    'fields'     => array(
        array(
        'id'       => 'ex_themes_extractor_apk_status_post_',
        'type'     => 'select',
        'title'    => __('Select for Status Post', 'redux-framework-demo'), 
        'subtitle' => __('<i>Draft or Publish * <b>Publish</b> to auto post</i>', 'redux-framework-demo'),		
        //'desc'     => __('<i>* Draft or Publish</i>', 'redux-framework-demo'),
        // Must provide key => value pairs for select options
        'options'  => array(
            'draft' => 'Draft',
            'publish' => 'Publish'
			),
				'default'  => 'draft',		
		),		
		array(
        'id'       => 'ex_themes_extractor_apk_title_',
        'type'     => 'select',
        'title'    => __('Select for Title Post', 'redux-framework-demo'), 
        'subtitle' => __('<i>* Title Mods or Title App Name PlayStore</i>', 'redux-framework-demo'),		
        //'desc'     => __('<i>* Title with Mods or Title from App Name</i>', 'redux-framework-demo'),
        // Must provide key => value pairs for select options
        'options'  => array(
            'title' => 'Title Mods',
            'title_GP' => 'Title PlayStore'
			),
				'default'  => 'title_GP',		
		),		
		array(
        'id'       => 'ex_themes_extractor_apk_permalink_',
        'type'     => 'select',
        'title'    => __('Select for Permalink Post', 'redux-framework-demo'), 
        'subtitle' => __('<i>* Permalink Title with Mods or Permalink Title from App Name</i>', 'redux-framework-demo'),		
        //'desc'     => __('<i>* Title with Mods or Title from App Name</i>', 'redux-framework-demo'),
        // Must provide key => value pairs for select options
        'options'  => array(
            'title' => 'Permalink Title with Mods',
            'title_GP' => 'Permalink Title App Name'
			),
				'default'  => 'title_GP',		
		),		
		array(
            'id'       => 'ex_themes_extractor_apk_debug_',
            'type'     => 'switch',
            'title'    => __( 'Showing Debugs', 'ex_themes' ),
			'subtitle' => __('<i>for developer only *if you dont know leave it default OFF </i>', 'redux-framework-demo'),		
            'default'  => false
        ),
		
        
		
    )
) );

Redux::setSection( $opt_name, array(
    'title'            => __( 'Options', 'ex_themes' ),
    'id'               => 'optionz',
    'customizer_width' => '500px',
    'icon'             => 'el el-adjust-alt',
    'fields'     => array(
        array(
            'id'       => 'ex_themes_thumbnails_gpstore_active_',
            'type'     => 'switch',
            'title'    => __( 'Enable Thumbnails Google Play', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        /* array(
                'id'       => 'ex_themes_fake_view_active_',
                'type'     => 'switch',
                'title'    => __( 'Enable Fake Views', 'ex_themes' ), 
                //'subtitle' => __( '<br> ', 'ex_themes' ), 
                'default'  => false
            ),
        */
        
        array(
               'id'       => 'ex_themes_minify_activate_',
               'type'     => 'switch',
               'title'    => __( 'Enable Minify', 'ex_themes' ), 
               //'subtitle' => __( '<br> ', 'ex_themes' ), 
               'default'  => false
           ),
      
        array(
            'id'       => 'ex_themes_photon_cdn_activate_',
            'type'     => 'switch',
            'title'    => __( 'Enable CDN by WP.com', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
        array(
            'id'       => 'ex_themes_remove_version_scripts_styles_activate_',
            'type'     => 'switch',
            'title'    => __( 'Remove all version scripts', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
		array(
            'id'       => 'ex_themes_disable_emojis_activate_',
            'type'     => 'switch',
            'title'    => __( 'Remove emojis script', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
		array(
            'id'       => 'ex_themes_add_img_title_activate_',
            'type'     => 'switch',
            'title'    => __( 'Add Automatic image title tag', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
		array(
            'id'       => 'ex_themes_async_scripts_activate_',
            'type'     => 'switch',
            'title'    => __( 'Add Defer & Async Attributes', 'ex_themes' ),
            //'subtitle' => __( '<br> ', 'ex_themes' ),
            'default'  => false
        ),
		 array(
                'id'       => 'ex_themes_bar_admin_activate_',
                'type'     => 'switch',
                'title'    => 'Hide Bar Admin',
                //'subtitle' => 'Click <code>On</code> to Activate.',
                'default'  => false
            ),
		array(
                'id'       => 'ex_themes_bar_admin_bottom_activate_',
                'type'     => 'switch',
                'title'    => 'Put Bar Admin on Bottom',
                //'subtitle' => 'Click <code>On</code> to Activate.',
                'default'  => false
            ),
			
		/**/
		array(
                'id'       => 'ex_themes_mask_link_',
                'type'     => 'switch',
                'title'    => 'Activate Masking Link  ',
                'subtitle' => '*<i>only working for .apk link</i>',
                'default'  => false
            ),	
			
		 

    )
) );