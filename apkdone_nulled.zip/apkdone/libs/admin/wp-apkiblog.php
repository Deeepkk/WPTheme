<?php
if ( ! defined( 'ABSPATH' ) ) exit;
define('ex_themes_name_extractor_','Extractor APK');
define('ex_themes_version_extractor_','1.0');
define('spacescore','v');
define('BY','ex-themes');
define('FB','https://facebook.com/ex.themes.coms');
define('TW','https://twitter.com/ExThemes');
define('IG','https://www.instagram.com/exthemescom/');
define('YT','https://youtube.com/c/seomakassar');

function wp_apk_mod_admin_menu() {
    add_menu_page(
        __( ''.ex_themes_name_extractor_.' ', 'ex_themes_' ),
        ''.ex_themes_name_extractor_.' ',
        'manage_options',
        'wp_apk_mod_menu',
        'wp_docs',
        'dashicons-share-alt',
        //plugins_url( '/img/imdb.png' ),
        100
    );
    add_submenu_page( 'wp_apk_mod_menu', 'play.google.com', 'PLAY.GOOGLE.COM', 'manage_options', 'wp_apk_googleplay', 'wp_googleplay' );
    add_submenu_page( 'wp_apk_mod_menu', 'apkhome.net', 'APKHOME.NET', 'manage_options', 'wp_apk_apkhome', 'wp_apkhome' );
    add_submenu_page( 'wp_apk_mod_menu', 'happymod.com', 'HAPPYMOD.COM', 'manage_options', 'wp_apk_happymod', 'wp_happymod' );
    add_submenu_page( 'wp_apk_mod_menu', 'apkdownload.cc', 'APKDOWNLOAD.CC', 'manage_options', 'wp_apk_apkdownload', 'wp_apkdownload' );
    add_submenu_page( 'wp_apk_mod_menu', 'setting', 'SETTING', 'manage_options', '_options&tab=13', 'wpwm_settings' );
}
add_action('admin_menu', 'wp_apk_mod_admin_menu');
require_once 'includes/apkhome.php';
require_once 'includes/apkdownload.php';
require_once 'includes/happymod.php';
require_once 'includes/googleplay.php';
require_once 'includes/core.php';
require_once 'includes/docs.php';
require_once 'includes/setting.php';
require_once 'includes/dom.php';
function webp_upload_mimes($existing_mimes) {
    $existing_mimes['webp'] = 'image/webp';
    return $existing_mimes;
}
add_filter('mime_types', 'webp_upload_mimes'); 