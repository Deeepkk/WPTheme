<?php global $opt_themes; if($opt_themes['ex_themes_extractor_apk_debug_']) { ?> 
<?php if($gets_data) { ?>
<?php 
$urlX = $url;
$parse = parse_url($urlX);
$urlX1 = preg_replace("/^([a-zA-Z0-9].*\.)?([a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z.]{2,})$/", '$2', $parse['host']);
?>

<div class="play_menu">
<h3 style="color:red">Showing Debug from <b style="text-transform:uppercase!important;"><a href='<?php echo $url; ?>' target="_blank"><?php echo $urlX1; ?></a></b></h3>

<img src='<?php print_r( $gets_data['poster_GP']) ?>' height='150px' width='150px' />
<br>
Paid1 ==> <?php print_r( $gets_data['paid_GP1']) ?>
<br>
Paid2 ==> <?php print_r( $gets_data['paid_GP2']) ?>
<br>
title_GP  ==> <?php print_r( $gets_data['title_GP']) ?>
<br>
ID ==> <?php print_r( $gets_data['GP_ID']) ?>
<br>
Google Play ==> <a href='https://play.google.com/store/apps/details?id=<?php print_r( $gets_data['title_id']) ?>'><?php print_r( $gets_data['GP_ID']) ?></a>
<br>
Title ==> <?php print_r( $gets_data['title']) ?>
<br>
Mods ==> <?php print_r( $gets_data['mods']) ?>
<br>
Version ==> <?php print_r( $gets_data['version']) ?>
<br>
Download Link ==> <?php print_r( $gets_data['downloadlink']) ?>
<br>
Name Download Link ==> <?php print_r( $gets_data['namedownloadlink']) ?>
<br>
Download Link 2 ==> <?php print_r( $gets_data['downloadlink2']) ?>
<br>
Name Download Link 2 ==> <?php print_r( $gets_data['namedownloadlink2']) ?>
<br>
<h3 style="color:red">Google Play</h3>
Title  ==> <?php print_r( $gets_data['title_GP']) ?>
<br>
Youtube id ==> <?php print_r( $gets_data['youtube_GP']) ?>
<br>
Desc  ==> <?php print_r( $gets_data['desck_GP']) ?>
<br>
Developers ==> <?php print_r( $gets_data['developers_GP']) ?>
<br>
Installs ==> <?php print_r( $gets_data['installs_GP']) ?>
<br>
Updates ==> <?php print_r( $gets_data['updates_GP']) ?>
<br>
What News ==> <?php print_r( $gets_data['whatnews_GP']) ?>
<br>
Requires ==> <?php print_r( $gets_data['requires_GP']) ?>
<br>
Concentrated ==> <?php print_r( $gets_data['contentrated_GP']) ?>
<br>
Rate ==> <?php print_r( $gets_data['rated_GP']) ?>
<br>
Rating ==> <?php print_r( $gets_data['ratings_GP']) ?>
<br>
Genre ==> <?php print_r( $gets_data['genres_GP']) ?>
<br> 
Version ==> <?php print_r( $gets_data['version_GP']) ?>
<br> 
Size ==> <?php print_r( $gets_data['sizes_GP']) ?>
<br>
<textarea style="width:98%"  name="play.google.com" class="play_menu" rows="25%" cols="100%">
<?php print_r( $gets_data['articlebody_GP']) ?>
</textarea> 
<?php print_r( $gets_data['']) ?>
</div> 
<?php } ?>
<?php } ?>