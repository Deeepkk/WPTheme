<?php
class getslinks
{	
	public function get_web_info($title)
	{
		$getLinkID = $this->get_web_id_from_search(trim($title));
		if($getLinkID === NULL){
			$arr = array();
			$arr['error'] = "No Title found in Search Results!";
			return $arr;
		}
		return $this->get_webs_info_by_id($getLinkID);
	}
	public function get_webs_info_by_id($getLinkID)
	{
		$arr = array();	 		
		$sources = "https://play.google.com/store/apps/details?id=" . trim($getLinkID) . ""; 
		return $this->scrape_web_info($sources);
	}
	public function scrape_web_info($sources)
	{				
		$arr = array();	 
		//************************[ Extra Functions ]******************************
		/* GOOGLE PLAY */ 	 
		/*
		<link rel="canonical" href="https:\/\/play.google.com\/store\/.*?\/details?id=(.*?)&amp;hl=.*?">
		$title_id = $this->match('/<link rel="canonical" href="https:\/\/play.google.com\/store\/.*?\/details?id=(.*?)&amp;hl=.*?">/ms', $gp1, 1);		
		if(empty($title_id) || !preg_match("/(.*?)/i", $title_id)) {
			$arr['error'] = "No Title found";
			return $arr;
		}
		$arr['title_id'] = $title_id;
		*/
		$titleId = $arr['GP_ID'];		 
		
		$gp1 = $this->geturl("${sources}");
		$gp = "https://play.google.com/store/apps/details?id=" . $titleId . "&hl=en"; 
		$gpindox = "https://play.google.com/store/apps/details?id=" . $titleId . "&hl=id"; 
		$gp11 = $this->geturl("${gp}");
		$gpindo = $this->geturl("${gpindox}"); 
		$arr['GP_ID_2'] = $this->match('/<meta property="og:url" content="(.*?)">/ms', $gp1, 1);	
		$arr['GP_ID'] = $this->match('/<meta name="appstore:bundle_id" content="(.*?)">/ms', $gp1, 1);	
		//$arr['GP_ID'] = str_replace('https://play.google.com/store/apps/details?id=', '', $arr['GP_ID']);
		if ($arr['GP_ID'] === FALSE or $arr['GP_ID'] == '') $arr['GP_ID'] = $arr['GP_ID_2'];	
		$arr['title_id'] = $this->match('/<meta name="appstore:bundle_id" content="(.*?)">/ms', $gp1, 1);	
		$arr['title_id'] = str_replace('https://play.google.com/store/apps/details?id=', '', $arr['title_id']);
		$arr['GP_ID99'] = $this->match('/<meta name="appstore:bundle_id" content="(.*?)">/ms', $gp1, 1);	
		$arr['GP_ID99'] = str_replace('https://play.google.com/store/apps/details?id=', '', $arr['GP_ID99']);
		$arr['title2'] = $this->match('/<h1 class="AHFaub".*?>.*?<span >(.*?)<\/span>.*?<\/h1>/msi', $gp1, 1);	
		$arr['title2'] = preg_replace('/- Apps on Google Play/is', '',  $arr['title2']);
		$arr['title'] = $this->match('/<title id="main-title">(.*?)<\/title>/msi', $gp1, 1);
		$arr['title'] = preg_replace('/- Apps on Google Play/is', '',  $arr['title']);
		$arr['title_GP3'] = $this->match('/<title id="main-title">(.*?)<\/title>/msi', $gp1, 1);	
		$arr['title_GP3'] = preg_replace('/- Apps on Google Play/is', '',  $arr['title_GP3']);
		$arr['title_GP2'] = $this->match('/<h1 class="AHFaub".*?>.*?<span >(.*?)<\/span>.*?<\/h1>/msi', $gp1, 1);	
		$arr['title_GP2'] = preg_replace('/- Apps on Google Play/is', '',  $arr['title_GP2']);
		$arr['title_GP'] = $this->match('/<title id="main-title">(.*?)<\/title>/msi', $gp1, 1);
		$arr['title_GP'] = preg_replace('/- Apps on Google Play/is', '',  $arr['title_GP']);
		$arr['title_GP3'] = $this->match('/<title id="main-title">(.*?)<\/title>/msi', $gp1, 1);	
		$arr['title_GP3'] = preg_replace('/- Apps on Google Play/is', '',  $arr['title_GP3']);
		$arr['poster_GP'] = $this->match('/<div class="xSyT2c">.*?<img.*?src="(.*?)\=.*?".*?>.*?<\/div>/msi', $gp1, 1);
		if(empty($arr['poster_GP']) || !preg_match("/(.*?)/i", $arr['poster_GP'])) {
			$arr['error'] = "No Title found";
			return $arr;
		}
		$arr['articlebody_GP'] = $this->match('/<div jsname="sngebd">(.*?)<\/div>/msi', $gp1, 1);
		$arr['articlebody_GP'] = preg_replace('/<a.*?">(.*?)<\/a>/is', '$1',  $arr['articlebody_GP']);		
		$arr['desck_GP'] = trim(strip_tags($this->match('/<div jsname="sngebd">(.*?)\..*?/msi', $gp1, 1)));
		$arr['contentrated_GP'] = trim(strip_tags($this->match('/<div class="KmO8jd"><img.*?alt="(.*?)".*?><\/div>/msi', $gp1, 1)));		
		$arr['rated_GP'] = trim(strip_tags($this->match('/<div class="BHMmbe" aria-label=".*?">(.*?)<\/div>/msi', $gp1, 1)));
		$arr['ratings_GP'] = trim(strip_tags($this->match('/<span class="EymY4b"><span class="O3QoBc hzfjkd"><\/span><span class="" aria-label=".*?">(.*?)<\/span> total<\/span>/msi', $gp1, 1)));
		$arr['genres_GP'] = $this->match('/<div class="qQKdcc">.*?<span class="T32cc UAO9ie"><a itemprop="genre".*?>(.*?)<\/a><\/span>.*?<\/div>/msi', $gp1, 1);		
		$arr['youtube_GP'] = $this->match('/<div class="TdqJUe">.*?<button.*?data-trailer-url=".*?\/embed\/(.*?)\?.*?".*?><\/button>.*?<\/div>/msi', $gp1, 1);		
		$arr['requires_GP'] = $this->match('/<div class="hAyfc">.*?<div class="BgcNfc">Requires Android<\/div>.*?<span class="htlgb">.*?<div class="IQ1z0d">.*?<span class="htlgb">(.*?)<\/span>.*?<\/div>.*?<\/span>.*?<\/div>/msi', $gp1, 1);
		$arr['requires_GP'] = str_replace('Varies with device', '4.4 and up',  $arr['requires_GP']);
		$arr['version_GP'] = $this->match('/<div class="hAyfc">.*?<div class="BgcNfc">.*?Current Version<\/div>.*?<span class="htlgb">.*?<div class="IQ1z0d">.*?<span class="htlgb">(.*?)<\/span>.*?<\/div>.*?<\/span>.*?<\/div>/msi', $gp1, 1);
		/*<div class="hAyfc"><div class="BgcNfc">Size</div><span class="htlgb"><div class="IQ1z0d"><span class="htlgb">112M</span></div></span></div>*/
		$arr['sizes_GP'] = $this->match('/<div class="hAyfc">.*?<div class="BgcNfc">.*?Size<\/div>.*?<span class="htlgb">.*?<div class="IQ1z0d">.*?<span class="htlgb">(.*?)<\/span>.*?<\/div>.*?<\/span>.*?<\/div>/msi', $gp1, 1);	
		$arr['version_GP'] = str_replace('Varies with device', $arr['version'],  $arr['version_GP']);
		$arr['developers_GP'] = $this->match('/<span class="T32cc UAO9ie">.*?<a.*?>(.*?)<\/a>.*?<\/span>/msi', $gp1, 1);
		$arr['developers2_GP'] = trim(strip_tags($this->match('/<div class="hAyfc"><div class="BgcNfc">Offered By<\/div><span class="htlgb"><div class="IQ1z0d"><span class="htlgb">(.*?)<\/span><\/div><\/span><\/div>/msi', $gp1, 1)));
		$arr['installs_GP'] = trim(strip_tags($this->match('/<div class="hAyfc">.*?<div class="BgcNfc">Installs<\/div>.*?<span class="htlgb">.*?<div class="IQ1z0d">.*?<span class="htlgb">(.*?)<\/span>.*?<\/div>.*?<\/span>.*?<\/div>/msi', $gp1, 1)));		
		$arr['updates_GP'] = trim(strip_tags($this->match('/<div class="hAyfc">.*?<div class="BgcNfc">Updated<\/div>.*?<span class="htlgb">.*?<div class="IQ1z0d">.*?<span class="htlgb">(.*?)<\/span>.*?<\/div>.*?<\/span>.*?<\/div>/msi', $gp1, 1)));		
		$arr['updates_GP1'] = trim(strip_tags($this->match('/<label>Update :<\/label>.*?<\/div>.*?<div class="col-xs-7 item">.*?<time.*?>(.*?)<\/time>.*?<\/div>.*?<\/div>/msi', $apkgk1, 1)));
		$arr['whatnews_GP'] = $this->match('/<div class="W4P4ne.*?">.*?<h2 class="Rm6Gwb">.*?<\/h2>.*?<div jsname="bN97Pc".*?itemprop="description".*?>.*?<span.*?>(.*?)<\/span>.*?<div class="n1EcZc uhqVLe" jsname="xBmnf" jsaction="JIbuQc:ornU0b">.*?/msi', $gp1, 1);
		/*
		$arr['whatnews_GP'] = preg_replace('/<div.*?>/is', '',  $arr['whatnews_GP']);
		$arr['whatnews_GP'] = str_replace('</div>', '',  $arr['whatnews_GP']);
		$arr['whatnews_GP'] = preg_replace('/<span.*?>/is', '',  $arr['whatnews_GP']);
		$arr['whatnews_GP'] = str_replace('</span>', '',  $arr['whatnews_GP']);
		$arr['whatnews_GP'] = str_replace('<br>', ' ',  $arr['whatnews_GP']);	
		*/
		$arr['whatnews_GP1'] = $this->match_all('/<div jsname="bN97Pc" class="DWPxHb" itemprop="description">(.*?)<\/div>/ms', $this->match('/<div class="W4P4ne ">.*?<div class="wSaTQd">.*?<h2 class="Rm6Gwb">What&#39;s New<\/h2>.*?<\/div>.*?<div jscontroller="IsfMIf" jsaction="rcuQ6b:npT2md" class="PHBdkd" data-content-height="144" jsshadow>(.*?)<div class="n1EcZc uhqVLe" jsname="xBmnf" jsaction="JIbuQc:ornU0b">/ms', $gp1, 1), 1);
		/*
		$arr['whatnews_GP1'] = preg_replace('/<div.*?>/is', '',  $arr['whatnews_GP1']);
		$arr['whatnews_GP1'] = str_replace('</div>', '',  $arr['whatnews_GP1']);
		$arr['whatnews_GP1'] = preg_replace('/<span.*?>/is', '',  $arr['whatnews_GP1']);
		$arr['whatnews_GP1'] = str_replace('</span>', '',  $arr['whatnews_GP1']);
		$arr['whatnews_GP1'] = str_replace('<br>', ' ',  $arr['whatnews_GP1']);		
		*/
		$arr['images_GP'] = $this->match_all('/<img.*?srcset="(.*?)\=.*?".*?>/ms', $this->match('/<div jsname="CmYpTb" class="JiLaSd u3EI9e">(.*?)<div class="awJjId.*?/ms', $gp1, 1), 1);
		$arr['images_GP2'] = $this->match_all('/<img.*?data-src="(.*?)\=.*?".*?>/ms', $this->match('/<div jsname="CmYpTb" class="JiLaSd u3EI9e">(.*?)<div class="awJjId.*?/ms', $gp1, 1), 1);
		$arr['images_GP3'] = $this->match_all('/<img.*?data-srcset="(.*?)\=.*?".*?>/ms', $this->match('/<div jsname="CmYpTb" class="JiLaSd u3EI9e">(.*?)<div class="awJjId.*?/ms', $gp1, 1), 1);
		$arr['paid_GP'] = $this->match('/<span class="oocvOe">.*?<button aria-label=".*?Buy".*?">.*?d+\(.*?)<\/button>.*?<\/span>/msi', $gp1, 1);
		//$arr['paid_GP'] = preg_replace('/<button.*?">(.*?)<\/button>/is', 'Paid',  $arr['paid_GP']);		
		$arr['paid_GP1'] = $this->match('/<button aria-label=".*?Buy".*?">(.*?)<\/button>/msi', $gp1, 1);
		$arr['paid_GP2'] = $this->match('/<button aria-label=".*?Buy".*?">(.*?)<\/button>/msi', $gp1, 1);
		$arr['paid_GP2'] = preg_replace('/.*?Buy/is', 'Paid',  $arr['paid_GP2']);		
		$arr['paid_GP3'] = $this->match('/<span class="oocvOe">.*?<button aria-label=".*?Buy".*?">(.*?)<\/button>.*?<\/span>/msi', $gp1, 1);
function gambarX21($gp1){
		$gambarX21 = array();
		foreach($this->match_all('/<img.*?data-src="(.*?)".*?>/msi', $this->match('/<div jsname="pCbVjb" class="SgoUSc">(.*?)<div class="awJjId nmBghe".*?><\/div>.*?<\/div>/ms', $gp1, 1), 1) as $m) {
			$gambarX21Match = $this->match_all('/<button class="Q4vdJd".*?>(.*?)<\/button>/ms', $m, 1);
			$akaCountry = trim($akaTitleMatch[0]);
			$gambarX21link = trim($gambarX21Match[1]);
			array_push($gambarX21, $gambarX21link);
		}
		return array_filter($gambarX21);
}
		return $arr;
	}
//************************[ Extra Functions ]******************************
private function get_web_id_from_search($title, $engine = "yahoo"){
		switch ($engine) {
			//case "google":  $nextEngine = "bing";  break;  
			//case "bing":    $nextEngine = "ask";   break;
			case "google":  $nextEngine = "bing";  break;			
			case "bing":    $nextEngine = "ask";   break;
			case "ask":    $nextEngine = "yandex";   break;
			case "yandex":    $nextEngine = "duckduckgo";   break;
			case "duckduckgo":     $nextEngine = FALSE;   break;
			case FALSE:     return NULL;
			default:        return NULL;
		}
		$url = "http://www.${engine}.com/search?q=apkhome.net+" . rawurlencode($title);
		/*
		https://www.gamespot.com/
		*/
		$ids = $this->match_all('/<a.*?href="https:\/\/apkhome.net\/.*?".*?>.*?<\/a>/ms', $this->geturl($url), 1);
		if (!isset($ids[0]) || empty($ids[0])) //if search failed
			return $this->get_web_id_from_search($title, $nextEngine); //move to next search engine
		else
			return $ids[0]; //return first IMDb result
}
private function decode($string, $action = 'e') {
  $secret_key = 'drivekey';
  $secret_iv = 'google';
  $output = false;
  $encrypt_method = "AES-256-CBC";
  $key = hash( 'sha256', $secret_key );
  $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
  if( $action == 'e' ) {
    $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
  }else if( $action == 'd' ){
    $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
  }
  return $output;
}
private function geturl($url){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
		$ip=rand(0,255).'.'.rand(0,255).'.'.rand(0,255).'.'.rand(0,255);
		//$ip=172.69.70.6;
		curl_setopt($ch, CURLOPT_HTTPHEADER, array("REMOTE_ADDR: $ip", "HTTP_X_FORWARDED_FOR: $ip"));
		//curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/".rand(3,5).".".rand(0,3)." (Windows NT ".rand(3,5).".".rand(0,2)."; rv:2.0.1) Gecko/20100101 Firefox/".rand(3,5).".0.1");
		curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:56.0) Gecko/20100101 Firefox/56.0");
		curl_setopt($ch, CURLOPT_REFERER, "http://www.google.com");
		curl_setopt($ch, CURLOPT_AUTOREFERER, true);
		$html = curl_exec($ch);
		curl_close($ch);
		return $html;
}
private function match_all_key_value($regex, $str, $keyIndex = 1, $valueIndex = 2){
		$arr = array();
		preg_match_all($regex, $str, $matches, PREG_SET_ORDER);
		foreach($matches as $m){
			$arr[$m[$keyIndex]] = $m[$valueIndex];
		}
		return $arr;
}
private function match_all($regex, $str, $i = 0){
		if(preg_match_all($regex, $str, $matches) === false)
			return false;
		else
			return $matches[$i];
}
private function match($regex, $str, $i = 0){
		if(preg_match($regex, $str, $match) == 1)
			return $match[$i];
		else
			return false;
}
}
?>