<?php
add_action( 'admin_init', 'ex_themes_install_db_page_' );
function ex_themes_install_db_page_() {
    if ( ! get_option( 'ex_themes_install_db_pages_' ) ) {

	$privacy_policy = array(
    'post_title'     => "Privacy Policy", 
	'post_name' => 'privacy-policy',
    'post_content'   => '', 
    'post_type'      => 'page',
	'post_status'   => 'publish',
    'page_template'  => "template/privacy.php"
	//'page_template'=> ''.get_template_directory_uri(). '/includes/privacy-policy.php'
	);
	$post_id = wp_insert_post( $privacy_policy );
	
	$sitemap = array(
    'post_title'     => "Sitemap", 
	'post_name' => 'sitemap',
    'post_content'   => '',
    'post_type'      => 'page', 
	'post_status'   => 'publish',
    'page_template'  => "template/sitemap.php"
	);
	$post_id = wp_insert_post( $sitemap );

	$about = array(
    'post_title'     => "About", 
	'post_name' => 'about',
    'post_content'   => '',
    'post_type'      => 'page', 
	'post_status'   => 'publish',
    'page_template'  => "template/about.php"
	);
	$post_id = wp_insert_post( $about );
 
	$contact = array(
    'post_title'     => "Contact", 
	'post_name' => 'contact',
    'post_content'   => '',
    'post_type'      => 'page', 
	'post_status'   => 'publish',
    'page_template'  => "template/contact.php"
	);
	$post_id = wp_insert_post( $contact );
 
	$dmca = array(
    'post_title'     => "DMCA", 
	'post_name' => 'dmca',
    'post_content'   => '',
    'post_type'      => 'page', 
	'post_status'   => 'publish',
    'page_template'  => "template/disclaimer.php"
	);
	$post_id = wp_insert_post( $dmca );
 
	$topapps = array(
    'post_title'     => "Top Apps", 
	'post_name' => 'top-apps',
    'post_content'   => '',
    'post_type'      => 'page', 
	'post_status'   => 'publish',
    'page_template'  => "template/template-popular-apps.php"
	);
	$post_id = wp_insert_post( $topapps );
 
	$topgames = array(
    'post_title'     => "Top Games", 
	'post_name' => 'top-games',
    'post_content'   => '',
    'post_type'      => 'page', 
	'post_status'   => 'publish',
    'page_template'  => "template/template-popular-games.php"
	);
	$post_id = wp_insert_post( $topgames );
 
	$toppaid = array(
    'post_title'     => "Paid for free", 
	'post_name' => 'top-paids',
    'post_content'   => '',
    'post_type'      => 'page', 
	'post_status'   => 'publish',
    'page_template'  => "template/template-popular-paids.php"
	);
	$post_id = wp_insert_post( $toppaid ); 
 
    update_option( 'ex_themes_install_db_pages_', true );
    }
	/*set permalink structure*/
	global $wp_rewrite;
	$wp_rewrite->set_permalink_structure( '/%postname%/' );
	$wp_rewrite->flush_rules(); 
}
