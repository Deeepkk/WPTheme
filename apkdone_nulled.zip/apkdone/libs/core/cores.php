<?php
###############################
###    Stop Don't Try Edit  ###
###  if you don't know php  ###
###############################
###      EX-THEMES.COM      ###
### Premium Wordress Themes ###
###############################
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_head_on_sections_() { ?>
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1"/>
    <meta content='yes' name='apple-mobile-web-app-capable' />
    <!-- Chrome, Firefox OS and Opera -->
    <meta content='<?php global $opt_themes; if(($opt_themes['color'] == '')) { } else {} echo $opt_themes['color'];  ?>' name='theme-color'/>
    <!-- Windows Phone -->
    <meta content='<?php global $opt_themes; if(($opt_themes['color'] == '')) { } else {} echo $opt_themes['color'];  ?>' name='msapplication-navbutton-color'/>
    <meta content='<?php global $opt_themes; if(($opt_themes['color'] == '')) { } else {} echo $opt_themes['color'];  ?>' name='apple-mobile-web-app-status-bar-style' />
    <link rel="shortcut icon" href="<?php global $opt_themes; if($opt_themes['aktif_favicon']) echo $opt_themes['favicon']['url']; ?>" type="image/x-icon" />
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "url": "<?php echo esc_url( home_url( '/' ) ); ?>",
      "logo": "<?php global $opt_themes; if($opt_themes['ex_themes_logo_headers_active_']) { ?><?php echo $opt_themes['header_logo']['url']; ?><?php } else { ?><?php echo get_template_directory_uri(); ?>/assetss/img/apkdone.png<?php } ?>",
	  "sameAs": [
	  "<?php echo $opt_themes['facebook_url']; ?>",
	  "<?php echo $opt_themes['twitter_url']; ?>",
	  "<?php echo $opt_themes['instagram_url']; ?>",
	  "<?php echo $opt_themes['youtube_url']; ?>"
	  ]
    }
    </script>
    <?php get_template_part( '/template/styles' ); ?>
    <?php get_template_part( '#/template/styles2' ); ?>
   <?php global $opt_themes; if($opt_themes['ex_themes_head_on_sections_active_']) echo $opt_themes['header_section'];  ?>
   
    <?php global $opt_themes; if($opt_themes['ex_themes_webmaster_tools_active_']) { ?>
	
        <!-- Webmaster Tool Verification -->
        <?php global $opt_themes; if($opt_themes['google_verif']) { ?>
            <meta name="google-site-verification" content="<?php echo $opt_themes['google_verif']; ?>" />
        <?php } ?>
        <?php global $opt_themes; if($opt_themes['bing_verif']) { ?>
            <meta name="msvalidate.01" content="<?php echo $opt_themes['bing_verif']; ?>" />
        <?php } ?>
        <?php global $opt_themes; if($opt_themes['yandex_verif']) { ?>
            <meta name="yandex-verification" content="<?php echo $opt_themes['yandex_verif']; ?>" />
        <?php } ?>
        <?php global $opt_themes; if($opt_themes['pinterest_verif']) { ?>
            <meta name="p:domain_verify" content="<?php echo $opt_themes['pinterest_verif']; ?>"/>
        <?php } ?>
        <?php global $opt_themes; if($opt_themes['baidu_verif']) { ?>
            <meta name="baidu-site-verification" content="<?php echo $opt_themes['baidu_verif']; ?>" />
        <?php } ?>
        <!-- Webmaster Tool Verification -->
		
    <?php } ?>
<?php }
add_shortcode('ex_themes_head_on_sections_', 'ex_themes_head_on_sections_');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_logo_headers_() { ?>
    <?php global $opt_themes;
    if($opt_themes['ex_themes_logo_headers_active_']) { ?>
        <img src="<?php echo $opt_themes['header_logo']['url']; ?>" data-spai="1" alt="<?php echo get_option("blogname") ?>" data-spai-upd="143" width="143" height="30">
    <?php } else { ?>
        <img src="<?php echo get_template_directory_uri(); ?>/assetss/img/apkdone.png" data-spai="1" alt="<?php echo get_option("blogname") ?>" data-spai-upd="143" width="143" height="30">
    <?php } ?>
<?php }
add_shortcode('ex_themes_logo_headers_', 'ex_themes_logo_headers_');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_headers_menu_() {
    ?>
    <?php $mainnav = array(
        'theme_location'  => 'menu_header',
        'container'       => false,
        'echo'            => false,
        'before'          => '',
        'after'           => '',
        'link_before'     => '',
        'link_after'      => '',
        'items_wrap'      => '%3$s',
        //'items_wrap' => '<ul id="%1$s" class="%2$s">'.'%3$s'.'<li>'.'<a href="#">'.'sasda'.'</a>'.'</li>'.'</ul>',
        //'item_spacing'    => 'preserve',
        'depth'           => 0,
        'walker'          => new ex_themes_headers_menu_ ,
    );
    echo strip_tags(wp_nav_menu( $mainnav ), '<li><a><i><span>' );
    ?>
<?php }
add_shortcode('ex_themes_headers_menu_', 'ex_themes_headers_menu_');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_footer_on_sections_() { ?>
    <footer class="footer" style="padding: 1.25rem;">
        <div class="container" il_cc1="2" data-word-count="20" data-p-count="1">
            <div class="footer-menu" id="menu-footer">
                <div class="menu-footer-info-container">
                    <ul id="menu-footer-list" class="menu">
                        <?php ex_themes_footer_menus_(); ?>
                    </ul>
                </div>
            </div>
            <?php ex_themes_copyright_(); ?>
            <?php ex_themes_footers_social_media_(); ?>
        </div>
    </footer>
    <?php global $opt_themes; if($opt_themes['ex_themes_footers_code_active_']) echo $opt_themes['ex_themes_footers_code_']; ?>
    <?php global $opt_themes; if($opt_themes['ex_themes_footers_sections_active_']) echo $opt_themes['ex_themes_footers_sections_']; ?>
    <script src="<?php echo get_template_directory_uri(); ?>/assetss/js/scripts.js"></script>
    <script>var timeOut;function scrollToTop(){0!=document.body.scrollTop||0!=document.documentElement.scrollTop?(window.scrollBy(0,-50),timeOut=setTimeout("scrollToTop()",10)):clearTimeout(timeOut)}window.onscroll=function(){50<document.body.scrollTop||50<document.documentElement.scrollTop?backtop.style.display="block":backtop.style.display="none"};var backtop=document.getElementById("backtop");backtop.addEventListener("click",scrollToTop);function lazyscript(e){if(e!=""){var t=document.createElement("script");t.type="text/javascript",t.async=!0,t.src=e;var n=document.getElementsByTagName("script")[0];n.parentNode.insertBefore(t,n)}}!function(){var e=!1;function t(){!1===e&&(e=!0,document.removeEventListener("scroll",t),document.removeEventListener("mousemove",t),document.removeEventListener("mousedown",t),document.removeEventListener("touchstart",t),lazyscript(" "),(adsbygoogle=window.adsbygoogle||[]).push({google_ad_client:"ca-pub-6216480716201798",enable_page_level_ads:!0,overlays:{bottom:!0}}),function(e,t,n,o){e[o]=e[o]||[],e[o].push({"gtm.start":(new Date).getTime(),event:"gtm.js"});var a=t.getElementsByTagName(n)[0],c=t.createElement(n);c.async=!0,c.src=" ",a.parentNode.insertBefore(c,a)}(window,document,"script","dataLayer"))}document.addEventListener("scroll",t),document.addEventListener("mousemove",t),document.addEventListener("mousedown",t),document.addEventListener("touchstart",t),document.addEventListener("load",function(){document.body.clientHeight!=document.documentElement.clientHeight&&0==document.documentElement.scrollTop&&0==document.body.scrollTop||t()})}();
    </script>
<?php }
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_copyright_() { ?>     
<p class="copyright"><?php global $opt_themes; if($opt_themes['ex_themes_footers_copyrights_active_']) { ?>
<?php echo $opt_themes['ex_themes_footers_copyrights_code_']; ?>
<?php } else { ?>
Developer by <a href="https://ex-themes.com" title="premium wordpress themes"><strong style="text-transform: capitalize;">ex-themes.com</strong></a>
<?php } ?></p>
<?php }
add_shortcode('ex_themes_footer_on_sections_', 'ex_themes_footer_on_sections_');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_footer_menus_() {
    ?>
    <?php $footermenu = array(
        'theme_location'  => 'menu_footer',
        'container'       => false,
        'echo'            => false,
        'before'          => '',
        'after'           => '',
        'link_before'     => '',
        'link_after'      => '',
        'items_wrap'      => '%3$s',
        //'items_wrap' => '<ul id="%1$s" class="%2$s">'.'%3$s'.'<li>'.'<a href="#">'.'sasda'.'</a>'.'</li>'.'</ul>',
        //'item_spacing'    => 'preserve',
        'depth'           => 0,
        //'walker'          => new ex_themes_headers_menu_ ,
    );
    echo strip_tags(wp_nav_menu( $footermenu ), '<li><a>' );
    ?>
<?php }
add_shortcode('ex_themes_footer_menus_', 'ex_themes_footer_menus_');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_footers_social_media_() { ?>
    <div class="social-network">
        <?php global $opt_themes; if($opt_themes['facebook_url']) { ?><a href="<?php echo $opt_themes['facebook_url']; ?>" rel="nofollow noreferrer" target="_blank" title="Follow <?php echo get_option("blogname") ?> on Facebook"> <svg role="img" width="14" height="14" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path fill="<?php global $opt_themes; if(($opt_themes['color'] == '')) { } else {} echo $opt_themes['color'];  ?>" d="M23.9981 11.9991C23.9981 5.37216 18.626 0 11.9991 0C5.37216 0 0 5.37216 0 11.9991C0 17.9882 4.38789 22.9522 10.1242 23.8524V15.4676H7.07758V11.9991H10.1242V9.35553C10.1242 6.34826 11.9156 4.68714 14.6564 4.68714C15.9692 4.68714 17.3424 4.92149 17.3424 4.92149V7.87439H15.8294C14.3388 7.87439 13.8739 8.79933 13.8739 9.74824V11.9991H17.2018L16.6698 15.4676H13.8739V23.8524C19.6103 22.9522 23.9981 17.9882 23.9981 11.9991Z">
                </path>
            </svg> </a> <?php } ?>
        <?php global $opt_themes; if($opt_themes['twitter_url']) { ?><a href="<?php echo $opt_themes['twitter_url']; ?>" rel="nofollow noreferrer" target="_blank" title="Follow <?php echo get_option("blogname") ?> on Twitter"> <svg role="img" width="14" height="14" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path fill="<?php global $opt_themes; if(($opt_themes['color'] == '')) { } else {} echo $opt_themes['color'];  ?>" d="M23.954 4.569c-.885.389-1.83.654-2.825.775 1.014-.611 1.794-1.574 2.163-2.723-.951.555-2.005.959-3.127 1.184-.896-.959-2.173-1.559-3.591-1.559-2.717 0-4.92 2.203-4.92 4.917 0 .39.045.765.127 1.124C7.691 8.094 4.066 6.13 1.64 3.161c-.427.722-.666 1.561-.666 2.475 0 1.71.87 3.213 2.188 4.096-.807-.026-1.566-.248-2.228-.616v.061c0 2.385 1.693 4.374 3.946 4.827-.413.111-.849.171-1.296.171-.314 0-.615-.03-.916-.086.631 1.953 2.445 3.377 4.604 3.417-1.68 1.319-3.809 2.105-6.102 2.105-.39 0-.779-.023-1.17-.067 2.189 1.394 4.768 2.209 7.557 2.209 9.054 0 13.999-7.496 13.999-13.986 0-.209 0-.42-.015-.63.961-.689 1.8-1.56 2.46-2.548l-.047-.02z">
                </path>
            </svg> </a> <?php } ?>
        <?php global $opt_themes; if($opt_themes['instagram_url']) { ?><a href="<?php echo $opt_themes['instagram_url']; ?>" rel="nofollow noreferrer" target="_blank" title="Follow <?php echo get_option("blogname") ?> on Instagram"> <svg role="img" width="14" height="14" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <title>Instagram icon</title>
                <path fill="<?php global $opt_themes; if(($opt_themes['color'] == '')) { } else {} echo $opt_themes['color'];  ?>" d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.899 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.899-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z">
                </path>
            </svg> </a> <?php } ?>
        <?php global $opt_themes; if($opt_themes['youtube_url']) { ?><a href="<?php echo $opt_themes['youtube_url']; ?>" rel="nofollow noreferrer" target="_blank" title="Follow <?php echo get_option("blogname") ?> on Youtube"> <svg role="img" width="14" height="14" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <title>YouTube icon</title>
                <path fill="<?php global $opt_themes; if(($opt_themes['color'] == '')) { } else {} echo $opt_themes['color'];  ?>" d="M23.495 6.205a3.007 3.007 0 0 0-2.088-2.088c-1.87-.501-9.396-.501-9.396-.501s-7.507-.01-9.396.501A3.007 3.007 0 0 0 .527 6.205a31.247 31.247 0 0 0-.522 5.805 31.247 31.247 0 0 0 .522 5.783 3.007 3.007 0 0 0 2.088 2.088c1.868.502 9.396.502 9.396.502s7.506 0 9.396-.502a3.007 3.007 0 0 0 2.088-2.088 31.247 31.247 0 0 0 .5-5.783 31.247 31.247 0 0 0-.5-5.805zM9.609 15.601V8.408l6.264 3.602z">
                </path>
            </svg> </a> <?php } ?>
        <?php global $opt_themes; if($opt_themes['telegram_url']) { ?><a href="<?php echo $opt_themes['telegram_url']; ?>" rel="nofollow noreferrer" target="_blank" title="Follow <?php echo get_option("blogname") ?> on Telegram"> <svg role="img" width="14" height="14" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <title>Telegram icon</title>
                <path fill="<?php global $opt_themes; if(($opt_themes['color'] == '')) { } else {} echo $opt_themes['color'];  ?>" d="M23.91 3.79L20.3 20.84c-.25 1.21-.98 1.5-2 .94l-5.5-4.07-2.66 2.57c-.3.3-.55.56-1.1.56-.72 0-.6-.27-.84-.95L6.3 13.7l-5.45-1.7c-1.18-.35-1.19-1.16.26-1.75l21.26-8.2c.97-.43 1.9.24 1.53 1.73z">
                </path>
            </svg> </a><?php } ?>
    </div>
<?php }
add_shortcode('ex_themes_footers_social_media_', 'ex_themes_footers_social_media_');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_related_posts_() { ?>
    <?php global 
	$opt_themes; 
	$activate = $opt_themes['ex_themes_related_posts_active_'];
    $numbers = $opt_themes['ex_themes_related_posts_numbers_'];
    $titles = $opt_themes['ex_themes_related_posts_title_'];
    //if (($activate == '1'))    
	if($activate) { ?>
        <div class="block-title">
            <div class="atitle">
                <p><?php echo $titles ?></p>
            </div>
        </div>
        <div class="columns is-multiline">
            <?php
            $categories = get_the_category($post->ID);
            if ($categories) {
                $category_ids = array();
                foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
                $args=array(
                    //'tag' => $tags->slug,
                    'category__in' => $category_ids,
                    'post__not_in' => array($post->ID),
                    'posts_per_page'=> $numbers, // Number of related posts that will be shown.
                    'caller_get_posts'=> 1
                );
                $my_query = new WP_Query( $args );
                if( $my_query->have_posts() ) {
                    while ($my_query->have_posts()) : $my_query->the_post(); ?>
                        <a href="<?php the_permalink() ?>" class="column app is-4 post post-<?php echo $postcounter ;?>" title="<?php the_title(); ?>">
                            <div>
							<?php
                                global $wpdb, $post;
                                $thumbnails = get_post_meta( $post->ID, 'wp_poster_GP', true );
                                ?>
                                <?php global $opt_themes; if($opt_themes['ex_themes_thumbnails_gpstore_active_']) { ?>
                                    <img alt="<?php echo get_the_title(); ?>" data-spai="1" class="lzl" src="<?php echo $thumbnails; ?>=w64"  data-spai-upd="64"/>
                                <?php } else { ?>
                                    <?php if (has_post_thumbnail()) { ?>
                                        <img alt="<?php echo get_the_title(); ?>" data-spai="1" class="lzl" src="<?php $image_id = get_post_thumbnail_id(); $image_url = wp_get_attachment_image_src($image_id,'64', true); echo $image_url[0]; ?>"  data-spai-upd="64"/>
                                    <?php } else { ?>
                                        <img alt="<?php echo get_the_title(); ?>" data-spai="1" class="lzl" src="<?php echo get_template_directory_uri(); ?>/assetss/img/lazy.png"  data-spai-upd="64"/>
                                    <?php } ?>
                                <?php } ?>
                            </div>
                            <div> <b><?php the_title(); ?></b>
                                <p>
                                    <span class="tag"><?php echo esc_html( get_post_meta( $post->ID, 'wp_rated_GP', true ) ); ?> ★</span> •
                                    <?php global $opt_themes; $ex_themes_fakees_ = mt_rand(500,9999); if($opt_themes['ex_themes_fake_view_active_']) { ?>
                                        <span class="tag"> <i class="icon-dl"></i> <!--<?php echo numToKs($ex_themes_fakees_); ?>--> <?php echo $ex_themes_fakees_; ?> </span>
                                    <?php } else { ?>
                                        <span class="tag"> <i class="icon-dl"></i> <?= ex_themes_get_post_view_(); ?> </span>
                                    <?php } ?>
                                </p> 
								<span><?php
                                    $i = 0;
                                    foreach((get_the_category()) as $cat) {
                                        echo '' . $cat->cat_name . '';
                                        if (++$i == 1) break;
                                    }
                                    ?>
									</span>
                            </div> </a>
                    <?php endwhile; }
                echo '';
                wp_reset_query();
            }?>
        </div>
        <div class="clearfix"></div>
		<?php } else { ?>
		<?php } ?>
		<?php global 
		$opt_themes; 
		$activate = $opt_themes['ex_themes_you_may_also_active_'];
		$numbers = $opt_themes['ex_themes_you_may_also_numbers_'];
		$titles = $opt_themes['ex_themes_you_may_also_title_'];
		//if (($activate == '1'))    
			if($activate) { ?>
        <div class="block-title">
            <div class="atitle">
                <p><?php echo $titles ?></p>
            </div>
        </div>
        <div class="columns is-multiline">
            <?php
            $categories2 = get_the_category($post->ID);
            if ($categories2) {
                $category_ids2 = array();
                foreach($categories2 as $individual_category2) $category_ids2[] = $individual_category2->term_id;
                $args2=array(
                    //'tag' => $tags->slug,
                    'post_type' => 'post',
                    'post_status' => 'publish',
                    'orderby'   => 'rand',
                    'post__not_in' => array($post->ID),
                    'posts_per_page'=> $numbers,  
                    'caller_get_posts'=> 1
                );
                $my_query = new WP_Query( $args2 );
                if( $my_query->have_posts() ) {
                    while ($my_query->have_posts()) : $my_query->the_post(); ?>
                        <a href="<?php the_permalink() ?>" class="column app is-4 post post-<?php echo $postcounter ;?>" title="<?php the_title(); ?>">
                            <div>
                                <?php
                                global $wpdb, $post;
                                $thumbnails = get_post_meta( $post->ID, 'wp_poster_GP', true );
                                ?>
                                <?php global $opt_themes; if($opt_themes['ex_themes_thumbnails_gpstore_active_']) { ?>
                                    <img alt="<?php echo get_the_title(); ?>" data-spai="1" class="lzl" src="<?php echo $thumbnails; ?>=w64"  data-spai-upd="64"/>
                                <?php } else { ?>
                                    <?php if (has_post_thumbnail()) { ?>
                                        <img alt="<?php echo get_the_title(); ?>" data-spai="1" class="lzl" src="<?php $image_id = get_post_thumbnail_id(); $image_url = wp_get_attachment_image_src($image_id,'64', true); echo $image_url[0]; ?>"  data-spai-upd="64"/>
                                    <?php } else { ?>
                                        <img alt="<?php echo get_the_title(); ?>" data-spai="1" class="lzl" src="<?php echo get_template_directory_uri(); ?>/assetss/img/lazy.png"  data-spai-upd="64"/>
                                    <?php } ?>
                                <?php } ?>
                            </div>
                            <div> <b><?php the_title(); ?></b>
                                <p>
                                    <span class="tag"><?php echo esc_html( get_post_meta( $post->ID, 'wp_rated_GP', true ) ); ?> ★</span> •
                                    <?php global $opt_themes; $ex_themes_fakees_ = mt_rand(500,9999); if($opt_themes['ex_themes_fake_view_active_']) { ?>
                                        <span class="tag"> <i class="icon-dl"></i> <!--<?php echo numToKs($ex_themes_fakees_); ?>--> <?php echo $ex_themes_fakees_; ?> </span>
                                    <?php } else { ?>
                                        <span class="tag"> <i class="icon-dl"></i> <?= ex_themes_get_post_view_(); ?> </span>
                                    <?php } ?>
                                </p> 
								<span><?php
                                    $i = 0;
                                    foreach((get_the_category()) as $cat) {
                                        echo '' . $cat->cat_name . '';
                                        if (++$i == 1) break;
                                    }
                                    ?></span>
                            </div> </a>
                    <?php endwhile; }
                echo '';
                wp_reset_query();
            }?>
        </div>
    <?php } else { ?>
    <?php } ?>
<?php }
add_shortcode('ex_themes_related_posts_', 'ex_themes_related_posts_');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_gallery_images_gpstore_() { ?>
    <?php global $wpdb, $post, $opt_themes; if($opt_themes['aktif_ex_themes_gallery_images_gpstore_']) { ?>
        <div class="gallery beauty-scroll mb-14" id="gallery-screenshots1">
            <?php if (get_post_meta( $post->ID, 'wp_images_GP', true )) { ?>
                <?php
                $datos_imagenes = get_post_meta(get_the_ID(), 'wp_images_GP', true);
                $i = 0;
                if(count($datos_imagenes)>1){
                    foreach($datos_imagenes as $elemento) { ?>
                        <a href="<?php echo (!empty($datos_imagenes[$i])) ? $datos_imagenes[$i] : ''; ?>=w1024-h768" title="<?php echo esc_html( get_post_meta( $post->ID, 'wp_title_GP', true ) ); ?> poster <?php echo $i; ?>" alt="<?php echo esc_html( get_post_meta( $post->ID, 'wp_title_GP', true ) ); ?> poster <?php echo $i; ?>">
                            <img src="<?php echo (!empty($datos_imagenes[$i])) ? $datos_imagenes[$i] : ''; ?>=h200-rw" title="<?php echo esc_html( get_post_meta( $post->ID, 'wp_title_GP', true ) ); ?> <?php echo esc_html( get_post_meta( $post->ID, 'wp_version_GP', true ) ); ?>  screenshots <?php echo $i; ?>" alt="<?php echo esc_html( get_post_meta( $post->ID, 'wp_title_GP', true ) ); ?> <?php echo esc_html( get_post_meta( $post->ID, 'wp_version_GP', true ) ); ?>  poster <?php echo $i; ?>" data-src="<?php echo (!empty($datos_imagenes[$i])) ? $datos_imagenes[$i] : ''; ?>=h200-rw" >
                        </a>
                        <?php $i++; } ?>
                <?php } else { for($i=0;$i<1;$i++): ?>
                <?php endfor; ?>
                <?php } ?>
            <?php } else { ?>
            <?php } ?>
        </div>
    <?php } else { ?>
    <?php } ?>
<?php }
add_shortcode('ex_themes_gallery_images_gpstore_', 'ex_themes_gallery_images_gpstore_');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_homes_search_() { ?>
   <div class="has-text-centered">
                        <form action="<?php echo esc_url(home_url('/')); ?>" method="GET">
                            <div style="display: -webkit-box;-webkit-box-orient: horizontal;">
                                <div style="-webkit-box-flex: 1;width: 100%;">
                                    <input name="s" value="" required="" aria-label="Name" class="ainput" type="search" style="border-color: darkgray;" placeholder="Enter your search here">
                                </div>
                                <button aria-label="Search" class="abutton is-light" style="border-color: darkgray;margin: 0 -1px; height: 2.25em;border-bottom-left-radius: 0;border-top-left-radius: 0"><span style="position: relative;top: -1px;">Search</span></button>
                            </div>
                        </form>
                    </div>
<?php }
add_shortcode('ex_themes_homes_search_', 'ex_themes_homes_search_');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_homes_titles_() {
    ?>
    <?php global $opt_themes;
    if($opt_themes['ex_themes_homes_titles_']) { ?>
       <h1 class="atitle has-text-centered"><?php echo $opt_themes['ex_themes_homes_titles_']; ?></h1>
    <?php } else { ?>
       <h1 class="atitle has-text-centered"><?php echo get_option("blogname") ?></h1>		
    <?php } ?>
<?php }
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
add_shortcode('ex_themes_homes_titles_', 'ex_themes_homes_titles_');
function ex_themes_notice_installers_() { ?>
    <?php global $opt_themes; if($opt_themes['ex_themes_notice_installers_active_']) { ?>
        <?php echo $opt_themes['ex_themes_notice_installers_codes_']; ?>
    <?php } else { ?>
    <?php } ?> 
<?php }
function ex_themes_blogs_shares_($content1) {
    global $wpdb, $post, $opt_themes;
    if(is_singular() || is_home()){
        #### Get current page URL
        $ex_themes_blogs_shares_urls_ = urlencode(get_permalink());
        $ex_themes_blogs_shares_view_1_ = ex_themes_set_post_view_();
        $ex_themes_blogs_shares_view_2_ = ex_themes_get_post_view_();
        $ex_themes_fakees_ = mt_rand(500,9999);
        #### Get current page title
        $ex_themes_page_titles_ = htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8');
        $ex_themes_page_descs_ = htmlspecialchars(urlencode(html_entity_decode( get_post_meta( $post->ID, 'wp_desck_GP', true ) ) ) );
        #### $ex_themes_page_titles_ = str_replace( ' ', '%20', get_the_title());
        #### Get Post Thumbnail for pinterest
        $ex_themes_page_thumbnail_ = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
        #### Construct sharing URL without using any script
        $twitterURL = 'https://twitter.com/intent/tweet?text='.$ex_themes_page_titles_.'&amp;url='.$ex_themes_blogs_shares_urls_.'&amp;via=iblog.my.id';
        $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$ex_themes_blogs_shares_urls_;
        $telegramURL = 'https://telegram.me/share/url?text='.$ex_themes_page_titles_.'&url='.$ex_themes_blogs_shares_urls_.'';
        $bufferURL = 'https://bufferapp.com/add?url='.$ex_themes_blogs_shares_urls_.'&amp;text='.$ex_themes_page_titles_;
        $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$ex_themes_blogs_shares_urls_.'&amp;title='.$ex_themes_page_titles_;
        $whatsappURL = 'https://api.whatsapp.com/send?text='.$ex_themes_page_titles_.'%20'.$ex_themes_blogs_shares_urls_.'';
        $tumblrURL = 'https://www.tumblr.com/widgets/share/tool?posttype=link&title='.$ex_themes_page_titles_.'&caption='.$ex_themes_page_titles_.'&content='.$ex_themes_blogs_shares_urls_.'&shareSource=tumblr_share_button';
        $vkURL = 'https://vk.com/share.php?url='.$ex_themes_blogs_shares_urls_.'&title='.$ex_themes_page_titles_.'&description='.$ex_themes_page_descs_.'&image='.$ex_themes_page_thumbnail_[0].'';
        #### Based on popular demand added Pinterest too
        $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$ex_themes_blogs_shares_urls_.'&amp;media='.$ex_themes_page_thumbnail_[0].'&amp;description='.$ex_themes_page_titles_;
        #### Add sharing button at the end of page/page content
        $content1 .= '';
        $content1 .= '<div class="social"> ';
        /*
        if($opt_themes['ex_themes_fake_view_active_']) {
        $content1 .= '<div class="nc_tweetContainer swp_share_button total_shares total_sharesalt"><span class="swp_count " style="transition: padding 0.1s linear 0s;">'.numToKs($ex_themes_fakees_).' <span class="swp_label">Reads</span></span></div>';
        } else {
        $content1 .= '<div class="nc_tweetContainer swp_share_button total_shares total_sharesalt"><span class="swp_count " style="transition: padding 0.1s linear 0s;">'.$ex_themes_blogs_shares_view_2_.' <span class="swp_label">Reads</span></span></div>';
        }
        */
        $content1 .= '<a class="resp-sharing-button__link" title="Facebook" href="'.$facebookURL.'" target="_blank" rel="nofollow noopener" aria-label="">
<div class="resp-sharing-button resp-sharing-button--facebook resp-sharing-button--small">
<div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
<path d="M18.77 7.46H14.5v-1.9c0-.9.6-1.1 1-1.1h3V.5h-4.33C10.24.5 9.5 3.44 9.5 5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4z" />
</svg>
</div>
</div> </a> ';
        $content1 .= '<a class="resp-sharing-button__link" title="Twitter" href="'. $twitterURL .'" target="_blank" rel="nofollow noopener" aria-label="">
<div class="resp-sharing-button resp-sharing-button--twitter resp-sharing-button--small">
<div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
<path d="M23.44 4.83c-.8.37-1.5.38-2.22.02.93-.56.98-.96 1.32-2.02-.88.52-1.86.9-2.9 1.1-.82-.88-2-1.43-3.3-1.43-2.5 0-4.55 2.04-4.55 4.54 0 .36.03.7.1 1.04-3.77-.2-7.12-2-9.36-4.75-.4.67-.6 1.45-.6 2.3 0 1.56.8 2.95 2 3.77-.74-.03-1.44-.23-2.05-.57v.06c0 2.2 1.56 4.03 3.64 4.44-.67.2-1.37.2-2.06.08.58 1.8 2.26 3.12 4.25 3.16C5.78 18.1 3.37 18.74 1 18.46c2 1.3 4.4 2.04 6.97 2.04 8.35 0 12.92-6.92 12.92-12.93 0-.2 0-.4-.02-.6.9-.63 1.96-1.22 2.56-2.14z" />
</svg>
</div>
</div> </a>  ';
        $content1 .= '<a class="resp-sharing-button__link" title="Tumblr" href="'. $tumblrURL .'" target="_blank" rel="nofollow noopener" aria-label="">
<div class="resp-sharing-button resp-sharing-button--tumblr resp-sharing-button--small">
<div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
<path d="M13.5.5v5h5v4h-5V15c0 5 3.5 4.4 6 2.8v4.4c-6.7 3.2-12 0-12-4.2V9.5h-3V6.7c1-.3 2.2-.7 3-1.3.5-.5 1-1.2 1.4-2 .3-.7.6-1.7.7-3h3.8z" />
</svg>
</div>
</div> </a>  ';
        $content1 .= '<a class="resp-sharing-button__link" title="Pinterest" onclick="var e=document.createElement(\'script\');						e.setAttribute(\'type\',\'text/javascript\');e.setAttribute(\'charset\',\'UTF-8\');						e.setAttribute(\'src\',\'\/\/assets.pinterest.com\/js\/pinmarklet.js?r=\'+Math.random()*99999999);						document.body.appendChild(e);" rel="nofollow noopener" aria-label="">
<div class="resp-sharing-button resp-sharing-button--pinterest resp-sharing-button--small">
<div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
<path d="M12.14.5C5.86.5 2.7 5 2.7 8.75c0 2.27.86 4.3 2.7 5.05.3.12.57 0 .66-.33l.27-1.06c.1-.32.06-.44-.2-.73-.52-.62-.86-1.44-.86-2.6 0-3.33 2.5-6.32 6.5-6.32 3.55 0 5.5 2.17 5.5 5.07 0 3.8-1.7 7.02-4.2 7.02-1.37 0-2.4-1.14-2.07-2.54.4-1.68 1.16-3.48 1.16-4.7 0-1.07-.58-1.98-1.78-1.98-1.4 0-2.55 1.47-2.55 3.42 0 1.25.43 2.1.43 2.1l-1.7 7.2c-.5 2.13-.08 4.75-.04 5 .02.17.22.2.3.1.14-.18 1.82-2.26 2.4-4.33.16-.58.93-3.63.93-3.63.45.88 1.8 1.65 3.22 1.65 4.25 0 7.13-3.87 7.13-9.05C20.5 4.15 17.18.5 12.14.5z" />
</svg>
</div>
</div> </a>  ';
        $content1 .= '<a class="resp-sharing-button__link" title="WhatsApp" href="'.$whatsappURL.'" target="_blank" rel="nofollow noopener" aria-label="">
<div class="resp-sharing-button resp-sharing-button--whatsapp resp-sharing-button--small">
<div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
<path d="M20.1 3.9C17.9 1.7 15 .5 12 .5 5.8.5.7 5.6.7 11.9c0 2 .5 3.9 1.5 5.6L.6 23.4l6-1.6c1.6.9 3.5 1.3 5.4 1.3 6.3 0 11.4-5.1 11.4-11.4-.1-2.8-1.2-5.7-3.3-7.8zM12 21.4c-1.7 0-3.3-.5-4.8-1.3l-.4-.2-3.5 1 1-3.4L4 17c-1-1.5-1.4-3.2-1.4-5.1 0-5.2 4.2-9.4 9.4-9.4 2.5 0 4.9 1 6.7 2.8 1.8 1.8 2.8 4.2 2.8 6.7-.1 5.2-4.3 9.4-9.5 9.4zm5.1-7.1c-.3-.1-1.7-.9-1.9-1-.3-.1-.5-.1-.7.1-.2.3-.8 1-.9 1.1-.2.2-.3.2-.6.1s-1.2-.5-2.3-1.4c-.9-.8-1.4-1.7-1.6-2-.2-.3 0-.5.1-.6s.3-.3.4-.5c.2-.1.3-.3.4-.5.1-.2 0-.4 0-.5C10 9 9.3 7.6 9 7c-.1-.4-.4-.3-.5-.3h-.6s-.4.1-.7.3c-.3.3-1 1-1 2.4s1 2.8 1.1 3c.1.2 2 3.1 4.9 4.3.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.6-.1 1.7-.7 1.9-1.3.2-.7.2-1.2.2-1.3-.1-.3-.3-.4-.6-.5z" />
</svg>
</div>
</div> </a>  ';
        $content1 .= '<a class="resp-sharing-button__link" title="VK" href="'.$vkURL.'" target="_blank" rel="nofollow noopener" aria-label="">
<div class="resp-sharing-button resp-sharing-button--vk resp-sharing-button--small">
<div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
<path d="M21.547 7h-3.29a.743.743 0 0 0-.655.392s-1.312 2.416-1.734 3.23C14.734 12.813 14 12.126 14 11.11V7.603A1.104 1.104 0 0 0 12.896 6.5h-2.474a1.982 1.982 0 0 0-1.75.813s1.255-.204 1.255 1.49c0 .42.022 1.626.04 2.64a.73.73 0 0 1-1.272.503 21.54 21.54 0 0 1-2.498-4.543.693.693 0 0 0-.63-.403h-2.99a.508.508 0 0 0-.48.685C3.005 10.175 6.918 18 11.38 18h1.878a.742.742 0 0 0 .742-.742v-1.135a.73.73 0 0 1 1.23-.53l2.247 2.112a1.09 1.09 0 0 0 .746.295h2.953c1.424 0 1.424-.988.647-1.753-.546-.538-2.518-2.617-2.518-2.617a1.02 1.02 0 0 1-.078-1.323c.637-.84 1.68-2.212 2.122-2.8.603-.804 1.697-2.507.197-2.507z" />
</svg>
</div>
</div> </a>  ';
        $content1 .= '<a class="resp-sharing-button__link" title="Telegram" href="'.$telegramURL.'" target="_blank" rel="nofollow noopener" aria-label="">
<div class="resp-sharing-button resp-sharing-button--telegram resp-sharing-button--small">
<div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
<path d="M.707 8.475C.275 8.64 0 9.508 0 9.508s.284.867.718 1.03l5.09 1.897 1.986 6.38a1.102 1.102 0 0 0 1.75.527l2.96-2.41a.405.405 0 0 1 .494-.013l5.34 3.87a1.1 1.1 0 0 0 1.046.135 1.1 1.1 0 0 0 .682-.803l3.91-18.795A1.102 1.102 0 0 0 22.5.075L.706 8.475z" />
</svg>
</div>
</div> </a> ';
        $content1 .= '</div>';
        return $content1;
    } else {
        #### if not a post/page then don't include sharing button
        return $content1;
    }
};
add_filter( 'the_content1', 'ex_themes_blogs_shares_');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\