<?php
###############################
###    Stop Don't Try Edit  ###
###  if you don't know php  ###
###############################
###      EX-THEMES.COM      ###
### Premium Wordress Themes ###
###############################
################## add scripts ##################
function jquery_() {
    wp_enqueue_script('jquery', 'https://code.jquery.com/jquery-3.2.1.min.js', array('jquery'), null, false);
}
add_action('wp_enqueue_scripts', 'jquery_', 5 );
function cloudflare() {
    wp_enqueue_script('cloudflare', 'http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js', array('jquery'), null, false);
}
add_action('wp_enqueue_scripts', 'cloudflare', 5 );