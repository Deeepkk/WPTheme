<?php
###############################
###    Stop Don't Try Edit  ###
###  if you don't know php  ###
###############################
###      EX-THEMES.COM      ###
### Premium Wordress Themes ###
###############################
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
if ( ! function_exists( 'apkdone_setup' ) ) :
    function apkdone_setup() {		
       
        add_theme_support( 'automatic-feed-links' );

        add_theme_support( 'title-tag' );

      
        add_theme_support( 'post-thumbnails' );

        // This theme uses wp_nav_menu() in one location.
        /*
		register_nav_menus( array(
            'main-menu' => __( 'Header' ),
            'footer-menu' => __( 'Footer' ) )
        );
		*/
		 
		function register_my_menu() {
			register_nav_menu('menu_header',__( 'Main Menu', 'ex_themes_' ));
			register_nav_menu('menu_footer',__( 'Footer', 'ex_themes_' ));
			}
		add_action( 'init', 'register_my_menu' );
		
		add_action('after_switch_theme', 'theme_activation_function', 10 ,  2);
		function theme_activation_function ($oldname, $oldtheme = false) {
			$menus = array(
			'Main Menu'  => array(
			'home'  => 'Home', 
			'top-apps'  => 'Apps Mods', 
			'top-games'  => 'Games Mods', 
			'top-paids'  => 'Paids'), 
			
			'Footer' => array(
			'aboutus' => 'About',
			'contact-us'  => 'Contact', 
			'privacy-policy'  => 'Privacy', 
			'dmca'  => 'DMCA', 
			'advertising'  => 'Advertising', 
			'sitemap'  => 'Sitemap'
			)
			);
		foreach($menus as $menuname => $menuitems) {
			$menu_exists = wp_get_nav_menu_object($menuname);
			// If it doesn't exist, let's create it.
			if ( !$menu_exists) {
				$menu_id = wp_create_nav_menu($menuname);
			foreach($menuitems as $slug => $item) {
				wp_update_nav_menu_item(
				$menu_id, 0, array(
				'menu-item-title'  => $item,
				'menu-item-url'     => '', 
				'menu-item-status'  => 'publish'
				)
			);
			}}}			
			}
		 
		/*
		//Get all locations (including the one we just created above)
			$locations = get_theme_mod('nav_menu_locations');
			//set the menu to the new location and save into database
			$locations[$menus] = $menu_id;
			set_theme_mod( 'nav_menu_locations', $locations );		
		*/
 
        add_theme_support( 'html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
        ) );

        // Add theme support for selective refresh for widgets.
        add_theme_support( 'customize-selective-refresh-widgets' );

        // Image Sizes
        add_image_size( '64', 64, 64, true );
        add_image_size( '120', 120, 120, true );
    }
endif;
add_action( 'after_setup_theme', 'apkdone_setup' );
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
if ( function_exists('register_sidebar') )
    register_sidebar(array(
        'id' => 'sidebar-1',
        'name'=> ''.EX_THEMES_NAMES.' Sidebar',
        'description'   => __( 'Widgets in this area will be shown on sidebar', 'ex_themes' ),
        'before_widget' => '<div class="block-title">',
        'after_widget' => '</div>',
        'before_title' => '<div class="atitle"><p>',
        'after_title' => '</p></div>',
    ));
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function remove_footer_admin ()
{echo '<span id="footer-thankyou" style="font-style:normal;font-size:90%;letter-spacing:1px;">©2021 - <script type=\'text/javascript\'>var creditsyear = new Date();document.write(creditsyear.getFullYear());</script>  <b>'.EX_THEMES_NAMES.' Themes</b> - Developed by <a href="https://ex-themes.com" title="Premium Wordpress Themes" target="_blank">ex-themes.com</a></span>';}
add_filter('admin_footer_text', 'remove_footer_admin');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function catch_that_image() {
    global $post, $posts;
    $first_img = '';
    ob_start();
    ob_end_clean();
    $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
    $first_img = $matches [1] [0];
    if(empty($first_img)){ //Defines a default image
        $first_img = "/images/default.jpg";
    }
    return $first_img;
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function timeago($ptime) {
    $ptime = strtotime($ptime);
    $etime = time() - $ptime;
    if($etime < 1) return ' just now';
    $interval = array (
        12 * 30 * 24 * 60 * 60 => ' years ago ('.date('F j, Y', $ptime).')',
        30 * 24 * 60 * 60 => ' months ago ('.date('F j, Y', $ptime).')',
        7 * 24 * 60 * 60 => ' weeks ago ('.date('F j, Y', $ptime).')',
        24 * 60 * 60 => ' days ago',
        60 * 60 => ' hours ago',
        60 => ' minutes ago',
        1 => ' seconds ago' );
    foreach ($interval as $secs => $str) {
        $d = $etime / $secs;
        if ($d >= 1) {
            $r = round($d);
            return $r . $str;
        }
    }; }
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_get_post_view_() {
    $count = get_post_meta( get_the_ID(), 'post_views_count', true );
    if($count=='') {
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0";
    }
    if ($count > 1000) {
        return round ( $count / 1000 , 1 ).'K';
    } else {
        return $count.'';
    }
    //return "$count";
}
function ex_themes_set_post_view_() {
    $key = 'post_views_count';
    $post_id = get_the_ID();
    $count = (int) get_post_meta( $post_id, $key, true );
    $count++;
    update_post_meta( $post_id, $key, $count );
}
function ex_themes_posts_column_views_( $columns ) {
    $columns['post_views'] = 'Views';
    return $columns;
}
function ex_themes_posts_custom_column_views_( $column ) {
    if ( $column === 'post_views') {
        echo ex_themes_get_post_view_();
    }
}
add_filter( 'manage_posts_columns', 'ex_themes_posts_column_views_' );
add_action( 'manage_posts_custom_column', 'ex_themes_posts_custom_column_views_' );
function ex_themes_getPostViews_($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count=='') {
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0 View";
    }
    if ($count > 1000) {
        return round ( $count / 1000 , 1 ).'K Views';
    } else {
        return $count.' Views';
    }
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_wpb_set_post_views_($postID) {
    $count_key = 'ex_themes_wpb_post_views_count_';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }
    if ($count > 1000) {
        return round ( $count / 1000 , 1 ).'K';
    } else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);
function ex_themes_wpb_track_post_views_ ($post_id) {
    if ( !is_single() ) return;
    if ( empty ( $post_id) ) {
        global $post;
        $post_id = $post->ID;
    }
    ex_themes_wpb_set_post_views_($post_id);
}
add_action( 'wp_head', 'ex_themes_wpb_track_post_views_');
function ex_themes_wpb_get_post_views_($postID){
    $count_key = 'ex_themes_wpb_post_views_count_';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0 View";
    }
    if ($count > 1000) {
        return round ( $count / 1000 , 1 ).'K Views';
    } else {
        return $count.' Views';
    }
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_duplicate_scripts( $hook ) {
    if( !in_array( $hook, array( 'post.php', 'post-new.php' , 'edit.php'))) return;
    wp_enqueue_script('duptitles',
        wp_enqueue_script('duptitles',EX_THEMES_URI.'/assetss/js/psy_duplicate.js',
            array( 'jquery' )), array( 'jquery' )  );
}
add_action( 'admin_enqueue_scripts', 'ex_themes_duplicate_scripts', 2000 );
require_once get_template_directory().'/libs/inc/options/functions.php';
add_action('wp_ajax_ex_themes_duplicate', 'ex_themes_duplicate_callback');
function ex_themes_duplicate_callback() {
    function ex_themes_results_checks() {
        global $wpdb;
        $title = $_POST['post_title'];
        $post_id = $_POST['post_id'];
        $titles = "SELECT post_title FROM $wpdb->posts WHERE post_status = 'publish' AND post_title = '{$title}' AND ID != {$post_id} ";
        $results = $wpdb->get_results($titles);
        if($results) {
            return '<div class="error"><p><span class="dashicons dashicons-warning"></span> '. __( 'This content already exists, we recommend not to publish.' , 'apkiblog' ) .' </p></div>';
        } else {
            return '<div class="notice rebskt updated"><p><span class="dashicons dashicons-thumbs-up"></span> '.__('Excellent! this content is unique.' , 'apkiblog').'</p></div>';
        }
    }
    echo ex_themes_results_checks();
    die();
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function doo_mobile() {
    $mobile = ( wp_is_mobile() == true ) ? '1' : 'false';
    return $mobile;
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
add_rewrite_endpoint( 'download', EP_PERMALINK | EP_PAGES );
function ex_themes_download() {
    add_rewrite_endpoint( 'download', EP_PERMALINK | EP_PAGES );
}
add_action( 'init', 'ex_themes_download' );
function ex_themes_download_template() {
    global $wp_query;
    // if this is not a request for play or a singular object then bail
    if ( ! isset( $wp_query->query_vars['download'] ) || ! is_singular() )
        return;
    // include custom template
    include get_template_directory().'/template/download.php';
    exit;
}
add_action( 'template_redirect', 'ex_themes_download_template' );
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
add_rewrite_endpoint( 'get', EP_PERMALINK | EP_PAGES );
function ex_themes_get() {
    add_rewrite_endpoint( 'get', EP_PERMALINK | EP_PAGES );
}
add_action( 'init', 'ex_themes_get' );
function ex_themes_get_template() {
    global $wp_query;
    // if this is not a request for play or a singular object then bail
    if ( ! isset( $wp_query->query_vars['get'] ) || ! is_singular() )
        return;
    // include custom template
    include get_template_directory().'/template/get.php';
    exit;
}
add_action( 'template_redirect', 'ex_themes_get_template' );
// ~~~~~~~~~~~~~~~~~~~~~ BANGREY ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_not_activate_notice() { ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>body{background:#000!important;overflow:hidden}#warning span{font-size:50px}#warning{z-index:999999999;position:fixed;top:0;right:0;left:0;padding:20% 0;height:100%;text-align:center;background:rgba(39,2,23, 0.97);color:#fff}h4.ex_themes, a.ex_themes {font-weight: 800;font-size: 40px;color: #ffd800 !important;line-height: 1.3em;text-align: center;text-shadow: 0.02em 0.05em 0em rgba(0,0,0,0.4);}</style><div id="warning"><h4 class="ex_themes"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Need Activate Themes <i class="fa fa-exclamation-triangle" aria-hidden="true"></i></h4><p>Please Contact <b><a class="ex_themes" href="https://ex-themes.com" target="_blank">eX-Themes.com</a></b> to get license key</p><span id="aktivasi"> </span></div>
<?php }
// ~~~~~~~~~~~~~~~~~~~~~ BANGREY ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_notices() {
    if(empty($lis) && ($_GET['page'] != EX_THEMES_SLUGS_) ) {
        printf('<style>.notice-error, div.error {border-left-color:deepskyblue!important;}.landingpress-message {padding: 20px !important;font-size:16px!important;}.landingpress-message-inner {overflow:hidden;}.landingpress-message-icon {float:left;width:35px;height:35px;padding-right:20px;}.landingpress-message-button {float:right;padding:3px 0 0 20px;}</style><div class="error landingpress-message"><div class="landingpress-message-inner"><div class="landingpress-message-icon" style="font-size:16px!important;text-transform:capitalize"><img src="'.get_template_directory_uri().'/assetss/img/favicon.png" width="35" height="35" alt=""/></div><div class="landingpress-message-button"><a href="' . admin_url( 'admin.php?page='.EX_THEMES_SLUGS_.'') . '" class="button button-primary">Enter License Code </a></div><strong style="text-transform:capitalize;  ">Welcome to '.EX_THEMES_NAMES.' WordPress Themes.</strong> <strong style="text-transform:capitalize;font-weight:800;font-size:20px;color:orangered!important; text-shadow:.02em .05em 0 rgba(0,0,0,0.4);">Please Activate '.EX_THEMES_NAMES.' license</strong> <br><i style="text-transform:capitalize; ">to get automatic updates, technical support, and access to '.EX_THEMES_NAMES.' Options Panel</i> .</div></div>');
    }
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_add_img_alt_tag_title($attr, $attachment = null) {
    $img_title = trim(strip_tags($attachment->post_title));
    if (empty($attr['alt'])) {
        $attr['alt'] = $img_title;
        $attr['title'] = $img_title;
    }
    return $attr;
}
add_filter('wp_get_attachment_image_attributes', 'ex_themes_add_img_alt_tag_title', 10, 2);
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_page_navy_($pages = '', $range = 1)
{
    $showitems = ($range * 2)+1;
    global $paged;
    if(empty($paged)) $paged = 1;
    if($pages == '')
    {
        global $wp_query;
        $pages = $wp_query->max_num_pages;
        if(!$pages)
        {
            $pages = 1;
        }
    }
    if(1 != $pages)
    {
        if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<li><a href='".get_pagenum_link(1)."'>&laquo;</a></li>";
        if($paged > 1 && $showitems < $pages) echo "<li><a  href='".get_pagenum_link($paged - 1)."'>&lsaquo; </a></li>";
        for ($i=1; $i <= $pages; $i++)
        {
            if (1 != $pages &&( !($i >= $paged+$range+4 || $i <= $paged-$range-1) || $pages <= $showitems ))
            {
                echo ($paged == $i)? "<li class=\"active Selected\"><a class='page-numbers' href='".get_pagenum_link($i)."'>".$i."</a></li>":"<li><a class='page-numbers' href='".get_pagenum_link($i)."'>".$i."</a></li>";
            }
        }
        if ($paged < $pages && $showitems < $pages) echo "<li><a href=\"".get_pagenum_link($paged + 1)."\" > &rsaquo;</a></li>";
        if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<li><a href='".get_pagenum_link($pages)."'  >&raquo;</a></li>";
    }
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
add_filter('the_generator', '__return_empty_string');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function numToKs($number) {
    if ($number >= 1000) {
        return number_format(($number / 1000), 1) . '&nbsp;k';
    } else {
        return $number;
    }
}
add_filter( 'use_block_editor_for_post', '__return_false' );
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
//remove_filter( 'sanitize_title', 'sanitize_title_with_dashes', 10 );
//add_filter( 'sanitize_title', 'wpse231448_sanitize_title_with_dashes', 10, 3 );
function wpse231448_sanitize_title_with_dashes( $title, $raw_title = '', $context = 'display' ) {
    $title = strip_tags($title);
    // Preserve escaped octets.
    $title = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '---$1---', $title);
    // Remove percent signs that are not part of an octet.
    $title = str_replace('%', '', $title);
    // Restore octets.
    $title = preg_replace('|---([a-fA-F0-9][a-fA-F0-9])---|', '%$1', $title);

    if (seems_utf8($title)) {
        if (function_exists('mb_strtolower')) {
            $title = mb_strtolower($title, 'UTF-8');
        }
        $title = utf8_uri_encode($title, 200);
    }

    $title = strtolower($title);

    if ( 'save' == $context ) {
        // Convert nbsp, ndash and mdash to hyphens
        $title = str_replace( array( '%c2%a0', '%e2%80%93', '%e2%80%94' ), '-', $title );
        // Convert nbsp, ndash and mdash HTML entities to hyphens
        $title = str_replace( array( '&nbsp;', '&#160;', '&ndash;', '&#8211;', '&mdash;', '&#8212;' ), '-', $title );

        // Strip these characters entirely
        $title = str_replace( array(
            // iexcl and iquest
            '%c2%a1', '%c2%bf',
            // angle quotes
            '%c2%ab', '%c2%bb', '%e2%80%b9', '%e2%80%ba',
            // curly quotes
            '%e2%80%98', '%e2%80%99', '%e2%80%9c', '%e2%80%9d',
            '%e2%80%9a', '%e2%80%9b', '%e2%80%9e', '%e2%80%9f',
            // copy, reg, deg, hellip and trade
            '%c2%a9', '%c2%ae', '%c2%b0', '%e2%80%a6', '%e2%84%a2',
            // acute accents
            '%c2%b4', '%cb%8a', '%cc%81', '%cd%81',
            // grave accent, macron, caron
            '%cc%80', '%cc%84', '%cc%8c',
        ), '', $title );

        // Convert times to x
        $title = str_replace( '%c3%97', 'x', $title );
    }

    $title = preg_replace('/&.+?;/', '', $title); // kill entities

    // WPSE-231448: Commented out this line below to stop dots being replaced by dashes.
    //$title = str_replace('.', '-', $title);

    // WPSE-231448: Add the dot to the list of characters NOT to be stripped.
    $title = preg_replace('/[^%a-z0-9 _\-\.]/', '', $title);
    $title = preg_replace('/\s+/', '-', $title);
    $title = preg_replace('|-+|', '-', $title);
    $title = trim($title, '-');

    return $title;
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_clean($string) {
   $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
   $string = preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
   return preg_replace('/-+/', '-', $string); // Replaces multiple hyphens with single one.
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_post_gallery_contents_($content2) {
    global $wpdb, $post, $opt_themes;
    if(is_singular() || is_home()){
        $ex_themes_page_titles_ = esc_html( get_post_meta( $post->ID, 'wp_title_GP', true ) );
		$ex_themes_datos_imagenes = get_post_meta(get_the_ID(), 'wp_images_GP', true);
        $ex_themes_if_ = get_post_meta( $post->ID, 'wp_images_GP', true );
        $content2 .= "<div id=\"gallery-3\" class=\"gallery galleryid-28459 gallery-columns-3 gallery-size-medium\">";
		if (get_post_meta( $post->ID, 'wp_images_GP', true )) {
        $datos_imagenes = $ex_themes_datos_imagenes;
        $i = 0;
		if(count($datos_imagenes)>3){
         foreach($datos_imagenes as $elemento) { 
        $content2 .= "<dl class=\"gallery-item\">";
        $content2 .= "<dt class=\"gallery-icon portrait\">";
		$content2 .= "<img src=\"";
		$content2 .= $datos_imagenes[$i];
		$content2 .= "\" data-spai=\"1\" class=\"attachment-medium size-medium\" title=\"";
		$content2 .= $ex_themes_page_titles_;
		$content2 .= "screen ";
		$content2 .= $i;
		$content2 .= "\" data-spai-upd=\"212\" width=\"226\" height=\"402\">";
        $content2 .= "</dt>";
        $content2 .= "</dl>";
        if (++$i == 3) break; } } } 
        $content2 .= "<br style=\"clear: both\">";
        $content2 .= "</div>";		 
        return $content2;
		} else {
        #### if not a post/page then don't include sharing button
        return $content2;
    }
};
add_filter( 'the_content2', 'ex_themes_post_gallery_contents_');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\ 
add_filter( 'the_content', 'ex_themes_post_gallery_contents_insert_' ); 
function ex_themes_post_gallery_contents_insert_( $content ) {  
	global $opt_themes;
    $activate = $opt_themes['ex_themes_gallery_content_activate_'];
    $numbers = $opt_themes['ex_themes_gallery_content_paragraph_on_'];
	$random = mt_rand(1,7);
	if (($activate == '1'))
        $ex_themes_post_gallery_contents_code_ = ex_themes_post_gallery_contents_($content2);
    if($numbers=='0') {
        return ex_themes_post_gallery_contents_after_paragraph_( $ex_themes_post_gallery_contents_code_, $random, $content );
    } else {
        return ex_themes_post_gallery_contents_after_paragraph_( $ex_themes_post_gallery_contents_code_, $numbers, $content );
    }
    if ( is_single() && ! is_admin() ) {
        return ex_themes_post_gallery_contents_after_paragraph_( $ex_themes_post_gallery_contents_code_, $numbers, $content );
    }
    return $content;      
	
}  
// Parent Function that makes the magic happen
function ex_themes_post_gallery_contents_after_paragraph_( $insertion, $paragraph_id, $content ) {
    $closing_p = '</p>';
    $paragraphs = explode( $closing_p, $content );
    foreach ($paragraphs as $index => $paragraph) { 
        if ( trim( $paragraph ) ) {
            $paragraphs[$index] .= $closing_p;
        } 
        if ( $paragraph_id == $index + 1 ) {
            $paragraphs[$index] .= $insertion;
        }
    }     
    return implode( '', $paragraphs );
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\ 
function ex_themes_post_youtube_contents_($content2) {
    global $wpdb, $post, $opt_themes;
    if(is_singular() || is_home()){
        $ex_themes_page_titles_ = esc_html( get_post_meta( $post->ID, 'wp_title_GP', true ) );
		$ex_themes_datos_youtube = get_post_meta(get_the_ID(), 'wp_youtube_GP', true);
        $ex_themes_if_ = get_post_meta( $post->ID, 'wp_youtube_GP', true );
		if (get_post_meta( $post->ID, 'wp_youtube_GP', true )) {
        $content2 .= "<center>";		 
        $datos_youtube = $ex_themes_datos_youtube;
		$content2 .= "<iframe src=\"https://www.youtube.com/embed/";
		$content2 .= $datos_youtube;
		$content2 .= "\" data-spai=\"1\" class=\"attachment-medium size-medium\" title=\"";
		$content2 .= $ex_themes_page_titles_;
		$content2 .= "screen ";
		$content2 .= $i;
		$content2 .= "\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\" width=\"100%\" height=\"400px\"></iframe>";
        $content2 .= "<br style=\"clear: both\">";
        $content2 .= "</center>";	
		}		
        return $content2;
		 
        #### if not a post/page then don't include sharing button
        return $content2;
    }
};
add_filter( 'the_content2', 'ex_themes_post_youtube_contents_');
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\ 
add_filter( 'the_content', 'ex_themes_post_youtube_contents_insert_' ); 
function ex_themes_post_youtube_contents_insert_( $content ) {  
	global $opt_themes;
    $activate = $opt_themes['ex_themes_youtube_content_activate_'];
    $numbers = $opt_themes['ex_themes_youtube_content_paragraph_on_'];
	$random = mt_rand(1,8);
	if (($activate == '1'))
        $ex_themes_post_youtube_contents_code_ = ex_themes_post_youtube_contents_($content2);
    if($numbers=='0') {
        return ex_themes_post_youtube_contents_after_paragraph_( $ex_themes_post_youtube_contents_code_, $random, $content );
    } else {
        return ex_themes_post_youtube_contents_after_paragraph_( $ex_themes_post_youtube_contents_code_, $numbers, $content );
    }
    if ( is_single() && ! is_admin() ) {
        return ex_themes_post_youtube_contents_after_paragraph_( $ex_themes_post_youtube_contents_code_, $numbers, $content );
    }
    return $content;
}  
function ex_themes_post_youtube_contents_after_paragraph_( $insertion, $paragraph_id, $content ) {
    $closing_p = '</p>';
    $paragraphs = explode( $closing_p, $content );
    foreach ($paragraphs as $index => $paragraph) { 
        if ( trim( $paragraph ) ) {
            $paragraphs[$index] .= $closing_p;
        } 
        if ( $paragraph_id == $index + 1 ) {
            $paragraphs[$index] .= $insertion;
        }
    }     
    return implode( '', $paragraphs );
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\ 