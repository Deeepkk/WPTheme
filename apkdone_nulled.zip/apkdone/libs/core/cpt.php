<?php
function ex_themes_taxonomies_() {
	// Add genres
	 
	$labels = array(
		'name'              => _x( 'Developer', 'taxonomy general name' ),
		'singular_name'     => _x( 'Developer', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Developer' ),
		'all_items'         => __( 'All Developer' ),
		'parent_item'       => __( 'Parent Developer' ),
		'parent_item_colon' => __( 'Parent Developer:' ),
		'edit_item'         => __( 'Edit Developer' ),
		'update_item'       => __( 'Update Developer' ),
		'add_new_item'      => __( 'Add New Developer' ),
		'new_item_name'     => __( 'New Developer Name' ),
		'menu_name'         => __( 'Developer' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'developer' ),
	);

	register_taxonomy( 'developer', array( 'post' ), $args );
	 
}
add_action( 'init', 'ex_themes_taxonomies_', 0 );