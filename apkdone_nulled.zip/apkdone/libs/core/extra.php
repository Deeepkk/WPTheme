<?php
###############################
###    Stop Don't Try Edit  ###
###  if you don't know php  ###
###############################
###      EX-THEMES.COM      ###
### Premium Wordress Themes ###
###############################
function ex_themes_disable_emojis_() {
	global $opt_themes;
    $activate = $opt_themes['ex_themes_disable_emojis_activate_'];
    if (($activate == '1'))   
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_action( 'admin_print_styles', 'print_emoji_styles' );
    remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
    remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
    remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
    add_filter( 'tiny_mce_plugins', 'ex_themes_disable_emojis__tinymce' );
    add_filter( 'wp_resource_hints', 'ex_themes_disable_emojis__remove_dns_prefetch', 10, 2 );
}
add_action( 'init', 'ex_themes_disable_emojis_' );
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_disable_emojis__tinymce( $plugins ) {
	global $opt_themes;
    $activate = $opt_themes['ex_themes_disable_emojis_activate_'];
    if (($activate == '1'))    
    if ( is_array( $plugins ) ) {
        return array_diff( $plugins, array( 'wpemoji' ) );
    } else {
        return array();
    }
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_disable_emojis__remove_dns_prefetch( $urls, $relation_type ) {
	global $opt_themes;
    $activate = $opt_themes['ex_themes_disable_emojis_activate_'];
    if (($activate == '1'))    
    if ( 'dns-prefetch' === $relation_type ) {
        /** This filter is documented in wp-includes/formatting.php */
        $emoji_svg_url = apply_filters( 'emoji_svg_url', 'https://s.w.org/images/core/emoji/2/svg/' );

        $urls = array_diff( $urls, array( $emoji_svg_url ) );
    }

    return $urls;
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_remove_version_scripts_styles($src) {
    global $opt_themes;
    $activate = $opt_themes['ex_themes_remove_version_scripts_styles_activate_'];
    if (($activate == '1'))
        if (strpos($src, 'ver=')) {
            $src = remove_query_arg('ver', $src);
        }
    return $src;
}
add_filter('style_loader_src', 'ex_themes_remove_version_scripts_styles', 9999);
add_filter('script_loader_src', 'ex_themes_remove_version_scripts_styles', 9999);
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
/*
function ex_themes_js_async_defer_attr_($tag){
	global $opt_themes;
	$activate = $opt_themes['ex_themes_async_scripts_activate_'];		
	if (($activate == '1'))
	else if ( is_admin() )	
	return str_replace( ' src', ' async="async" defer="defer" src', $tag );
	else
	return str_replace( ' src', 'src', $tag );

}
add_filter( 'script_loader_tag', 'ex_themes_js_async_defer_attr_', 10 );
*/
function ex_themes_async_scripts( $url ) {
	/*global $opt_themes;
	$activate = $opt_themes['ex_themes_async_scripts_activate_'];		
	if (($activate == '1'))*/
    if ( strpos( $url, ' async="async" defer="defer" src') === false )
        return $url;
    else if ( is_admin() )
        return str_replace( ' src', ' async="async" defer="defer" src', $url );
    else
        return str_replace(  ' src', ' async="async" defer="defer" src', $url ) . "' async defer data-async='1";
}
add_filter( 'clean_url', 'ex_themes_async_scripts', 11, 1 );


// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_disable_embeds_init_() {
	global $opt_themes;
    $activate = $opt_themes['ex_themes_disable_emojis_activate_'];
    if (($activate == '1'))     
    remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
    /* removes EditURI/RSD (Really Simple Discovery) link. */
    remove_action( 'wp_head', 'rsd_link' );
    /* removes wlwmanifest (Windows Live Writer) link. */
    remove_action( 'wp_head', 'wlwmanifest_link' );
    /* removes meta name generator. */
    remove_action( 'wp_head', 'wp_generator' );
    /* removes shortlink. */
    remove_action( 'wp_head', 'wp_shortlink_wp_head' );
    /* removes feed links. */
    remove_action( 'wp_head', 'feed_links', 2 );
    /* removes comments feed. */
    remove_action( 'wp_head', 'feed_links_extra', 3 );
    remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head' );
}
add_action( 'init', 'ex_themes_disable_embeds_init_', 9999 );
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
class ex_themes_cdn {
    /**
     * The max number of image servers WP.com have (at time of writing it is 4)
     * So the servers as i0.wp.com, i1.wp.com, i2.wp.com, i3.wp.com
     * Edited to only load one, no reason to add extra dns lookups (Domain sharding is not recommended in an http2 world)
     * Defult: 3
     */
    const MAXSRV = 1;
    function __construct() {
        //add_action( 'wp_head', array( $this, 'dns_prefetch' ) );
        //add_action( 'template_redirect', array( $this, 'ex_themes_buffering_photon_cdn_starts_' ), PHP_INT_MAX );
    }
    // Adds the DNS prefetch meta fields for the WP.com servers
    function dns_prefetch() {
        for ( $srv = 0; $srv < self::MAXSRV; $srv++ ) :
            $domain = "i{$srv}.wp.com";
            ?>
            <link rel='dns-prefetch' href='//<?php echo esc_attr( $domain ) ?>' />
        <?php
        endfor;
    }
    // Start the output buffering
    function ex_themes_buffering_photon_cdn_starts_() {
        global $opt_themes;
        $activate = $opt_themes['ex_themes_photon_cdn_activate_'];
        if (($activate == '1'))
            ob_start( array( $this, 'process_output' ) );
    }
    // Processes the output buffer, replacing all matching images with URLs
    // Pointing to wp.com
    function process_output( $buffer ) {
        // Get the content directory URL minus the http://
        $photon_site_url = site_url();
        $content_url = content_url();
        $content_url = str_replace( 'http://', '', $content_url );
        $content_url = str_replace( 'https://', '', $content_url );
        $content_url = str_replace( $photon_site_url, '', $content_url );
        $content_url = str_replace( '', '', $content_url );
        // Replace references to images on our servers with the wp.com CDN
        // Photon only supports the following image types.
        return preg_replace_callback(
            '{'. $content_url .'/.+\.(jpg|jpeg|png|gif|webp)}i',
            array( $this, 'replace' ),
            $buffer
        );
    }
    // Replaces a single image URL match
    function replace( $matches ) {
        // Grab the parsed image URL
        $url = isset( $matches[0] ) ? $matches[0] : '';
        // Pick a random server
        srand( crc32( $url ) ); // Best if we always use same server for this image
        $server = rand( 0, self::MAXSRV-1 );
        // Build the wp.com URL, as return as the replacement
        return "i{$server}.wp.com/{$url}";
    }
}
new ex_themes_cdn();
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_remove_hentry( $classes ) {
        if ( is_page() ) {
            $classes = array_diff( $classes, array( 'hentry' ) );
        }

        return $classes;
    }
add_filter( 'post_class', 'ex_themes_remove_hentry' );
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_pingback_header() {
        if ( is_singular() && pings_open() ) {
            echo '<link rel="pingback" href="', bloginfo( 'pingback_url' ), '">';
        }
    }
add_action( 'wp_head', 'ex_themes_pingback_header' );
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_add_img_title( $attr, $attachment = null ) {
	global $opt_themes;
    $activate = $opt_themes['ex_themes_add_img_title_activate_'];
    if (($activate == '1'))  
        $attr['title'] = trim( wp_strip_all_tags( $attachment->post_title ) );
        return $attr;
    }

add_filter( 'wp_get_attachment_image_attributes', 'ex_themes_add_img_title', 10, 2 );
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
function ex_themes_add_title_alt_gravatar( $text ) {
        $text = str_replace( 'alt=\'\'', 'alt=\'' . __( 'Gravatar Image', 'exthemes' ) . '\' title=\'' . __( 'Gravatar', 'exthemes' ) . '\'', $text );
        return $text;
}
// ~~~~~~~~~~~~~~~~~~~~~ EX_THEMES ~~~~~~~~~~~~~~~~~~~~~~~~ \\
remove_action( 'wp_head', 'wp_print_scripts' ); 
remove_action( 'wp_head', 'wp_print_head_scripts', 9 ); 
remove_action( 'wp_head', 'wp_enqueue_scripts', 1 );
add_action( 'wp_footer', 'wp_print_scripts', 5 );
add_action( 'wp_footer', 'wp_enqueue_scripts', 5 );
add_action( 'wp_footer', 'wp_print_head_scripts', 5 ); 
class WP_HTML_Compression
{
    // Settings
	
    protected $compress_css = true;
    protected $compress_js = false;
    protected $info_comment = true;
    protected $remove_comments = true;

    // Variables
    protected $html;
    public function __construct($html)
    {
   	 if (!empty($html))
   	 {
   		 $this->parseHTML($html);
   	 }
    }
    public function __toString()
    {
   	 return $this->html;
    }
    protected function bottomComment($raw, $compressed)
    {
   	 $raw = strlen($raw);
	 $urls = get_option("siteurl");
   	 $compressed = strlen($compressed);
   	 
   	 $savings = ($raw-$compressed) / $raw * 100;
   	 
   	 $savings = round($savings, 2);
   	 
   	 return '<!-- '.EX_THEMES_NAMES.' Themes developer by ex-themes.com for auto minify to '.$urls.' '.date("Y").' - HTML compressed, size saved '.$savings.'%. From '.$raw.' bytes, now '.$compressed.' bytes-->';
    }
    protected function minifyHTML($html)
    {
   	 $pattern = '/<(?<script>script).*?<\/script\s*>|<(?<style>style).*?<\/style\s*>|<!(?<comment>--).*?-->|<(?<tag>[\/\w.:-]*)(?:".*?"|\'.*?\'|[^\'">]+)*>|(?<text>((<[^!\/\w.:-])?[^<]*)+)|/si';
   	 preg_match_all($pattern, $html, $matches, PREG_SET_ORDER);
   	 $overriding = false;
   	 $raw_tag = false;
   	 // Variable reused for output
   	 $html = '';
   	 foreach ($matches as $token)
   	 {
   		 $tag = (isset($token['tag'])) ? strtolower($token['tag']) : null;
   		 
   		 $content = $token[0];
   		 
   		 if (is_null($tag))
   		 {
   			 if ( !empty($token['script']) )
   			 {
   				 $strip = $this->compress_js;
   			 }
   			 else if ( !empty($token['style']) )
   			 {
   				 $strip = $this->compress_css;
   			 }
   			 else if ($content == '<!--wp-html-compression no compression-->')
   			 {
   				 $overriding = !$overriding;
   				 
   				 // Don't print the comment
   				 continue;
   			 }
   			 else if ($this->remove_comments)
   			 {
   				 if (!$overriding && $raw_tag != 'textarea')
   				 {
   					 // Remove any HTML comments, except MSIE conditional comments
   					 $content = preg_replace('/<!--(?!\s*(?:\[if [^\]]+]|<!|>))(?:(?!-->).)*-->/s', '', $content);
   				 }
   			 }
   		 }
   		 else
   		 {
   			 if ($tag == 'pre' || $tag == 'textarea')
   			 {
   				 $raw_tag = $tag;
   			 }
   			 else if ($tag == '/pre' || $tag == '/textarea')
   			 {
   				 $raw_tag = false;
   			 }
   			 else
   			 {
   				 if ($raw_tag || $overriding)
   				 {
   					 $strip = false;
   				 }
   				 else
   				 {
   					 $strip = true;
   					 
   					 // Remove any empty attributes, except:
   					 // action, alt, content, src
   					 $content = preg_replace('/(\s+)(\w++(?<!\baction|\balt|\bcontent|\bsrc)="")/', '$1', $content);
   					 
   					 // Remove any space before the end of self-closing XHTML tags
   					 // JavaScript excluded
   					 $content = str_replace(' />', '/>', $content);
   				 }
   			 }
   		 }
   		 
   		 if ($strip)
   		 {
   			 $content = $this->removeWhiteSpace($content);
   		 }
   		 
   		 $html .= $content;
   	 }
   	 
   	 return $html;
    }
   	 
    public function parseHTML($html)
    {
   	 $this->html = $this->minifyHTML($html);
   	 
   	 if ($this->info_comment)
   	 {
   		 $this->html .= "\n" . $this->bottomComment($html, $this->html);
   	 }
    }
    
    protected function removeWhiteSpace($str)
    {
   	 $str = str_replace("\t", ' ', $str);
   	 $str = str_replace("\n",  '', $str);
   	 $str = str_replace("\r",  '', $str);
   	 
   	 while (stristr($str, '  '))
   	 {
   		 $str = str_replace('  ', ' ', $str);
   	 }
   	 
   	 return $str;
    }
}

function wp_html_compression_finish($html)
{
    return new WP_HTML_Compression($html);
}

function wp_html_compression_start()
{
	global $opt_themes;
    $activate = $opt_themes['ex_themes_minify_activate_'];
    if (($activate == '1'))
    ob_start('wp_html_compression_finish');
}
add_action('get_header', 'wp_html_compression_start');