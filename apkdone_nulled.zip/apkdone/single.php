<?php get_header(); ?>
<div class="wrap post-<?php the_ID(); ?>">
<div class="single single-<?php the_ID(); ?>">
    <div class="container">
        <div class="columns">
            <div class="column is-9">                
                <nav class="breadcrumb" aria-label="breadcrumb_items">
				<span>
				<span><a href="<?php echo home_url(); ?>">Home</a> »
				<span><?php echo get_the_category_list( '  »  ', '', $post->ID ); ?></span>  »
				<span class="breadcrumb_last" aria-current="page"><?php echo get_the_title(); ?></span>
				</span>
				</span>
                </nav>
				<?php ex_themes_adv_single_page_(); ?>
                <?php get_template_part('template/loop/gallery'); ?>
                <?php ex_themes_notice_installers_(); ?>
                <?php get_template_part('template/loop/apk_info'); ?>
                <div class="clearfix"></div>
                <?php ex_themes_related_posts_(); ?>
                <?php get_template_part('template/loop/comments'); ?>
            </div>
            <div class="column is-3 sidebar">
                <?php get_sidebar(); ?>
            </div>
        </div>
                <div id="breadcrumbiblog">
            <?php if (function_exists('breadcrumbsX')) breadcrumbsX(); ?>
        </div>
    </div>
    </section>
<?php get_footer(); ?>