<?php
 if ( ! defined( 'ABSPATH' ) ) exit; 
get_header();
?>
    <div class="wrap archive">
        <div class="columns">
            <div class="column is-9">
                <nav class="breadcrumb" aria-label="breadcrumb_items" style="text-transform: capitalize;"> 
				<span>
				<span><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a> » 
				<span class="breadcrumb_last" aria-current="page">Oops! That page can&rsquo;t be found.</span>
				</span>
				</span>
                </nav>
				<?php ex_themes_adv_homes_(); ?>
                <div class="clearfix"></div>
				<div class="block-title">
                    <div class="atitle">
                        <p><?php echo esc_html__( 'Oops! That page can&rsquo;t be found.', 'apkdone' ); ?></p>
                    </div>
                </div>
                <p style="text-align:center;padding:10px;"><?php echo esc_html__( 'The page you were looking for could not be found. It might have been removed, renamed, or did not exist in the first place.', 'apkdone' ); ?></p>
            </div>
            <div class="column is-3 sidebar">
                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
<?php get_footer(); ?>