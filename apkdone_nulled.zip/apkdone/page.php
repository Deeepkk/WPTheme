<?php get_header(); ?>
<div class="wrap post-<?php the_title(); ?>">
<div class="single page page-<?php the_ID(); ?>">
    <div class="container">
        <div class="columns">
            <div class="column is-9">
                <nav class="breadcrumb" aria-label="breadcrumb_items">
                    <span>
                        <span>
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a> » <span class="breadcrumb_last" aria-current="page"><?php the_title(); ?></span>
                        </span>
                    </span>
                </nav>
                <article class="is-large">
                    <h1><?php the_title(); ?></h1>
                </article>
                <div class="desc">
                    <p><?php
                        if ( have_posts() ) : while ( have_posts() ) : the_post();
                            the_content();
                        endwhile;
                        endif;
                        ?></p>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="column is-3 sidebar">
                <?php get_sidebar(); ?>
            </div>
        </div>
        
        <div id="breadcrumbiblog">
            <?php if (function_exists('breadcrumbsX')) breadcrumbsX(); ?>
        </div>
    </div>
    </section>
<?php get_footer(); ?>