<?php get_header(); ?>
    <div class="page-container">
    <section class="section">
        <div class="container">
            <div class="columns">
                <div class="column is-9">
                    <?php ex_themes_homes_titles_(); ?>
                    <?php ex_themes_homes_search_(); ?>
                    <br>
                    <?php ex_themes_adv_homes_(); ?>
                    <hr>
                    <?php ex_themes_notice_installers_(); ?>
                    <div class="block-title">
					<div class="atitle"><p><?php echo esc_html__( 'Latest Updates', 'apkdone' ); ?></p></div>
                    </div>
                    <?php get_template_part('template/loop/home'); ?>
                    <div class="clearfix"></div>
                    <?php ex_themes_adv_homes_2(); ?>
                    <ul class="pagination paginador">
                        <?php ex_themes_page_navy_(); ?>
                    </ul>
                    <div class="clearfix"></div>
                    <?php get_template_part('template/loop/categorie_home'); ?>
                </div>
                <div class="column is-3 sidebar">
                    <?php get_sidebar(); ?>
                </div>
            </div>
 <?php get_footer(); ?>